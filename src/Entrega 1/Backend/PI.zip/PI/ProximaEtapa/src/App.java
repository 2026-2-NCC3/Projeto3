import DAO.AlunoDAO;
import entity.Aluno;

public class App {
    public static void main(String[] args) throws Exception {
        Aluno a1 = new Aluno();
		
		a1.setNome_aluno("Lucas");
		a1.setTelefone_aluno("11 99999-9999");
		a1.setEscola("FECAP");
		a1.setCidade("Guarulhos");
		a1.setGrade("Terça-feira");
		
		new AlunoDAO().cadastrarUsuario(a1);
    }
}
