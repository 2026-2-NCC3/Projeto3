package entity;

import java.sql.Timestamp;

public class Inscricao {

    private int id_inscricao;
    private int id_aluno; // Chave Estrangeira
    private int id_curso; // Chave Estrangeira
    private String status_inscricao;
    private Timestamp data_inscricao; 

    
    public Inscricao() {
    }

    
    public int getId_inscricao() {
        return id_inscricao;
    }

    public void setId_inscricao(int id_inscricao) {
        this.id_inscricao = id_inscricao;
    }

    public int getId_aluno() {
        return id_aluno;
    }

    public void setId_aluno(int id_aluno) {
        this.id_aluno = id_aluno;
    }

    public int getId_curso() {
        return id_curso;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }

    public String getStatus_inscricao() {
        return status_inscricao;
    }

    public void setStatus_inscricao(String status_inscricao) {
        this.status_inscricao = status_inscricao;
    }

    public Timestamp getData_inscricao() {
        return data_inscricao;
    }

    public void setData_inscricao(Timestamp data_inscricao) {
        this.data_inscricao = data_inscricao;
    }
}