package entity;

import java.sql.Date;
import java.sql.Time;

public class Curso {
    
    private int id_curso;
    private int id_atividade; // Chave estrangeira
    private int id_universidade; // Chave estrangeira
    private String nome_curso;
    private String descricao_curso;
    private Date data_curso;
    private Time horario_curso;
    private String local_curso;
    private int carga_horaria;
    private int quantidade_aula;

    
    public Curso() {
    }

    
    public int getId_curso() {
        return id_curso;
    }

    public void setId_curso(int id_curso) {
        this.id_curso = id_curso;
    }

    public int getId_atividade() {
        return id_atividade;
    }

    public void setId_atividade(int id_atividade) {
        this.id_atividade = id_atividade;
    }

    public int getId_universidade() {
        return id_universidade;
    }

    public void setId_universidade(int id_universidade) {
        this.id_universidade = id_universidade;
    }

    public String getNome_curso() {
        return nome_curso;
    }

    public void setNome_curso(String nome_curso) {
        this.nome_curso = nome_curso;
    }

    public String getDescricao_curso() {
        return descricao_curso;
    }

    public void setDescricao_curso(String descricao_curso) {
        this.descricao_curso = descricao_curso;
    }

    public Date getData_curso() {
        return data_curso;
    }

    public void setData_curso(Date data_curso) {
        this.data_curso = data_curso;
    }

    public Time getHorario_curso() {
        return horario_curso;
    }

    public void setHorario_curso(Time horario_curso) {
        this.horario_curso = horario_curso;
    }

    public String getLocal_curso() {
        return local_curso;
    }

    public void setLocal_curso(String local_curso) {
        this.local_curso = local_curso;
    }

    public int getCarga_horaria() {
        return carga_horaria;
    }

    public void setCarga_horaria(int carga_horaria) {
        this.carga_horaria = carga_horaria;
    }

    public int getQuantidade_aula() {
        return quantidade_aula;
    }

    public void setQuantidade_aula(int quantidade_aula) {
        this.quantidade_aula = quantidade_aula;
    }
}