package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import entity.Aluno;

public class AlunoDAO {
    
    //Cadastrar
    public void cadastrarUsuario(Aluno aluno) {
        String sql = "INSERT INTO Aluno (nome_aluno, telefone_aluno, escola, cidade, grade) VALUES ( ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;
        
        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getNome_aluno());
            ps.setString(2, aluno.getTelefone_aluno());
            ps.setString(3, aluno.getEscola());
            ps.setString(4, aluno.getCidade());
            ps.setString(5, aluno.getGrade());
            
            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //Atualizar
    public void atualizarAluno(Aluno aluno) {
        String sql = "UPDATE Aluno SET nome_aluno = ?, telefone_aluno = ?, escola = ?, cidade = ?, grade = ? WHERE id_aluno = ?";
        PreparedStatement ps = null;
        
        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setString(1, aluno.getNome_aluno());
            ps.setString(2, aluno.getTelefone_aluno());
            ps.setString(3, aluno.getEscola());
            ps.setString(4, aluno.getCidade());
            ps.setString(5, aluno.getGrade());
            ps.setInt(6, aluno.getId_aluno());
            
            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Deletar
    public void deletarAluno(int id_aluno) {
        String sql = "DELETE FROM Aluno WHERE id_aluno = ?";
        PreparedStatement ps = null;
        
        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_aluno);
            
            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Buscar todos os alunos
    public List<Aluno> listarAlunos() {
        String sql = "SELECT * FROM Aluno";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Aluno> alunos = new ArrayList<>();
        
        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                Aluno aluno = new Aluno();
                aluno.setId_aluno(rs.getInt("id_aluno"));
                aluno.setNome_aluno(rs.getString("nome_aluno"));
                aluno.setTelefone_aluno(rs.getString("telefone_aluno"));
                aluno.setEscola(rs.getString("escola"));
                aluno.setCidade(rs.getString("cidade"));
                aluno.setGrade(rs.getString("grade"));
                
                alunos.add(aluno);
            }
            
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return alunos;
    }

    //Buscar aluno por ID
    public Aluno buscarAlunoPorId(int id_aluno) {
        String sql = "SELECT * FROM Aluno WHERE id_aluno = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        Aluno aluno = null;
        
        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_aluno);
            rs = ps.executeQuery();
            
            if (rs.next()) {
                aluno = new Aluno();
                aluno.setId_aluno(rs.getInt("id_aluno"));
                aluno.setNome_aluno(rs.getString("nome_aluno"));
                aluno.setTelefone_aluno(rs.getString("telefone_aluno"));
                aluno.setEscola(rs.getString("escola"));
                aluno.setCidade(rs.getString("cidade"));
                aluno.setGrade(rs.getString("grade"));
            }
            
            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return aluno;
    }
}