package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import entity.Inscricao;

public class InscricaoDAO {

    public InscricaoDAO() {
    }

    //Cadastrar
    public void cadastrarInscricao(Inscricao inscricao) {
        // A data de inscricao é preenchida pelo DEFAULT CURRENT_TIMESTAMP no banco, então não precisa por ela aqui, que nem o id autoincrement
        String sql = "INSERT INTO Inscricao (id_aluno, id_curso, status_inscricao) VALUES (?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, inscricao.getId_aluno());
            ps.setInt(2, inscricao.getId_curso());
            ps.setString(3, inscricao.getStatus_inscricao());

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Atualizar
    public void atualizarInscricao(Inscricao inscricao) {
        String sql = "UPDATE Inscricao SET id_aluno = ?, id_curso = ?, status_inscricao = ? WHERE id_inscricao = ?";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, inscricao.getId_aluno());
            ps.setInt(2, inscricao.getId_curso());
            ps.setString(3, inscricao.getStatus_inscricao());
            ps.setInt(4, inscricao.getId_inscricao());

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Deletar
    public void deletarInscricao(int id_inscricao) {
        String sql = "DELETE FROM Inscricao WHERE id_inscricao = ?";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_inscricao);

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Buscar todas as inscrições
    public List<Inscricao> listarInscricoes() {
        String sql = "SELECT * FROM Inscricao";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Inscricao> inscricoes = new ArrayList<>();

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Inscricao inscricao = new Inscricao();
                inscricao.setId_inscricao(rs.getInt("id_inscricao"));
                inscricao.setId_aluno(rs.getInt("id_aluno"));
                inscricao.setId_curso(rs.getInt("id_curso"));
                inscricao.setStatus_inscricao(rs.getString("status_inscricao"));
                inscricao.setData_inscricao(rs.getTimestamp("data_inscricao"));

                inscricoes.add(inscricao);
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return inscricoes;
    }
    
    //Buscar as inscrições de aluno por id
    public List<Inscricao> buscarInscricoesPorAluno(int id_aluno) {
        String sql = "SELECT * FROM Inscricao WHERE id_aluno = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Inscricao> inscricoes = new ArrayList<>();

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_aluno);
            rs = ps.executeQuery();

            while (rs.next()) {
                Inscricao inscricao = new Inscricao();
                inscricao.setId_inscricao(rs.getInt("id_inscricao"));
                inscricao.setId_aluno(rs.getInt("id_aluno"));
                inscricao.setId_curso(rs.getInt("id_curso"));
                inscricao.setStatus_inscricao(rs.getString("status_inscricao"));
                inscricao.setData_inscricao(rs.getTimestamp("data_inscricao"));

                inscricoes.add(inscricao);
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return inscricoes;
    }
}