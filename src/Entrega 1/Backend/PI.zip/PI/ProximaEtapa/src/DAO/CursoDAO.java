package DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import conexao.Conexao;
import entity.Curso;

public class CursoDAO {

    public CursoDAO() {
    }

    //Cadastrar
    public void cadastrarCurso(Curso curso) {
        String sql = "INSERT INTO Curso (id_atividade, id_universidade, nome_curso, descricao_curso, data_curso, horario_curso, local_curso, carga_horaria, quantidade_aula) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, curso.getId_atividade());
            ps.setInt(2, curso.getId_universidade());
            ps.setString(3, curso.getNome_curso());
            ps.setString(4, curso.getDescricao_curso());
            ps.setDate(5, curso.getData_curso());
            ps.setTime(6, curso.getHorario_curso());
            ps.setString(7, curso.getLocal_curso());
            ps.setInt(8, curso.getCarga_horaria());
            ps.setInt(9, curso.getQuantidade_aula());

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Atualizar
    public void atualizarCurso(Curso curso) {
        String sql = "UPDATE Curso SET id_atividade = ?, id_universidade = ?, nome_curso = ?, descricao_curso = ?, data_curso = ?, horario_curso = ?, local_curso = ?, carga_horaria = ?, quantidade_aula = ? WHERE id_curso = ?";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, curso.getId_atividade());
            ps.setInt(2, curso.getId_universidade());
            ps.setString(3, curso.getNome_curso());
            ps.setString(4, curso.getDescricao_curso());
            ps.setDate(5, curso.getData_curso());
            ps.setTime(6, curso.getHorario_curso());
            ps.setString(7, curso.getLocal_curso());
            ps.setInt(8, curso.getCarga_horaria());
            ps.setInt(9, curso.getQuantidade_aula());
            ps.setInt(10, curso.getId_curso());

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Deletar
    public void deletarCurso(int id_curso) {
        String sql = "DELETE FROM Curso WHERE id_curso = ?";
        PreparedStatement ps = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_curso);

            ps.execute();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Buscar todos os cursos
    public List<Curso> listarCursos() {
        String sql = "SELECT * FROM Curso";
        PreparedStatement ps = null;
        ResultSet rs = null;
        List<Curso> cursos = new ArrayList<>();

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                Curso curso = new Curso();
                curso.setId_curso(rs.getInt("id_curso"));
                curso.setId_atividade(rs.getInt("id_atividade"));
                curso.setId_universidade(rs.getInt("id_universidade"));
                curso.setNome_curso(rs.getString("nome_curso"));
                curso.setDescricao_curso(rs.getString("descricao_curso"));
                curso.setData_curso(rs.getDate("data_curso"));
                curso.setHorario_curso(rs.getTime("horario_curso"));
                curso.setLocal_curso(rs.getString("local_curso"));
                curso.setCarga_horaria(rs.getInt("carga_horaria"));
                curso.setQuantidade_aula(rs.getInt("quantidade_aula"));

                cursos.add(curso);
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return cursos;
    }

    //Buscar curso por ID
    public Curso buscarCursoPorId(int id_curso) {
        String sql = "SELECT * FROM Curso WHERE id_curso = ?";
        PreparedStatement ps = null;
        ResultSet rs = null;
        Curso curso = null;

        try {
            ps = Conexao.getConexao().prepareStatement(sql);
            ps.setInt(1, id_curso);
            rs = ps.executeQuery();

            if (rs.next()) {
                curso = new Curso();
                curso.setId_curso(rs.getInt("id_curso"));
                curso.setId_atividade(rs.getInt("id_atividade"));
                curso.setId_universidade(rs.getInt("id_universidade"));
                curso.setNome_curso(rs.getString("nome_curso"));
                curso.setDescricao_curso(rs.getString("descricao_curso"));
                curso.setData_curso(rs.getDate("data_curso"));
                curso.setHorario_curso(rs.getTime("horario_curso"));
                curso.setLocal_curso(rs.getString("local_curso"));
                curso.setCarga_horaria(rs.getInt("carga_horaria"));
                curso.setQuantidade_aula(rs.getInt("quantidade_aula"));
            }

            rs.close();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return curso;
    }
}