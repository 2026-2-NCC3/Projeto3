const form = document.querySelector("form");
const inputNome = document.querySelector(".nome");
const inputTel = document.querySelector(".tel");
const inputEscola = document.querySelector(".escola");
const inputCidade = document.querySelector(".cidade");
const inputGrade = document.querySelector(".grade");
const inputSenha = document.querySelector(".senha");


form.addEventListener("submit", function (event) {
    event.preventDefault(); // Impede o comportamento padrão de recarregar a página ao enviar

    cadastrar();
    limpar();
});

function cadastrar() {
    fetch("http://localhost:8080/cadastrar", {
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        method: "POST",
        body: JSON.stringify({
            nome: inputNome.value,
            telefone: inputTel.value,
            escola: inputEscola.value,
            cidade: inputCidade.value,
            grade: inputGrade.value,
            senha: inputSenha.value
            
        })
    })
    .then(function (res) { console.log(res) })
    .catch(function (res) { console.log(res) })
}

function limpar() {
    inputNome.value = "";
    inputTel.value = "";
    inputEscola.value = "";
    inputCidade.value = "";
    inputGrade.value = "";
    inputSenha.value = "";
}