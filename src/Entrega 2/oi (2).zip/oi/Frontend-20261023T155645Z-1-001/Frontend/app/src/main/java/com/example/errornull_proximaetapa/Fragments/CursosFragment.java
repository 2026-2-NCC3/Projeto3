package com.example.errornull_proximaetapa.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.errornull_proximaetapa.BlacklistManager;
import com.example.errornull_proximaetapa.CarouselAdapter;
import com.example.errornull_proximaetapa.CursoInfo;
import com.example.errornull_proximaetapa.NotificationHelper;
import com.example.errornull_proximaetapa.PerfilFaculdadeActivity;
import com.example.errornull_proximaetapa.R;
import com.example.errornull_proximaetapa.UserSession;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CursosFragment extends Fragment {

    private ViewPager2 viewPagerCursosCarousel;
    private final Handler carouselHandler = new Handler(Looper.getMainLooper());
    private Runnable carouselRunnable;
    private int currentCarouselPosition = 0;

    private View dot1, dot2, dot3;
    private View facul1, facul2, facul3;
    private View cardCurso1, cardCurso2, cardCurso3, cardCurso4;
    private View btnSininhoNotificacoes;

    private Button btnAdicionarFaculdadeAdmin, btnAdicionarCursoAdmin;
    private ImageView btnExcluir1, btnExcluir2, btnExcluir3, btnExcluir4;

    // Filtros Multi-Seleção Backdrop
    private View btnToggleBackdropFilter;
    private TextView txtFiltroSelecionadoBackdrop;
    private final Set<String> categoriasMultiSelecionadas = new HashSet<>();

    // Elementos do Perfil da Faculdade do Professor
    private LinearLayout containerCursosProfessorPage;
    private LinearLayout containerCursosAlunoPage;
    private Button btnPostarNovaDisciplinaProfPage;
    private LinearLayout containerDisciplinasProfPage;
    private TextView txtNomeEscolaProfessor, txtDeptoProfessor;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cursos, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dot1 = view.findViewById(R.id.dotCursos1);
        dot2 = view.findViewById(R.id.dotCursos2);
        dot3 = view.findViewById(R.id.dotCursos3);

        facul1 = view.findViewById(R.id.facul1);
        facul2 = view.findViewById(R.id.facul2);
        facul3 = view.findViewById(R.id.facul3);

        cardCurso1 = view.findViewById(R.id.cardCurso1);
        cardCurso2 = view.findViewById(R.id.cardCurso2);
        cardCurso3 = view.findViewById(R.id.cardCurso3);
        cardCurso4 = view.findViewById(R.id.cardCurso4);

        btnToggleBackdropFilter = view.findViewById(R.id.btnToggleBackdropFilter);
        txtFiltroSelecionadoBackdrop = view.findViewById(R.id.txtFiltroSelecionadoBackdrop);

        if (btnToggleBackdropFilter != null) {
            btnToggleBackdropFilter.setOnClickListener(v -> abrirBackdropFilterDialog());
        }

        btnAdicionarFaculdadeAdmin = view.findViewById(R.id.btnAdicionarFaculdadeAdmin);
        btnAdicionarCursoAdmin = view.findViewById(R.id.btnAdicionarCursoAdmin);

        btnExcluir1 = view.findViewById(R.id.btnExcluirCurso1Admin);
        btnExcluir2 = view.findViewById(R.id.btnExcluirCurso2Admin);
        btnExcluir3 = view.findViewById(R.id.btnExcluirCurso3Admin);
        btnExcluir4 = view.findViewById(R.id.btnExcluirCurso4Admin);

        containerCursosProfessorPage = view.findViewById(R.id.containerCursosProfessorPage);
        containerCursosAlunoPage = view.findViewById(R.id.containerCursosAlunoPage);
        btnPostarNovaDisciplinaProfPage = view.findViewById(R.id.btnPostarNovaDisciplinaProfPage);
        containerDisciplinasProfPage = view.findViewById(R.id.containerDisciplinasProfPage);
        txtNomeEscolaProfessor = view.findViewById(R.id.txtNomeEscolaProfessor);
        txtDeptoProfessor = view.findViewById(R.id.txtDeptoProfessor);

        btnSininhoNotificacoes = view.findViewById(R.id.btnSininhoNotificacoes);
        if (btnSininhoNotificacoes != null) {
            btnSininhoNotificacoes.setOnClickListener(v -> NotificationHelper.exibirCentralNotificacoes(requireContext(), () -> atualizarSininho(view)));
        }

        if (btnPostarNovaDisciplinaProfPage != null) {
            btnPostarNovaDisciplinaProfPage.setOnClickListener(v -> exibirDialogPostarCursoProf());
        }

        inicializarCarrossel(view);
        configurarCliquesFaculdades();
        configurarCliquesCursos();
        configurarFerramentasAdmin();
        atualizarCursosDisponiveis();
        atualizarSininho(view);
    }

    private void abrirBackdropFilterDialog() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_backdrop_filter_cursos, null);

        Button btnFechar = dialogView.findViewById(R.id.btnFecharBackdrop);
        Button btnAplicar = dialogView.findViewById(R.id.btnAplicarBackdropFilter);

        CheckBox cbTodos = dialogView.findViewById(R.id.cbTodosBackdrop);
        CheckBox cbTech = dialogView.findViewById(R.id.cbTechBackdrop);
        CheckBox cbGestao = dialogView.findViewById(R.id.cbGestaoBackdrop);
        CheckBox cbLogistica = dialogView.findViewById(R.id.cbLogisticaBackdrop);
        CheckBox cbMarketing = dialogView.findViewById(R.id.cbMarketingBackdrop);

        boolean nenhumSelecionado = categoriasMultiSelecionadas.isEmpty() || categoriasMultiSelecionadas.contains("todos");

        if (cbTodos != null) cbTodos.setChecked(nenhumSelecionado);
        if (cbTech != null) cbTech.setChecked(categoriasMultiSelecionadas.contains("tech"));
        if (cbGestao != null) cbGestao.setChecked(categoriasMultiSelecionadas.contains("gestao"));
        if (cbLogistica != null) cbLogistica.setChecked(categoriasMultiSelecionadas.contains("logistica"));
        if (cbMarketing != null) cbMarketing.setChecked(categoriasMultiSelecionadas.contains("marketing"));

        if (cbTodos != null) {
            cbTodos.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (isChecked) {
                    if (cbTech != null) cbTech.setChecked(false);
                    if (cbGestao != null) cbGestao.setChecked(false);
                    if (cbLogistica != null) cbLogistica.setChecked(false);
                    if (cbMarketing != null) cbMarketing.setChecked(false);
                }
            });
        }

        View.OnClickListener desmarcarTodosListener = v -> {
            if (cbTodos != null) cbTodos.setChecked(false);
        };

        if (cbTech != null) cbTech.setOnClickListener(desmarcarTodosListener);
        if (cbGestao != null) cbGestao.setOnClickListener(desmarcarTodosListener);
        if (cbLogistica != null) cbLogistica.setOnClickListener(desmarcarTodosListener);
        if (cbMarketing != null) cbMarketing.setOnClickListener(desmarcarTodosListener);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnFechar != null) {
            btnFechar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnAplicar != null) {
            btnAplicar.setOnClickListener(v -> {
                categoriasMultiSelecionadas.clear();

                if (cbTech != null && cbTech.isChecked()) categoriasMultiSelecionadas.add("tech");
                if (cbGestao != null && cbGestao.isChecked()) categoriasMultiSelecionadas.add("gestao");
                if (cbLogistica != null && cbLogistica.isChecked()) categoriasMultiSelecionadas.add("logistica");
                if (cbMarketing != null && cbMarketing.isChecked()) categoriasMultiSelecionadas.add("marketing");

                if (categoriasMultiSelecionadas.isEmpty() || (cbTodos != null && cbTodos.isChecked())) {
                    categoriasMultiSelecionadas.clear();
                    categoriasMultiSelecionadas.add("todos");
                    if (txtFiltroSelecionadoBackdrop != null) txtFiltroSelecionadoBackdrop.setText("🔍 Filtrar Cursos: [ Todas as Áreas ] ▾");
                } else {
                    StringBuilder sb = new StringBuilder("🔍 Cursos: [ ");
                    int count = 0;
                    for (String cat : categoriasMultiSelecionadas) {
                        count++;
                        sb.append(cat.toUpperCase());
                        if (count < categoriasMultiSelecionadas.size()) sb.append(", ");
                    }
                    sb.append(" ] ▾");
                    if (txtFiltroSelecionadoBackdrop != null) txtFiltroSelecionadoBackdrop.setText(sb.toString());
                }

                aplicarFiltroBackdropCursos();
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void aplicarFiltroBackdropCursos() {
        if (getContext() == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        Set<String> cursosInscritos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        boolean mostrarTodos = categoriasMultiSelecionadas.isEmpty() || categoriasMultiSelecionadas.contains("todos");

        boolean mostrarGestao = mostrarTodos || categoriasMultiSelecionadas.contains("gestao");
        boolean mostrarLogistica = mostrarTodos || categoriasMultiSelecionadas.contains("logistica");
        boolean mostrarMarketing = mostrarTodos || categoriasMultiSelecionadas.contains("marketing");
        boolean mostrarTech = mostrarTodos || categoriasMultiSelecionadas.contains("tech");

        if (cardCurso1 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_adm", false);
            cardCurso1.setVisibility(mostrarGestao && !deletado && !cursosInscritos.contains("adm") ? View.VISIBLE : View.GONE);
        }

        if (cardCurso2 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_logistica", false);
            cardCurso2.setVisibility(mostrarLogistica && !deletado && !cursosInscritos.contains("logistica") ? View.VISIBLE : View.GONE);
        }

        if (cardCurso3 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_marketing", false);
            cardCurso3.setVisibility(mostrarMarketing && !deletado && !cursosInscritos.contains("marketing") ? View.VISIBLE : View.GONE);
        }

        if (cardCurso4 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_web", false);
            cardCurso4.setVisibility(mostrarTech && !deletado && !cursosInscritos.contains("web") ? View.VISIBLE : View.GONE);
        }
    }

    private void atualizarSininho(View view) {
        if (view == null || getContext() == null) return;
        TextView badge = view.findViewById(R.id.badgeSininhoQtd);
        int qtd = NotificationHelper.getQtdNaoLidas(requireContext());
        if (badge != null) {
            if (qtd > 0) {
                badge.setText(String.valueOf(qtd));
                badge.setVisibility(View.VISIBLE);
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    private void inicializarCarrossel(View view) {
        int[] carouselImages = new int[]{
                R.drawable.proximaetapa1,
                R.drawable.proximaetapa2,
                R.drawable.proximaetapa3
        };

        viewPagerCursosCarousel = view.findViewById(R.id.viewPagerCursosCarousel);
        if (viewPagerCursosCarousel != null) {
            viewPagerCursosCarousel.setAdapter(new CarouselAdapter(carouselImages));

            viewPagerCursosCarousel.setPageTransformer((page, position) -> {
                float absPos = Math.abs(position);
                if (position <= -1 || position >= 1) {
                    page.setAlpha(0f);
                } else {
                    page.setTranslationX(-position * page.getWidth());
                    page.setAlpha(1f - absPos);
                    float scale = 0.95f + (1f - absPos) * 0.05f;
                    page.setScaleX(scale);
                    page.setScaleY(scale);
                }
            });

            viewPagerCursosCarousel.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    currentCarouselPosition = position;
                    atualizarDots(position);
                }
            });

            carouselRunnable = new Runnable() {
                @Override
                public void run() {
                    if (viewPagerCursosCarousel != null) {
                        currentCarouselPosition = (currentCarouselPosition + 1) % carouselImages.length;
                        viewPagerCursosCarousel.setCurrentItem(currentCarouselPosition, true);
                        carouselHandler.postDelayed(this, 6000);
                    }
                }
            };

            carouselHandler.postDelayed(carouselRunnable, 6000);
        }
    }

    private void atualizarDots(int position) {
        if (dot1 == null || dot2 == null || dot3 == null) return;

        dot1.setBackgroundResource(position == 0 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot2.setBackgroundResource(position == 1 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot3.setBackgroundResource(position == 2 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);

        ViewGroup.LayoutParams p1 = dot1.getLayoutParams();
        p1.width = position == 0 ? 50 : 20;
        dot1.setLayoutParams(p1);

        ViewGroup.LayoutParams p2 = dot2.getLayoutParams();
        p2.width = position == 1 ? 50 : 20;
        dot2.setLayoutParams(p2);

        ViewGroup.LayoutParams p3 = dot3.getLayoutParams();
        p3.width = position == 2 ? 50 : 20;
        dot3.setLayoutParams(p3);
    }

    private void configurarFerramentasAdmin() {
        if (getContext() == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        String tipo = sp.getString("tipoUsuario", "aluno");

        boolean isProf = "professor".equalsIgnoreCase(tipo);
        boolean isAdmin = "admin".equalsIgnoreCase(tipo);

        if (isProf) {
            if (containerCursosProfessorPage != null) containerCursosProfessorPage.setVisibility(View.VISIBLE);
            if (containerCursosAlunoPage != null) containerCursosAlunoPage.setVisibility(View.GONE);

            String escolaProf = sp.getString("escola", sp.getString("faculdade", ""));
            if (escolaProf.isEmpty()) {
                if (txtNomeEscolaProfessor != null) txtNomeEscolaProfessor.setText("Sem instituição lecionada vinculada");
                if (txtDeptoProfessor != null) txtDeptoProfessor.setText("Faça login ou cadastro para sincronizar sua universidade");
            } else {
                if (txtNomeEscolaProfessor != null) txtNomeEscolaProfessor.setText(escolaProf);
                if (txtDeptoProfessor != null) txtDeptoProfessor.setText("Departamento de Ensino & Pesquisa Acadêmica");
            }

            renderizarDisciplinasProfessor(sp);
        } else {
            if (containerCursosProfessorPage != null) containerCursosProfessorPage.setVisibility(View.GONE);
            if (containerCursosAlunoPage != null) containerCursosAlunoPage.setVisibility(View.VISIBLE);

            if (btnAdicionarFaculdadeAdmin != null) {
                btnAdicionarFaculdadeAdmin.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnAdicionarFaculdadeAdmin.setOnClickListener(v -> exibirDialogAdicionarFaculdade());
            }

            if (btnAdicionarCursoAdmin != null) {
                btnAdicionarCursoAdmin.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnAdicionarCursoAdmin.setOnClickListener(v -> exibirDialogAdicionarCursoAdmin());
            }

            if (btnExcluir1 != null) {
                btnExcluir1.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnExcluir1.setOnClickListener(v -> excluirCursoAdmin("adm", cardCurso1));
            }

            if (btnExcluir2 != null) {
                btnExcluir2.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnExcluir2.setOnClickListener(v -> excluirCursoAdmin("logistica", cardCurso2));
            }

            if (btnExcluir3 != null) {
                btnExcluir3.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnExcluir3.setOnClickListener(v -> excluirCursoAdmin("marketing", cardCurso3));
            }

            if (btnExcluir4 != null) {
                btnExcluir4.setVisibility(isAdmin ? View.VISIBLE : View.GONE);
                btnExcluir4.setOnClickListener(v -> excluirCursoAdmin("web", cardCurso4));
            }
        }
    }

    private void renderizarDisciplinasProfessor(SharedPreferences sp) {
        if (containerDisciplinasProfPage == null || getContext() == null) return;
        containerDisciplinasProfPage.removeAllViews();

        Set<String> setCursos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        if (setCursos.isEmpty()) {
            TextView txtVazio = new TextView(getContext());
            txtVazio.setText("Nenhuma disciplina cadastrada por você ainda. Clique em '➕ Postar Disciplina' para publicar uma nova matéria!");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(13);
            txtVazio.setPadding(12, 12, 12, 12);
            containerDisciplinasProfPage.addView(txtVazio);
            return;
        }

        LayoutInflater inflater = LayoutInflater.from(getContext());

        for (String idCurso : setCursos) {
            String nome = sp.getString("nomeCurso_" + idCurso, "");
            String faculdade = sp.getString("faculdadeCurso_" + idCurso, "USP");
            String dias = sp.getString("diasSemana_" + idCurso, "Seg, Qua, Sex (14h - 16h)");
            String prazoReserva = sp.getString("prazoReserva_" + idCurso, "Até 15/05/2026");

            if (nome.isEmpty()) continue;

            View profView = inflater.inflate(R.layout.item_curso_professor_row, containerDisciplinasProfPage, false);

            TextView txtNome = profView.findViewById(R.id.txtNomeCursoProfRow);
            TextView txtFacul = profView.findViewById(R.id.txtFaculdadeProfRow);
            TextView txtStatusInscricao = profView.findViewById(R.id.txtStatusInscricaoProfRow);
            Button btnAlunos = profView.findViewById(R.id.btnVerAlunosTurmaProfRow);
            Button btnFoto = profView.findViewById(R.id.btnAlterarFotoCursoProfRow);
            ImageView btnExcluir = profView.findViewById(R.id.btnExcluirCursoProfRow);

            if (txtNome != null) txtNome.setText(nome);
            if (txtFacul != null) txtFacul.setText(faculdade + " • " + dias);
            if (txtStatusInscricao != null) txtStatusInscricao.setText("Reserva: " + prazoReserva);

            if (btnAlunos != null) {
                btnAlunos.setOnClickListener(v -> exibirAlunosTurmaProfDialog(idCurso, nome, prazoReserva));
            }

            if (btnFoto != null) {
                btnFoto.setOnClickListener(v -> exibirOpcoesFotoCursoProf(idCurso, nome));
            }

            if (btnExcluir != null) {
                btnExcluir.setOnClickListener(v -> {
                    setCursos.remove(idCurso);
                    sp.edit().putStringSet("lista_cursos_ids", setCursos).remove("nomeCurso_" + idCurso).apply();
                    renderizarDisciplinasProfessor(sp);
                    NotificationHelper.exibirToastCustomizado(getContext(), "Disciplina " + nome + " excluída com sucesso!");
                });
            }

            containerDisciplinasProfPage.addView(profView);
        }
    }

    private void exibirOpcoesFotoCursoProf(String idCurso, String nomeCurso) {
        if (getContext() == null) return;

        CharSequence[] opcoes = {
                "📷 Capa Robótica / Tecnologia",
                "📊 Capa Administração / Negócios",
                "🚚 Capa Logística / Frotas",
                "📢 Capa Marketing / Vendas",
                "🎓 Capa Padrão Próxima Etapa"
        };

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setTitle("Alterar Foto da Disciplina: " + nomeCurso)
                .setItems(opcoes, (d, which) -> {
                    int resId = R.drawable.proximaetapa1;
                    if (which == 1) resId = R.drawable.adm_logo;
                    if (which == 2) resId = R.drawable.logistica_logo;
                    if (which == 3) resId = R.drawable.marketing_logo;
                    if (which == 4) resId = R.drawable.logo_proxima_etapa;

                    SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                    sp.edit().putInt("cursoImagem_" + idCurso, resId).apply();
                    NotificationHelper.exibirToastCustomizado(getContext(), "Foto da disciplina " + nomeCurso + " atualizada!");
                })
                .setNegativeButton("Cancelar", null)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    private void exibirAlunosTurmaProfDialog(String idCurso, String nomeCurso, String prazoInscricao) {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_alunos_turma_prof, null);

        Button btnVoltar = dialogView.findViewById(R.id.btnVoltarTurmaProf);
        TextView txtTitulo = dialogView.findViewById(R.id.txtTituloCursoTurmaProf);
        TextView txtPrazo = dialogView.findViewById(R.id.txtPrazoInscricaoTurmaProf);
        LinearLayout containerAlunos = dialogView.findViewById(R.id.containerAlunosInscritosTurmaProf);

        if (txtTitulo != null) txtTitulo.setText("Disciplina: " + nomeCurso);
        if (txtPrazo != null) txtPrazo.setText("Período de Reserva: " + prazoInscricao);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnVoltar != null) {
            btnVoltar.setOnClickListener(v -> dialog.dismiss());
        }

        if (containerAlunos != null) {
            containerAlunos.removeAllViews();

            SharedPreferences spGeneral = requireContext().getSharedPreferences("ListaGeralAlunosAdmin", Context.MODE_PRIVATE);
            String savedString = spGeneral.getString("lista_alunos_cadastrados_string", "");
            List<String> listaAlunos = new ArrayList<>();

            if (!savedString.isEmpty()) {
                listaAlunos.addAll(Arrays.asList(savedString.split("###")));
            }

            int contInscritos = 0;

            for (String aStr : listaAlunos) {
                String[] p = aStr.split(";;;");
                String nomeA = p.length > 0 ? p[0] : "Aluno";
                String emailA = p.length > 1 ? p[1] : "";

                if (emailA.isEmpty()) continue;

                SharedPreferences spAluno = requireContext().getSharedPreferences("PerfilUsuario_" + emailA.replaceAll("[^a-zA-Z0-9]", "_"), Context.MODE_PRIVATE);
                Set<String> cursosInscritosAluno = spAluno.getStringSet("lista_cursos_ids", new HashSet<>());

                // FILTRA SOMENTE ALUNOS QUE REALMENTE SE INSCREVERAM NESTA DISCIPLINA
                if (cursosInscritosAluno.contains(idCurso)) {
                    contInscritos++;
                    int progresso = spAluno.getInt("progressoCurso_" + idCurso, 0);

                    TextView txtCardA = new TextView(requireContext());
                    txtCardA.setText("👤 " + nomeA + " (" + emailA + ")\n• Progresso: " + progresso + "% das atividades concluídas");
                    txtCardA.setTextColor(requireContext().getColor(R.color.dark_indigo));
                    txtCardA.setTextSize(13);
                    txtCardA.setBackgroundResource(R.drawable.bg_card_questionario);
                    txtCardA.setPadding(16, 12, 16, 12);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, 4, 0, 6);
                    txtCardA.setLayoutParams(lp);

                    containerAlunos.addView(txtCardA);
                }
            }

            if (contInscritos == 0) {
                TextView txtVazio = new TextView(requireContext());
                txtVazio.setText("Nenhum aluno inscrito nesta disciplina até o momento.");
                txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
                txtVazio.setTextSize(13);
                txtVazio.setPadding(12, 12, 12, 12);
                containerAlunos.addView(txtVazio);
            }
        }

        dialog.show();
    }

    private void exibirDialogPostarCursoProf() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_postar_curso_prof, null);

        EditText inputNome = dialogView.findViewById(R.id.inputNomeCursoProf);
        EditText inputFaculdade = dialogView.findViewById(R.id.inputFaculdadeProf);
        EditText inputPontos = dialogView.findViewById(R.id.inputPontosTotaisProf);
        EditText inputReserva = dialogView.findViewById(R.id.inputPrazoReservaProf);
        EditText inputTermino = dialogView.findViewById(R.id.inputPrazoTerminoProf);
        Spinner spinnerQtdAulas = dialogView.findViewById(R.id.spinnerQtdAulasProf);
        EditText inputDias = dialogView.findViewById(R.id.inputDiasSemanaProf);

        Button btnAddModulo = dialogView.findViewById(R.id.btnAdicionarModuloProf);
        LinearLayout containerModulos = dialogView.findViewById(R.id.containerModulosProf);
        Button btnPublicar = dialogView.findViewById(R.id.btnPublicarCursoProfFinal);

        // Configura o Spinner de Quantidade de Aulas
        if (spinnerQtdAulas != null) {
            String[] opçõesAulas = {"5 Aulas (Completo)", "10 Aulas (Incompleto/Em Aulas)", "15 Aulas (Incompleto)", "20 Aulas (Finalizado)"};
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, opçõesAulas);
            spinnerQtdAulas.setAdapter(adapter);
        }

        // Adiciona 1 Módulo Padrão Inicial
        if (containerModulos != null) {
            adicionarBlocoModulo(containerModulos, "Módulo 1: Introdução Prática", "35", "Aulas teóricas + Teste 1");
        }

        if (btnAddModulo != null && containerModulos != null) {
            btnAddModulo.setOnClickListener(v -> adicionarBlocoModulo(containerModulos, "", "", ""));
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnPublicar != null) {
            btnPublicar.setOnClickListener(v -> {
                String nome = inputNome != null ? inputNome.getText().toString().trim() : "";
                String faculdade = inputFaculdade != null ? inputFaculdade.getText().toString().trim() : "USP";
                String pontos = inputPontos != null ? inputPontos.getText().toString().trim() : "100";
                String prazoReserva = inputReserva != null ? inputReserva.getText().toString().trim() : "Até 15/05/2026";
                String prazoTermino = inputTermino != null ? inputTermino.getText().toString().trim() : "Até 30/11/2026";
                String qtdAulas = spinnerQtdAulas != null && spinnerQtdAulas.getSelectedItem() != null ? spinnerQtdAulas.getSelectedItem().toString() : "10 Aulas";
                String dias = inputDias != null ? inputDias.getText().toString().trim() : "Seg, Qua e Sex (14h - 16h)";

                if (nome.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Digite o nome da disciplina!");
                    return;
                }

                String idCurso = "curso_prof_" + System.currentTimeMillis();
                SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

                Set<String> setCursos = new HashSet<>(sp.getStringSet("lista_cursos_ids", new HashSet<>()));
                setCursos.add(idCurso);

                sp.edit()
                        .putBoolean("inscrito", true)
                        .putStringSet("lista_cursos_ids", setCursos)
                        .putString("nomeCurso_" + idCurso, nome)
                        .putString("faculdadeCurso_" + idCurso, faculdade)
                        .putString("cargaHoraria_" + idCurso, pontos + " pontos")
                        .putString("diasSemana_" + idCurso, dias)
                        .putString("prazoReserva_" + idCurso, prazoReserva)
                        .putString("prazoTermino_" + idCurso, prazoTermino)
                        .putString("qtdAulas_" + idCurso, qtdAulas)
                        .putInt("progressoCurso_" + idCurso, 0)
                        .apply();

                NotificationHelper.adicionarNotificacao(
                        requireContext(),
                        "Nova Disciplina Publicada",
                        "Você publicou a matéria " + nome + " (" + faculdade + ") com período de reserva " + prazoReserva + "!"
                );

                NotificationHelper.exibirToastCustomizado(getContext(), "📢 Disciplina " + nome + " publicada com sucesso!");
                renderizarDisciplinasProfessor(sp);
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void adicionarBlocoModulo(LinearLayout container, String nomeDefault, String pontosDefault, String modosDefault) {
        if (getContext() == null || container == null) return;

        View moduloView = LayoutInflater.from(requireContext()).inflate(R.layout.item_modulo_prof_block, container, false);

        EditText inputNomeM = moduloView.findViewById(R.id.inputNomeModuloProf);
        EditText inputPontosM = moduloView.findViewById(R.id.inputPontosModuloProf);
        EditText inputModosM = moduloView.findViewById(R.id.inputModosModuloProf);
        ImageView btnRemoverM = moduloView.findViewById(R.id.btnRemoverModuloProf);

        if (inputNomeM != null && !nomeDefault.isEmpty()) inputNomeM.setText(nomeDefault);
        if (inputPontosM != null && !pontosDefault.isEmpty()) inputPontosM.setText(pontosDefault);
        if (inputModosM != null && !modosDefault.isEmpty()) inputModosM.setText(modosDefault);

        if (btnRemoverM != null) {
            btnRemoverM.setOnClickListener(v -> container.removeView(moduloView));
        }

        container.addView(moduloView);
    }

    private void excluirCursoAdmin(String idCurso, View cardView) {
        if (getContext() == null) return;

        new AlertDialog.Builder(requireContext())
                .setTitle("Excluir Curso")
                .setMessage("Deseja realmente remover este curso da plataforma?")
                .setPositiveButton("Excluir", (dialog, which) -> {
                    SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                    sp.edit().putBoolean("curso_deletado_" + idCurso, true).apply();
                    if (cardView != null) cardView.setVisibility(View.GONE);
                    NotificationHelper.exibirToastCustomizado(getContext(), "Curso removido com sucesso pelo ADM!");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void exibirDialogAdicionarFaculdade() {
        if (getContext() == null) return;

        LinearLayout customCard = new LinearLayout(requireContext());
        customCard.setOrientation(LinearLayout.VERTICAL);
        customCard.setBackgroundResource(R.drawable.bg_card_questionario);
        customCard.setPadding(40, 40, 40, 40);

        TextView title = new TextView(requireContext());
        title.setText("➕ Adicionar Nova Faculdade");
        title.setTextColor(requireContext().getColor(R.color.dark_indigo));
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);

        EditText inputNome = new EditText(requireContext());
        inputNome.setHint("Nome/Sigla da Faculdade (ex: FATEC)");

        EditText inputDesc = new EditText(requireContext());
        inputDesc.setHint("Descrição da Instituição");

        Button btnAdd = new Button(requireContext());
        btnAdd.setText("Cadastrar Faculdade");
        btnAdd.setBackgroundTintList(ColorStateList.valueOf(requireContext().getColor(R.color.yellow)));
        btnAdd.setTextColor(requireContext().getColor(R.color.dark_indigo));
        btnAdd.setTypeface(null, Typeface.BOLD);

        customCard.addView(title);
        customCard.addView(inputNome);
        customCard.addView(inputDesc);
        customCard.addView(btnAdd);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(customCard)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        btnAdd.setOnClickListener(v -> {
            String nome = inputNome.getText().toString().trim();
            if (nome.isEmpty()) {
                NotificationHelper.exibirToastCustomizado(getContext(), "Digite o nome da faculdade!");
                return;
            }
            NotificationHelper.adicionarNotificacao(requireContext(), "Nova Faculdade Adicionada", "A faculdade " + nome + " foi integrada à plataforma!");
            NotificationHelper.exibirToastCustomizado(getContext(), "Faculdade " + nome + " cadastrada!");
            dialog.dismiss();
        });

        dialog.show();
    }

    private void exibirDialogAdicionarCursoAdmin() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_postar_curso, null);

        EditText inputNome = dialogView.findViewById(R.id.inputNomeCursoPostar);
        EditText inputFaculdade = dialogView.findViewById(R.id.inputFaculdadePostar);
        EditText inputCarga = dialogView.findViewById(R.id.inputCargaHorariaPostar);
        EditText inputDias = dialogView.findViewById(R.id.inputDiasSemanaPostar);
        Button btnPublicar = dialogView.findViewById(R.id.btnPublicarCursoProfessor);

        if (btnPublicar != null) {
            btnPublicar.setText("➕ Cadastrar Curso na Plataforma");
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnPublicar != null) {
            btnPublicar.setOnClickListener(v -> {
                String nome = inputNome != null ? inputNome.getText().toString().trim() : "";
                String faculdade = inputFaculdade != null ? inputFaculdade.getText().toString().trim() : "USP";
                String carga = inputCarga != null ? inputCarga.getText().toString().trim() : "80 horas";
                String dias = inputDias != null ? inputDias.getText().toString().trim() : "Seg, Qua, Sex (14h - 16h)";

                if (nome.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Digite o nome do curso!");
                    return;
                }

                String idCurso = "curso_adm_" + System.currentTimeMillis();
                SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

                Set<String> setCursos = new HashSet<>(sp.getStringSet("lista_cursos_ids", new HashSet<>()));
                setCursos.add(idCurso);

                sp.edit()
                        .putBoolean("inscrito", true)
                        .putStringSet("lista_cursos_ids", setCursos)
                        .putString("nomeCurso_" + idCurso, nome)
                        .putString("faculdadeCurso_" + idCurso, faculdade)
                        .putString("cargaHoraria_" + idCurso, carga)
                        .putString("diasSemana_" + idCurso, dias)
                        .putInt("progressoCurso_" + idCurso, 0)
                        .apply();

                NotificationHelper.adicionarNotificacao(
                        requireContext(),
                        "Novo Curso Cadastrado",
                        "O ADM cadastrou o curso " + nome + " (" + faculdade + ") na plataforma!"
                );

                NotificationHelper.exibirToastCustomizado(getContext(), "📢 Curso " + nome + " publicado pelo ADM!");
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void configurarCliquesFaculdades() {
        if (facul1 != null) {
            facul1.setOnClickListener(v -> abrirPerfilFaculdadePage(
                    "USP",
                    "USP - Universidade de São Paulo",
                    "Líder em ensino superior, inovação acadêmica, pesquisa tecnológica e extensão universitária no Brasil.",
                    R.drawable.proximaetapa1
            ));
        }
        if (facul2 != null) {
            facul2.setOnClickListener(v -> abrirPerfilFaculdadePage(
                    "UNICAMP",
                    "UNICAMP - Universidade Estadual de Campinas",
                    "Referência internacional em pesquisa, engenharia, inovação tecnológica e ciências biológicas.",
                    R.drawable.proximaetapa2
            ));
        }
        if (facul3 != null) {
            facul3.setOnClickListener(v -> abrirPerfilFaculdadePage(
                    "UNESP",
                    "UNESP - Universidade Estadual Paulista",
                    "Excelente infraestrutura acadêmica com forte presença e impacto social em todo o estado de SP.",
                    R.drawable.proximaetapa3
            ));
        }
    }

    private void abrirPerfilFaculdadePage(String sigla, String nomeCompleto, String desc, int caparesId) {
        Intent intent = new Intent(getActivity(), PerfilFaculdadeActivity.class);
        intent.putExtra("sigla", sigla);
        intent.putExtra("nomeCompleto", nomeCompleto);
        intent.putExtra("descricao", desc);
        intent.putExtra("capaResId", caparesId);
        startActivity(intent);
    }

    private void configurarCliquesCursos() {
        if (cardCurso1 != null) {
            cardCurso1.setOnClickListener(v -> abrirDetalhesCurso(
                    "Administração & Gestão",
                    "Curso focado em liderança, processos organizacionais e gestão estratégica. Aulas práticas com mentoria de profissionais renomados.",
                    R.drawable.adm_logo, "USP", "adm", "80 horas", "Segunda, Quarta e Sexta (14h - 16h)"));
        }

        if (cardCurso2 != null) {
            cardCurso2.setOnClickListener(v -> abrirDetalhesCurso(
                    "Logística & Suprimentos",
                    "Aprenda gerenciamento de cadeias de suprimentos, frotas, armazenagem e distribuição eficiente para o mercado moderno.",
                    R.drawable.logistica_logo, "UNICAMP", "logistica", "60 horas", "Terça, Quinta e Sábado (09h - 11h)"));
        }

        if (cardCurso3 != null) {
            cardCurso3.setOnClickListener(v -> abrirDetalhesCurso(
                    "Marketing Digital",
                    "Desenvolva estratégias em mídias sociais, comunicação de marca, tráfego e vendas para grandes empresas e startups.",
                    R.drawable.marketing_logo, "UNESP", "marketing", "50 horas", "Segunda, Quarta e Sexta (16h - 18h)"));
        }

        if (cardCurso4 != null) {
            cardCurso4.setOnClickListener(v -> abrirDetalhesCurso(
                    "Desenvolvimento Web & TI",
                    "Sua jornada no mundo da programação! Aprenda desenvolvimento de software, aplicações web e tecnologia moderna.",
                    R.drawable.logo_proxima_etapa, "USP", "web", "100 horas", "Terça, Quinta e Sábado (14h - 17h)"));
        }
    }

    private void abrirDetalhesCurso(String nome, String descricao, int imagemResId, String faculdade, String idCurso, String carga, String dias) {
        if (getContext() != null && BlacklistManager.isSuspensoOuBanido(requireContext())) {
            BlacklistManager.exibirTelaBloqueioCurso(requireContext());
            return;
        }

        Intent intent = new Intent(getActivity(), CursoInfo.class);
        intent.putExtra("nomeCurso", nome);
        intent.putExtra("cursoInfo", descricao);
        intent.putExtra("cursoImagem", imagemResId);
        intent.putExtra("faculdadePertencente", faculdade);
        intent.putExtra("cursoId", idCurso);
        intent.putExtra("cargaHoraria", carga);
        intent.putExtra("diasSemana", dias);
        startActivity(intent);
    }

    private void atualizarCursosDisponiveis() {
        if (getContext() == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        Set<String> cursosInscritos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        if (cardCurso1 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_adm", false);
            cardCurso1.setVisibility(deletado || cursosInscritos.contains("adm") ? View.GONE : View.VISIBLE);
        }
        if (cardCurso2 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_logistica", false);
            cardCurso2.setVisibility(deletado || cursosInscritos.contains("logistica") ? View.GONE : View.VISIBLE);
        }
        if (cardCurso3 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_marketing", false);
            cardCurso3.setVisibility(deletado || cursosInscritos.contains("marketing") ? View.GONE : View.VISIBLE);
        }
        if (cardCurso4 != null) {
            boolean deletado = sp.getBoolean("curso_deletado_web", false);
            cardCurso4.setVisibility(deletado || cursosInscritos.contains("web") ? View.GONE : View.VISIBLE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        configurarFerramentasAdmin();
        atualizarCursosDisponiveis();
        if (getView() != null) {
            atualizarSininho(getView());
        }
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
            carouselHandler.postDelayed(carouselRunnable, 6000);
        }
    }
}