package com.example.errornull_proximaetapa.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.errornull_proximaetapa.CarouselAdapter;
import com.example.errornull_proximaetapa.NotificationHelper;
import com.example.errornull_proximaetapa.R;
import com.example.errornull_proximaetapa.RequerimentosManager;
import com.example.errornull_proximaetapa.UserSession;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class AvisosFragment extends Fragment {

    private ViewPager2 viewPagerAvisosCarousel;
    private final Handler carouselHandler = new Handler(Looper.getMainLooper());
    private Runnable carouselRunnable;
    private int currentCarouselPosition = 0;

    private View dot1, dot2, dot3;
    private Button btnCriarEvento, btnVerTodosEventos;
    private LinearLayout containerEventos;

    private CalendarView calendarViewAvisos;
    private TextView txtDataSelecionadaTitulo, txtDetalheDataCalendario;

    private View btnWhats, btnInsta, btnYt;
    private View btnSininhoNotificacoes;

    // Componentes de Requerimentos Ativos
    private Button btnNovoRequerimentoAvisos;
    private LinearLayout containerRequerimentosAtivosAvisos;

    private static final String KEY_CUSTOM_EVENTOS = "custom_eventos_string";

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_avisos, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dot1 = view.findViewById(R.id.dotAvisos1);
        dot2 = view.findViewById(R.id.dotAvisos2);
        dot3 = view.findViewById(R.id.dotAvisos3);

        btnCriarEvento = view.findViewById(R.id.btnCriarEvento);
        btnVerTodosEventos = view.findViewById(R.id.btnVerTodosEventos);
        containerEventos = view.findViewById(R.id.containerEventos);

        calendarViewAvisos = view.findViewById(R.id.calendarViewAvisos);
        txtDataSelecionadaTitulo = view.findViewById(R.id.txtDataSelecionadaTitulo);
        txtDetalheDataCalendario = view.findViewById(R.id.txtDetalheDataCalendario);

        btnWhats = view.findViewById(R.id.btnWhats);
        btnInsta = view.findViewById(R.id.btnInsta);
        btnYt = view.findViewById(R.id.btnYt);

        btnNovoRequerimentoAvisos = view.findViewById(R.id.btnNovoRequerimentoAvisos);
        containerRequerimentosAtivosAvisos = view.findViewById(R.id.containerRequerimentosAtivosAvisos);

        if (btnNovoRequerimentoAvisos != null) {
            btnNovoRequerimentoAvisos.setOnClickListener(v -> abrirFormularioRequerimentoAluno());
        }

        btnSininhoNotificacoes = view.findViewById(R.id.btnSininhoNotificacoes);
        if (btnSininhoNotificacoes != null) {
            btnSininhoNotificacoes.setOnClickListener(v -> NotificationHelper.exibirCentralNotificacoes(requireContext(), () -> atualizarSininho(view)));
        }

        inicializarCarrossel(view);
        configurarEventos();
        configurarCalendario();
        configurarContatos();
        renderizarRequerimentosAtivosAluno();
        atualizarSininho(view);
    }

    private void renderizarRequerimentosAtivosAluno() {
        if (containerRequerimentosAtivosAvisos == null || getContext() == null) return;
        containerRequerimentosAtivosAvisos.removeAllViews();

        SharedPreferences spUser = UserSession.getScopedPreferences(requireContext());
        String tipoUsuario = spUser.getString("tipoUsuario", "aluno");

        if ("admin".equalsIgnoreCase(tipoUsuario)) {
            // ADM: exibe atalho direto para o painel geral de requerimentos
            Button btnPainelAdm = new Button(requireContext());
            btnPainelAdm.setText("📬 Abrir Painel de Gestão de Requerimentos dos Alunos");
            btnPainelAdm.setBackgroundTintList(android.content.res.ColorStateList.valueOf(requireContext().getColor(R.color.yellow)));
            btnPainelAdm.setTextColor(requireContext().getColor(R.color.dark_indigo));
            btnPainelAdm.setTypeface(null, Typeface.BOLD);
            btnPainelAdm.setTextSize(12);

            btnPainelAdm.setOnClickListener(v -> RequerimentosManager.abrirPainelRequerimentosAdmin(requireContext()));
            containerRequerimentosAtivosAvisos.addView(btnPainelAdm);
            return;
        }

        // ALUNO: renderizar requerimentos ativos enviados por este aluno
        String myEmail = UserSession.getCurrentUserEmail(requireContext());
        List<String> todosReqs = RequerimentosManager.getListaRequerimentosGeral(requireContext());
        int meusReqsCount = 0;

        for (String reqStr : todosReqs) {
            String[] p = reqStr.split("\\|\\|\\|");
            String emailAluno = p.length > 1 ? p[1] : "";
            String tipoProb = p.length > 3 ? p[3] : "Solicitação";
            String relato = p.length > 4 ? p[4] : "";
            String dataHora = p.length > 5 ? p[5] : "";
            String status = p.length > 6 ? p[6] : "Pendente";
            String resposta = p.length > 7 ? p[7] : "Sem resposta da Direção ainda";

            if (emailAluno.equalsIgnoreCase(myEmail) || emailAluno.isEmpty() || myEmail.contains("convidado")) {
                meusReqsCount++;

                LinearLayout cardReq = new LinearLayout(requireContext());
                cardReq.setOrientation(LinearLayout.VERTICAL);
                cardReq.setBackgroundResource(R.drawable.bg_card_questionario);
                cardReq.setPadding(16, 14, 16, 14);

                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 4, 0, 10);
                cardReq.setLayoutParams(lp);

                TextView txtStatus = new TextView(requireContext());
                boolean isConcluido = "Respondido".equalsIgnoreCase(status) || "Concluído".equalsIgnoreCase(status);
                txtStatus.setText("📬 " + tipoProb + " • " + dataHora + "\nStatus: " + status.toUpperCase());
                txtStatus.setTextColor(requireContext().getColor(isConcluido ? R.color.mint : R.color.purple));
                txtStatus.setTextSize(12);
                txtStatus.setTypeface(null, Typeface.BOLD);

                TextView txtRelato = new TextView(requireContext());
                txtRelato.setText("💬 Seu relato: " + relato);
                txtRelato.setTextColor(requireContext().getColor(R.color.dark_indigo));
                txtRelato.setTextSize(12);

                TextView txtResp = new TextView(requireContext());
                txtResp.setText("✉️ Resposta da Direção/ADM:\n" + resposta);
                txtResp.setTextColor(requireContext().getColor(isConcluido ? R.color.dark_indigo : R.color.dark_gray));
                txtResp.setTextSize(12);
                txtResp.setPadding(0, 4, 0, 0);

                cardReq.addView(txtStatus);
                cardReq.addView(txtRelato);
                cardReq.addView(txtResp);

                containerRequerimentosAtivosAvisos.addView(cardReq);
            }
        }

        if (meusReqsCount == 0) {
            TextView txtVazio = new TextView(requireContext());
            txtVazio.setText("Você não possui nenhum requerimento ativo em andamento. Clique em '➕ Novo Requerimento' para enviar uma solicitação!");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(12);
            txtVazio.setPadding(8, 8, 8, 8);
            containerRequerimentosAtivosAvisos.addView(txtVazio);
        }
    }

    private void abrirFormularioRequerimentoAluno() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_form_requerimento_adm, null);

        Spinner spinnerTipo = dialogView.findViewById(R.id.spinnerTipoProblemaRequerimento);
        EditText inputRelato = dialogView.findViewById(R.id.inputRelatoProblemaRequerimento);
        Button btnCancelar = dialogView.findViewById(R.id.btnFecharRequerimentoForm);
        Button btnEnviar = dialogView.findViewById(R.id.btnEnviarRequerimentoForm);

        if (spinnerTipo != null) {
            String[] tiposArr = {
                    "Solicitação de Atestado / Declaração",
                    "Dúvidas sobre Matrícula / Cursos",
                    "Problema Técnico / Acesso à Plataforma",
                    "Denúncia ou Outro Assunto"
            };
            ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_dropdown_item, tiposArr);
            spinnerTipo.setAdapter(adapter);
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnCancelar != null) btnCancelar.setOnClickListener(v -> dialog.dismiss());

        if (btnEnviar != null && inputRelato != null && spinnerTipo != null) {
            btnEnviar.setOnClickListener(v -> {
                String relato = inputRelato.getText().toString().trim();
                String tipoProb = spinnerTipo.getSelectedItem() != null ? spinnerTipo.getSelectedItem().toString() : "Geral";

                if (relato.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Descreva o seu relato/solicitação!");
                    return;
                }

                SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                String email = UserSession.getCurrentUserEmail(requireContext());
                String nome = sp.getString("nome", "Estudante");

                RequerimentosManager.enviarRequerimento(requireContext(), email, nome, tipoProb, relato);
                renderizarRequerimentosAtivosAluno();
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void atualizarSininho(View view) {
        if (view == null || getContext() == null) return;
        TextView badge = view.findViewById(R.id.badgeSininhoQtd);
        int qtd = NotificationHelper.getQtdNaoLidas(requireContext());
        if (badge != null) {
            if (qtd > 0) {
                badge.setText(String.valueOf(qtd));
                badge.setVisibility(View.VISIBLE);
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    private void inicializarCarrossel(View view) {
        int[] carouselImages = new int[]{
                R.drawable.proximaetapa1,
                R.drawable.proximaetapa2,
                R.drawable.proximaetapa3
        };

        viewPagerAvisosCarousel = view.findViewById(R.id.viewPagerAvisosCarousel);
        if (viewPagerAvisosCarousel != null) {
            viewPagerAvisosCarousel.setAdapter(new CarouselAdapter(carouselImages));

            viewPagerAvisosCarousel.setPageTransformer((page, position) -> {
                float absPos = Math.abs(position);
                if (position <= -1 || position >= 1) {
                    page.setAlpha(0f);
                } else {
                    page.setTranslationX(-position * page.getWidth());
                    page.setAlpha(1f - absPos);
                    float scale = 0.95f + (1f - absPos) * 0.05f;
                    page.setScaleX(scale);
                    page.setScaleY(scale);
                }
            });

            viewPagerAvisosCarousel.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    currentCarouselPosition = position;
                    atualizarDots(position);
                }
            });

            carouselRunnable = new Runnable() {
                @Override
                public void run() {
                    if (viewPagerAvisosCarousel != null) {
                        currentCarouselPosition = (currentCarouselPosition + 1) % carouselImages.length;
                        viewPagerAvisosCarousel.setCurrentItem(currentCarouselPosition, true);
                        carouselHandler.postDelayed(this, 6000);
                    }
                }
            };

            carouselHandler.postDelayed(carouselRunnable, 6000);
        }
    }

    private void atualizarDots(int position) {
        if (dot1 == null || dot2 == null || dot3 == null) return;

        dot1.setBackgroundResource(position == 0 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot2.setBackgroundResource(position == 1 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot3.setBackgroundResource(position == 2 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);

        ViewGroup.LayoutParams p1 = dot1.getLayoutParams();
        p1.width = position == 0 ? 50 : 20;
        dot1.setLayoutParams(p1);

        ViewGroup.LayoutParams p2 = dot2.getLayoutParams();
        p2.width = position == 1 ? 50 : 20;
        dot2.setLayoutParams(p2);

        ViewGroup.LayoutParams p3 = dot3.getLayoutParams();
        p3.width = position == 2 ? 50 : 20;
        dot3.setLayoutParams(p3);
    }

    private void configurarEventos() {
        renderizarListaEventos();

        if (btnCriarEvento != null) {
            btnCriarEvento.setOnClickListener(v -> exibirDialogCriarEvento());
        }

        if (btnVerTodosEventos != null) {
            btnVerTodosEventos.setOnClickListener(v -> exibirAbaTodosEventos());
        }
    }

    private void renderizarListaEventos() {
        if (containerEventos == null || getContext() == null) return;
        containerEventos.removeAllViews();

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        List<String> listaEventos = carregarEventosSp(sp);

        if (btnVerTodosEventos != null) {
            btnVerTodosEventos.setText("🔍 Ver Todos os Eventos (" + listaEventos.size() + ")");
        }

        LayoutInflater inflater = LayoutInflater.from(getContext());

        // Limita a exibição da tela principal a no máximo 3 eventos recentes
        int limite = Math.min(3, listaEventos.size());

        for (int i = 0; i < limite; i++) {
            String eventoStr = listaEventos.get(i);
            String[] partes = eventoStr.split(";;;");
            String titulo = partes.length > 0 ? partes[0] : "Evento";
            String data = partes.length > 1 ? partes[1] : "Data A Definir";
            String desc = partes.length > 2 ? partes[2] : "";

            View eventView = inflater.inflate(R.layout.item_evento_row, containerEventos, false);
            TextView txtTitulo = eventView.findViewById(R.id.txtTituloEventoRow);
            TextView txtData = eventView.findViewById(R.id.txtDataEventoRow);
            TextView txtDesc = eventView.findViewById(R.id.txtDescEventoRow);

            if (txtTitulo != null) txtTitulo.setText(titulo);
            if (txtData != null) txtData.setText(data);
            if (txtDesc != null) txtDesc.setText(desc);

            containerEventos.addView(eventView);
        }
    }

    private void exibirAbaTodosEventos() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_lista_eventos, null);

        Button btnVoltar = dialogView.findViewById(R.id.btnVoltarListaEventos);
        LinearLayout containerBlocos = dialogView.findViewById(R.id.containerTodosEventosBlocos);

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        List<String> listaEventos = carregarEventosSp(sp);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnVoltar != null) {
            btnVoltar.setOnClickListener(v -> dialog.dismiss());
        }

        if (containerBlocos != null) {
            containerBlocos.removeAllViews();
            LayoutInflater inflater = LayoutInflater.from(getContext());

            int[] imagensExemplo = new int[]{
                    R.drawable.proximaetapa1,
                    R.drawable.proximaetapa2,
                    R.drawable.proximaetapa3
            };

            for (int i = 0; i < listaEventos.size(); i++) {
                String eventoStr = listaEventos.get(i);
                String[] partes = eventoStr.split(";;;");
                String titulo = partes.length > 0 ? partes[0] : "Evento";
                String data = partes.length > 1 ? partes[1] : "Data A Definir";
                String desc = partes.length > 2 ? partes[2] : "";

                View blocoView = inflater.inflate(R.layout.item_evento_card_bloco, containerBlocos, false);
                ImageView imgCapa = blocoView.findViewById(R.id.imgCapaEventoBloco);
                TextView txtData = blocoView.findViewById(R.id.txtDataEventoBloco);
                TextView txtTitulo = blocoView.findViewById(R.id.txtTituloEventoBloco);
                TextView txtDesc = blocoView.findViewById(R.id.txtDescEventoBloco);

                if (imgCapa != null) {
                    imgCapa.setImageResource(imagensExemplo[i % imagensExemplo.length]);
                }
                if (txtData != null) txtData.setText(data);
                if (txtTitulo != null) txtTitulo.setText(titulo);
                if (txtDesc != null) txtDesc.setText(desc.isEmpty() ? "Evento organizado pela plataforma Próxima Etapa." : desc);

                containerBlocos.addView(blocoView);
            }
        }

        dialog.show();
    }

    private List<String> carregarEventosSp(SharedPreferences sp) {
        String savedString = sp.getString(KEY_CUSTOM_EVENTOS, "");
        List<String> lista = new ArrayList<>();

        if (!savedString.isEmpty()) {
            String[] split = savedString.split("###");
            lista.addAll(Arrays.asList(split));
        } else {
            // Eventos padrão fictícios
            lista.add("Feira de Profissões Próxima Etapa 2026;;;15/04/2026;;;Conecte-se com universidades públicas e privadas e conheça opções de carreira.");
            lista.add("Palestra: Futuro da Tecnologia & IA;;;22/04/2026;;;Encontro com especialistas de TI no auditório da instituição.");
            salvarEventosSp(sp, lista);
        }

        return lista;
    }

    private void salvarEventosSp(SharedPreferences sp, List<String> lista) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista.size(); i++) {
            sb.append(lista.get(i));
            if (i < lista.size() - 1) {
                sb.append("###");
            }
        }
        sp.edit().putString(KEY_CUSTOM_EVENTOS, sb.toString()).apply();
    }

    private void exibirDialogCriarEvento() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(getContext()).inflate(R.layout.dialog_criar_evento, null);

        EditText inputTitulo = dialogView.findViewById(R.id.inputTituloEvento);
        EditText inputData = dialogView.findViewById(R.id.inputDataEvento);
        EditText inputDesc = dialogView.findViewById(R.id.inputDescricaoEvento);
        Button btnSalvar = dialogView.findViewById(R.id.btnSalvarNovoEvento);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnSalvar != null && inputTitulo != null && inputData != null && inputDesc != null) {
            btnSalvar.setOnClickListener(v -> {
                String titulo = inputTitulo.getText().toString().trim();
                String data = inputData.getText().toString().trim();
                String desc = inputDesc.getText().toString().trim();

                if (titulo.isEmpty() || data.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Preencha o título e a data do evento!");
                    return;
                }

                SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                List<String> listaAtual = carregarEventosSp(sp);

                String novoEvento = titulo + ";;;" + data + ";;;" + desc;
                listaAtual.add(0, novoEvento); // Adiciona no topo para aparecer entre os 3 mais recentes!
                salvarEventosSp(sp, listaAtual);

                NotificationHelper.adicionarNotificacao(
                        requireContext(),
                        "Novo Evento Cadastrado",
                        "O evento '" + titulo + "' foi agendado para " + data + "."
                );

                NotificationHelper.exibirToastCustomizado(
                        requireContext(),
                        "📅 Evento '" + titulo + "' cadastrado para " + data + "!"
                );

                renderizarListaEventos();
                if (getView() != null) atualizarSininho(getView());
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void configurarCalendario() {
        if (calendarViewAvisos == null) return;

        calendarViewAvisos.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            int mesReal = month + 1;
            String dataFormatada = String.format("%02d/%02d/%d", dayOfMonth, mesReal, year);

            Calendar cal = Calendar.getInstance();
            cal.set(year, month, dayOfMonth);
            int diaSemanaInt = cal.get(Calendar.DAY_OF_WEEK); // 1 = Dom, 2 = Seg, 3 = Ter, 4 = Qua, 5 = Qui, 6 = Sex, 7 = Sáb

            SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
            Set<String> cursosInscritos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

            StringBuilder detalhes = new StringBuilder();

            // Verifica aulas dos cursos inscritos
            if (!cursosInscritos.isEmpty()) {
                for (String idCurso : cursosInscritos) {
                    String nomeCurso = sp.getString("nomeCurso_" + idCurso, "");
                    if ("adm".equalsIgnoreCase(idCurso) || "marketing".equalsIgnoreCase(idCurso)) {
                        // Aulas em Seg, Qua, Sex
                        if (diaSemanaInt == Calendar.MONDAY || diaSemanaInt == Calendar.WEDNESDAY || diaSemanaInt == Calendar.FRIDAY) {
                            detalhes.append("• Aula de ").append(nomeCurso).append(" (14h - 16h)\n");
                        }
                    } else if ("logistica".equalsIgnoreCase(idCurso) || "web".equalsIgnoreCase(idCurso)) {
                        // Aulas em Ter, Qui, Sáb
                        if (diaSemanaInt == Calendar.TUESDAY || diaSemanaInt == Calendar.THURSDAY || diaSemanaInt == Calendar.SATURDAY) {
                            detalhes.append("• Aula de ").append(nomeCurso).append(" (09h - 11h)\n");
                        }
                    }
                }
            }

            // Verifica eventos agendados para a data
            List<String> eventos = carregarEventosSp(sp);
            for (String ev : eventos) {
                String[] p = ev.split(";;;");
                if (p.length > 1 && p[1].contains(String.format("%02d/%02d", dayOfMonth, mesReal))) {
                    detalhes.append("• Evento: ").append(p[0]).append("\n");
                }
            }

            if (txtDataSelecionadaTitulo != null) {
                txtDataSelecionadaTitulo.setText("Programação de " + dataFormatada);
            }

            if (txtDetalheDataCalendario != null) {
                if (detalhes.length() == 0) {
                    txtDetalheDataCalendario.setText("Nenhuma aula ou evento agendado para esta data.");
                } else {
                    txtDetalheDataCalendario.setText(detalhes.toString().trim());
                }
            }
        });
    }

    private void configurarContatos() {
        if (btnWhats != null) {
            btnWhats.setOnClickListener(v -> abrirLinkRede("https://wa.me/5511999999999", "WhatsApp Próxima Etapa: (11) 99999-9999"));
        }

        if (btnInsta != null) {
            btnInsta.setOnClickListener(v -> abrirLinkRede("https://instagram.com/proximaetapa", "Instagram: @proximaetapa"));
        }

        if (btnYt != null) {
            btnYt.setOnClickListener(v -> abrirLinkRede("https://youtube.com/proximaetapa", "YouTube: Canal Próxima Etapa"));
        }
    }

    private void abrirLinkRede(String url, String canalTexto) {
        NotificationHelper.exibirToastCustomizado(getContext(), canalTexto);
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent);
        } catch (Exception ignored) {}
    }

    @Override
    public void onPause() {
        super.onPause();
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        renderizarListaEventos();
        renderizarRequerimentosAtivosAluno();
        if (getView() != null) {
            atualizarSininho(getView());
        }
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
            carouselHandler.postDelayed(carouselRunnable, 6000);
        }
    }
}