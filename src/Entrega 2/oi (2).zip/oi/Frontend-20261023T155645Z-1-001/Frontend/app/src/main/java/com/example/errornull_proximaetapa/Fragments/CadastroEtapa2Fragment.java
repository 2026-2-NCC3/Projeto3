package com.example.errornull_proximaetapa.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.errornull_proximaetapa.Cadastro;
import com.example.errornull_proximaetapa.CadastroViewModel;
import com.example.errornull_proximaetapa.R;

public class CadastroEtapa2Fragment extends Fragment {

    private LinearLayout layoutEscolarAluno, layoutEscolarProfessor, layoutEscolarAdmin;

    // Campos Aluno
    private EditText inputEscola, inputGrade, inputCidade, inputTelefoneAluno, inputPretensaoFaculdade;

    // Campos Professor
    private EditText inputTelefoneProfessor, inputEspecialidade;

    // Campos Admin
    private EditText inputCargo;

    // Botões
    private Button btnVoltarEtapa2, btnAvancarEtapa2;

    private CadastroViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cadastro_etapa2, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity() != null) {
            viewModel = new ViewModelProvider(requireActivity()).get(CadastroViewModel.class);
            ((Cadastro) getActivity()).bloquearTabs(true);
        }

        // Sub-layouts
        layoutEscolarAluno = view.findViewById(R.id.layoutEscolarAluno);
        layoutEscolarProfessor = view.findViewById(R.id.layoutEscolarProfessor);
        layoutEscolarAdmin = view.findViewById(R.id.layoutEscolarAdmin);

        // Aluno
        inputEscola = view.findViewById(R.id.input_escola);
        inputGrade = view.findViewById(R.id.input_grade);
        inputCidade = view.findViewById(R.id.input_cidade);
        inputTelefoneAluno = view.findViewById(R.id.input_telefone_aluno);
        inputPretensaoFaculdade = view.findViewById(R.id.input_pretensao_faculdade);

        // Professor
        inputTelefoneProfessor = view.findViewById(R.id.input_telefone_professor);
        inputEspecialidade = view.findViewById(R.id.input_especialidade);

        // Admin
        inputCargo = view.findViewById(R.id.input_cargo);

        // Botões
        btnVoltarEtapa2 = view.findViewById(R.id.btnVoltarEtapa2);
        btnAvancarEtapa2 = view.findViewById(R.id.btnAvancarEtapa2);

        // Preencher dados salvos
        if (viewModel != null) {
            if (inputEscola != null) inputEscola.setText(viewModel.getEscola());
            if (inputGrade != null) inputGrade.setText(viewModel.getGrade());
            if (inputCidade != null) inputCidade.setText(viewModel.getCidade());
            if (inputTelefoneAluno != null) inputTelefoneAluno.setText(viewModel.getTelefoneAluno());
            if (inputPretensaoFaculdade != null) inputPretensaoFaculdade.setText(viewModel.getPretensaoFaculdade());

            if (inputTelefoneProfessor != null) inputTelefoneProfessor.setText(viewModel.getTelefoneProfessor());
            if (inputEspecialidade != null) inputEspecialidade.setText(viewModel.getEspecialidade());

            if (inputCargo != null) inputCargo.setText(viewModel.getCargo());

            atualizarVisibilidadeTipo(viewModel.getTipoUsuario());
        }

        btnVoltarEtapa2.setOnClickListener(v -> {
            salvarDados();
            if (getActivity() instanceof Cadastro) {
                ((Cadastro) getActivity()).navegarParaEtapa(1);
            }
        });

        btnAvancarEtapa2.setOnClickListener(v -> {
            salvarDados();
            if (getActivity() instanceof Cadastro) {
                ((Cadastro) getActivity()).navegarParaEtapa(3);
            }
        });
    }

    public void atualizarVisibilidadeTipo(String tipo) {
        if (layoutEscolarAluno == null || layoutEscolarProfessor == null || layoutEscolarAdmin == null) return;

        layoutEscolarAluno.setVisibility(View.GONE);
        layoutEscolarProfessor.setVisibility(View.GONE);
        layoutEscolarAdmin.setVisibility(View.GONE);

        if ("professor".equalsIgnoreCase(tipo)) {
            layoutEscolarProfessor.setVisibility(View.VISIBLE);
        } else if ("admin".equalsIgnoreCase(tipo)) {
            layoutEscolarAdmin.setVisibility(View.VISIBLE);
        } else {
            layoutEscolarAluno.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        salvarDados();
    }

    private void salvarDados() {
        if (viewModel == null) return;

        if (inputEscola != null) viewModel.setEscola(inputEscola.getText().toString().trim());
        if (inputGrade != null) viewModel.setGrade(inputGrade.getText().toString().trim());
        if (inputCidade != null) viewModel.setCidade(inputCidade.getText().toString().trim());
        if (inputTelefoneAluno != null) viewModel.setTelefoneAluno(inputTelefoneAluno.getText().toString().trim());
        if (inputPretensaoFaculdade != null) viewModel.setPretensaoFaculdade(inputPretensaoFaculdade.getText().toString().trim());

        if (inputTelefoneProfessor != null) viewModel.setTelefoneProfessor(inputTelefoneProfessor.getText().toString().trim());
        if (inputEspecialidade != null) viewModel.setEspecialidade(inputEspecialidade.getText().toString().trim());

        if (inputCargo != null) viewModel.setCargo(inputCargo.getText().toString().trim());
    }
}