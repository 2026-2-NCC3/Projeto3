package com.example.errornull_proximaetapa;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;

public class UserSession {

    private static final String SESSION_PREF = "UserSessionManager";
    private static final String KEY_CURRENT_USER_EMAIL = "CURRENT_USER_EMAIL";

    public static void setUsuarioAtual(Context context, String email) {
        if (email == null || email.trim().isEmpty()) {
            email = "usuario_convidado";
        }
        SharedPreferences sp = context.getSharedPreferences(SESSION_PREF, Context.MODE_PRIVATE);
        sp.edit().putString(KEY_CURRENT_USER_EMAIL, email.toLowerCase().trim()).apply();
    }

    public static String getUsuarioAtual(Context context) {
        SharedPreferences sp = context.getSharedPreferences(SESSION_PREF, Context.MODE_PRIVATE);
        return sp.getString(KEY_CURRENT_USER_EMAIL, "usuario_convidado");
    }

    public static String getCurrentUserEmail(Context context) {
        return getUsuarioAtual(context);
    }

    public static void logout(Context context) {
        if (context == null) return;
        SharedPreferences sp = context.getSharedPreferences(SESSION_PREF, Context.MODE_PRIVATE);
        sp.edit().clear().apply();
    }

    public static SharedPreferences getScopedPreferences(Context context) {
        String emailAtual = getUsuarioAtual(context);
        String prefName = "PerfilUsuario_" + emailAtual.replaceAll("[^a-zA-Z0-9]", "_");
        return context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
    }

    public static SharedPreferences getScopedPreferencesForUser(Context context, String email) {
        if (context == null || email == null || email.trim().isEmpty()) {
            return getScopedPreferences(context);
        }
        String cleanEmail = email.toLowerCase().trim();
        String prefName = "PerfilUsuario_" + cleanEmail.replaceAll("[^a-zA-Z0-9]", "_");
        return context.getSharedPreferences(prefName, Context.MODE_PRIVATE);
    }

    public static void aplicarPreferenciasTema(Context context) {
        if (context == null) return;
        SharedPreferences sp = getScopedPreferences(context);
        boolean temaEscuro = sp.getBoolean("config_tema_escuro", false);

        if (temaEscuro) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}