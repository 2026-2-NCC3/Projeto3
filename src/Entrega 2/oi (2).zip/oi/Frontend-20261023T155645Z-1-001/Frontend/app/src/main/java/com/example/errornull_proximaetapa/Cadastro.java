package com.example.errornull_proximaetapa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.errornull_proximaetapa.Fragments.CadastroEtapa1Fragment;
import com.example.errornull_proximaetapa.Fragments.CadastroEtapa2Fragment;
import com.example.errornull_proximaetapa.Fragments.CadastroEtapa3Fragment;
import com.example.errornull_proximaetapa.peServices.ApiService;
import com.example.errornull_proximaetapa.peServices.CadastroRequest;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Cadastro extends AppCompatActivity {

    private TextView tabAluno, tabProf, tabAdm;
    private TextView txtIndicadorEtapa;
    private Button btnIrLogin;

    private CadastroViewModel viewModel;
    private ApiService api;
    private boolean abasBloqueadas = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela_cadastro);

        viewModel = new ViewModelProvider(this).get(CadastroViewModel.class);

        inicializarViews();
        configurarNavegacaoAbas();
        configurarRetrofit();

        // Inicia na Etapa 1
        navegarParaEtapa(1);
    }

    private void inicializarViews() {
        tabAluno = findViewById(R.id.tab_aluno);
        tabProf = findViewById(R.id.tab_prof);
        tabAdm = findViewById(R.id.tab_adm);
        txtIndicadorEtapa = findViewById(R.id.txtIndicadorEtapa);
        btnIrLogin = findViewById(R.id.btn_ir_login);

        if (btnIrLogin != null) {
            btnIrLogin.setOnClickListener(v -> {
                startActivity(new Intent(Cadastro.this, LoginInfo.class));
                finish();
            });
        }
    }

    private void configurarNavegacaoAbas() {
        if (tabAluno != null) tabAluno.setOnClickListener(v -> selecionarTipoUsuario("aluno"));
        if (tabProf != null) tabProf.setOnClickListener(v -> selecionarTipoUsuario("professor"));
        if (tabAdm != null) tabAdm.setOnClickListener(v -> selecionarTipoUsuario("admin"));
    }

    public void bloquearTabs(boolean bloquear) {
        this.abasBloqueadas = bloquear;
        if (tabAluno == null || tabProf == null || tabAdm == null) return;

        if (bloquear) {
            tabAluno.setAlpha(0.6f);
            tabProf.setAlpha(0.6f);
            tabAdm.setAlpha(0.6f);
        } else {
            tabAluno.setAlpha(1.0f);
            tabProf.setAlpha(1.0f);
            tabAdm.setAlpha(1.0f);
        }
    }

    public void selecionarTipoUsuario(String tipo) {
        if (abasBloqueadas) {
            Toast.makeText(this, "O tipo de conta não pode ser alterado após iniciar o preenchimento.", Toast.LENGTH_SHORT).show();
            return;
        }

        viewModel.setTipoUsuario(tipo);

        if (tabAluno == null || tabProf == null || tabAdm == null) return;

        tabAluno.setBackgroundResource(R.drawable.bg_tab_unselected);
        tabAluno.setTextColor(getColor(R.color.dark_indigo));

        tabProf.setBackgroundResource(R.drawable.bg_tab_unselected);
        tabProf.setTextColor(getColor(R.color.dark_indigo));

        tabAdm.setBackgroundResource(R.drawable.bg_tab_unselected);
        tabAdm.setTextColor(getColor(R.color.dark_indigo));

        if ("professor".equalsIgnoreCase(tipo)) {
            tabProf.setBackgroundResource(R.drawable.bg_tab_selected);
            tabProf.setTextColor(getColor(R.color.white));
        } else if ("admin".equalsIgnoreCase(tipo)) {
            tabAdm.setBackgroundResource(R.drawable.bg_tab_selected);
            tabAdm.setTextColor(getColor(R.color.white));
        } else {
            tabAluno.setBackgroundResource(R.drawable.bg_tab_selected);
            tabAluno.setTextColor(getColor(R.color.white));
        }

        Fragment activeFragment = getSupportFragmentManager().findFragmentById(R.id.fragment_container_cadastro);
        if (activeFragment instanceof CadastroEtapa2Fragment) {
            ((CadastroEtapa2Fragment) activeFragment).atualizarVisibilidadeTipo(tipo);
        }
    }

    public void navegarParaEtapa(int etapa) {
        Fragment fragment;
        if (etapa == 1) {
            fragment = new CadastroEtapa1Fragment();
            if (txtIndicadorEtapa != null) txtIndicadorEtapa.setText("Parte 1 de 3: Informações Pessoais");
        } else if (etapa == 2) {
            bloquearTabs(true); // Bloqueia abas ao passar para a Parte 2
            fragment = new CadastroEtapa2Fragment();
            if (txtIndicadorEtapa != null) txtIndicadorEtapa.setText("Parte 2 de 3: Informações Escolares");
        } else {
            bloquearTabs(true); // Bloqueia abas ao passar para a Parte 3
            fragment = new CadastroEtapa3Fragment();
            if (txtIndicadorEtapa != null) txtIndicadorEtapa.setText("Parte 3 de 3: Personalização de Perfil");
        }

        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(android.R.anim.fade_in, android.R.anim.fade_out)
                .replace(R.id.fragment_container_cadastro, fragment)
                .commit();
    }

    private void configurarRetrofit() {
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://pi3-kc5f.onrender.com/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(ApiService.class);
    }

    public void executarCadastroFinal() {
        String cpf = viewModel.getCpf();
        String nome = viewModel.getNome();
        String email = viewModel.getEmail();
        String senha = viewModel.getSenha();
        String tipoUsuario = viewModel.getTipoUsuario();

        if (cpf.isEmpty() || nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            Toast.makeText(Cadastro.this, "Preencha os campos obrigatórios na Parte 1!", Toast.LENGTH_SHORT).show();
            navegarParaEtapa(1);
            return;
        }

        String telAluno = null, escola = null, cidade = null, grade = null;
        String telProf = null, especialidade = null, cargo = null;

        if ("aluno".equals(tipoUsuario)) {
            telAluno = viewModel.getTelefoneAluno();
            escola = viewModel.getEscola();
            cidade = viewModel.getCidade();
            grade = viewModel.getGrade();
        } else if ("professor".equals(tipoUsuario)) {
            telProf = viewModel.getTelefoneProfessor();
            especialidade = viewModel.getEspecialidade();
        } else if ("admin".equals(tipoUsuario)) {
            cargo = viewModel.getCargo();
        }

        // Define a sessão do usuário recém-cadastrado
        UserSession.setUsuarioAtual(Cadastro.this, email);

        // Salvar dados do perfil no SharedPreferences exclusivo do usuário
        SharedPreferences sp = UserSession.getScopedPreferences(Cadastro.this);
        sp.edit()
                .putString("nome", nome)
                .putString("email", email)
                .putString("cpf", cpf)
                .putString("tipoUsuario", tipoUsuario)
                .putString("idade", viewModel.getIdade())
                .putString("estado", viewModel.getEstado())
                .putString("escola", escola)
                .putString("grade", grade)
                .putString("cidade", cidade)
                .putString("pretensaoFaculdade", viewModel.getPretensaoFaculdade())
                .putString("bio", viewModel.getBio())
                .putString("preferencias", viewModel.getPreferencias())
                .putString("foto_perfil_uri", viewModel.getFotoUri())
                .apply();

        CadastroRequest request = new CadastroRequest(
                cpf, nome, email, senha, tipoUsuario,
                telAluno, escola, cidade, grade,
                telProf, especialidade, cargo
        );

        api.fazerCadastro(request).enqueue(new Callback<Object>() {
            @Override
            public void onResponse(Call<Object> call, Response<Object> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(Cadastro.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Cadastro.this, LoginInfo.class));
                    finish();
                } else {
                    Toast.makeText(Cadastro.this, "Erro ao cadastrar no servidor. Dados salvos localmente.", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Cadastro.this, LoginInfo.class));
                    finish();
                }
            }

            @Override
            public void onFailure(Call<Object> call, Throwable t) {
                Toast.makeText(Cadastro.this, "Erro de conexão. Cadastro salvo localmente.", Toast.LENGTH_SHORT).show();
                Log.e("API_ERRO", "Falha: " + t.getMessage());
                startActivity(new Intent(Cadastro.this, LoginInfo.class));
                finish();
            }
        });
    }
}