package com.example.errornull_proximaetapa.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.errornull_proximaetapa.CardImageSaver;
import com.example.errornull_proximaetapa.GamificationManager;
import com.example.errornull_proximaetapa.NotificationHelper;
import com.example.errornull_proximaetapa.PerfilFaculdadeActivity;
import com.example.errornull_proximaetapa.R;
import com.example.errornull_proximaetapa.UserSession;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PerfilFragment extends Fragment {

    private ImageView imgFotoPerfil;
    private TextView txtNomePerfil, txtTipoPerfil, txtTituloEquipadoPerfil;
    private TextView txtIdadePerfil, txtFaculdadePerfil;
    private TextView txtBioPerfil, txtPreferenciasPerfil;
    private View containerFotoPerfil, btnAlterarFoto;
    private Button btnVerCardPerfil;
    private LinearLayout containerCertificadosPerfil;
    private View btnSininhoNotificacoes;

    // Botões do Menu de Atalhos do Estudante
    private Button btnMenuCertificados, btnMenuReservas, btnMenuCursos, btnMenuTestes, btnMenuEditarPerfil;

    // Elementos de Gamificação & Conquistas
    private View cardGamificacaoContainer;
    private TextView txtNivelGamificacao;
    private Button btnPersonalizarTituloPerfil;

    private TextView txtCircleIconPrimeiroPasso, txtLabelPrimeiroPasso, txtReqPrimeiroPassoStatus;
    private TextView txtCircleIconExplorador, txtLabelExplorador, txtReqExploradorStatus;
    private TextView txtCircleIconDedicado, txtLabelDedicado, txtReqDedicadoStatus;
    private TextView txtCircleIconMestre, txtLabelMestre, txtReqMestreStatus;

    private View headerFaculdadesSeguidasPerfil, headerCertificadosPerfil;
    private LinearLayout containerListaFaculdadesSeguidasPerfil;

    private String avatarSelecionadoTemp = "preset:round_person";

    // Launcher para trocar a foto diretamente no Perfil
    private final ActivityResultLauncher<String> changeImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    try {
                        requireContext().getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {}

                    if (imgFotoPerfil != null) {
                        imgFotoPerfil.setImageURI(uri);
                    }

                    if (getContext() != null) {
                        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                        sp.edit().putString("foto_perfil_uri", uri.toString()).apply();
                        NotificationHelper.adicionarNotificacao(requireContext(), "Perfil Atualizado", "Sua foto de perfil foi atualizada com sucesso!");
                        if (getView() != null) atualizarSininho(getView());
                    }

                    Toast.makeText(getContext(), "Foto de perfil atualizada!", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_perfil, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        imgFotoPerfil = view.findViewById(R.id.imgFotoPerfil);
        txtNomePerfil = view.findViewById(R.id.txtNomePerfil);
        txtTipoPerfil = view.findViewById(R.id.txtTipoPerfil);
        txtTituloEquipadoPerfil = view.findViewById(R.id.txtTituloEquipadoPerfil);
        txtIdadePerfil = view.findViewById(R.id.txtIdadePerfil);
        txtFaculdadePerfil = view.findViewById(R.id.txtFaculdadePerfil);
        txtBioPerfil = view.findViewById(R.id.txtBioPerfil);
        txtPreferenciasPerfil = view.findViewById(R.id.txtPreferenciasPerfil);
        containerFotoPerfil = view.findViewById(R.id.containerFotoPerfil);
        btnAlterarFoto = view.findViewById(R.id.btnAlterarFoto);
        btnVerCardPerfil = view.findViewById(R.id.btnVerCardPerfil);
        containerCertificadosPerfil = view.findViewById(R.id.containerCertificadosPerfil);

        // Bindings do Menu de Atalhos do Estudante
        btnMenuCertificados = view.findViewById(R.id.btnMenuCertificados);
        btnMenuReservas = view.findViewById(R.id.btnMenuReservas);
        btnMenuCursos = view.findViewById(R.id.btnMenuCursos);
        btnMenuTestes = view.findViewById(R.id.btnMenuTestes);
        btnMenuEditarPerfil = view.findViewById(R.id.btnMenuEditarPerfil);

        if (btnMenuCertificados != null) btnMenuCertificados.setOnClickListener(v -> exibirDialogCertificadosMenu());
        if (btnMenuReservas != null) btnMenuReservas.setOnClickListener(v -> exibirDialogMinhasReservasMenu());
        if (btnMenuCursos != null) btnMenuCursos.setOnClickListener(v -> exibirDialogMeusCursosMenu());
        if (btnMenuTestes != null) btnMenuTestes.setOnClickListener(v -> exibirDialogMeusTestesMenu());
        if (btnMenuEditarPerfil != null) btnMenuEditarPerfil.setOnClickListener(v -> exibirDialogEditarPerfilAluno());

        // Bindings de Gamificação & Conquistas
        cardGamificacaoContainer = view.findViewById(R.id.cardGamificacaoContainer);
        txtNivelGamificacao = view.findViewById(R.id.txtNivelGamificacao);
        btnPersonalizarTituloPerfil = view.findViewById(R.id.btnPersonalizarTituloPerfil);

        txtCircleIconPrimeiroPasso = view.findViewById(R.id.txtCircleIconPrimeiroPasso);
        txtLabelPrimeiroPasso = view.findViewById(R.id.txtLabelPrimeiroPasso);
        txtReqPrimeiroPassoStatus = view.findViewById(R.id.txtReqPrimeiroPassoStatus);

        txtCircleIconExplorador = view.findViewById(R.id.txtCircleIconExplorador);
        txtLabelExplorador = view.findViewById(R.id.txtLabelExplorador);
        txtReqExploradorStatus = view.findViewById(R.id.txtReqExploradorStatus);

        txtCircleIconDedicado = view.findViewById(R.id.txtCircleIconDedicado);
        txtLabelDedicado = view.findViewById(R.id.txtLabelDedicado);
        txtReqDedicadoStatus = view.findViewById(R.id.txtReqDedicadoStatus);

        txtCircleIconMestre = view.findViewById(R.id.txtCircleIconMestre);
        txtLabelMestre = view.findViewById(R.id.txtLabelMestre);
        txtReqMestreStatus = view.findViewById(R.id.txtReqMestreStatus);

        headerFaculdadesSeguidasPerfil = view.findViewById(R.id.headerFaculdadesSeguidasPerfil);
        headerCertificadosPerfil = view.findViewById(R.id.headerCertificadosPerfil);
        containerListaFaculdadesSeguidasPerfil = view.findViewById(R.id.containerListaFaculdadesSeguidasPerfil);

        btnSininhoNotificacoes = view.findViewById(R.id.btnSininhoNotificacoes);
        if (btnSininhoNotificacoes != null) {
            btnSininhoNotificacoes.setOnClickListener(v -> NotificationHelper.exibirCentralNotificacoes(requireContext(), () -> atualizarSininho(view)));
        }

        View.OnClickListener listenerFoto = v -> exibirDialogEditarPerfilAluno();
        if (containerFotoPerfil != null) containerFotoPerfil.setOnClickListener(listenerFoto);
        if (btnAlterarFoto != null) btnAlterarFoto.setOnClickListener(listenerFoto);

        if (btnVerCardPerfil != null) {
            btnVerCardPerfil.setOnClickListener(v -> CardImageSaver.exibirCardEstudanteDialog(requireContext()));
        }

        if (btnPersonalizarTituloPerfil != null) {
            btnPersonalizarTituloPerfil.setOnClickListener(v -> exibirDialogPersonalizarTitulo());
        }

        carregarDadosPerfil(view);
    }

    private void exibirDialogCertificadosMenu() {
        if (getContext() == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        Set<String> setCursos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        if (setCursos.isEmpty()) {
            NotificationHelper.exibirToastCustomizado(getContext(), "Você ainda não possui certificados concluídos.");
            return;
        }

        String cursoExemplo = setCursos.iterator().next();
        String nomeCurso = sp.getString("nomeCurso_" + cursoExemplo, "Desenvolvimento Web & TI");
        String faculdade = sp.getString("faculdadeCurso_" + cursoExemplo, "USP");
        CardImageSaver.exibirCertificadoDialog(requireContext(), nomeCurso, faculdade);
    }

    private void exibirDialogMinhasReservasMenu() {
        if (getContext() == null) return;

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        Set<String> setCursos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundResource(R.drawable.bg_card_questionario);
        layout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(requireContext());
        title.setText("📖 Minhas Reservas de Cursos");
        title.setTextColor(requireContext().getColor(R.color.dark_indigo));
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);

        if (setCursos.isEmpty()) {
            TextView txtVazio = new TextView(requireContext());
            txtVazio.setText("Nenhuma reserva de curso ativa no momento.");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(13);
            txtVazio.setPadding(0, 16, 0, 16);
            layout.addView(txtVazio);
        } else {
            for (String idC : setCursos) {
                String nome = sp.getString("nomeCurso_" + idC, "Curso");
                String faculdade = sp.getString("faculdadeCurso_" + idC, "USP");
                String prazo = sp.getString("prazoReserva_" + idC, "Até 15/05/2026");

                TextView itemR = new TextView(requireContext());
                itemR.setText("📖 " + nome + " (" + faculdade + ")\n• Período de Reserva: " + prazo + "\nStatus: Vaga Garantida ✓");
                itemR.setTextColor(requireContext().getColor(R.color.dark_indigo));
                itemR.setTextSize(13);
                itemR.setBackgroundResource(R.drawable.bg_card_questionario);
                itemR.setPadding(16, 12, 16, 12);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 8, 0, 8);
                itemR.setLayoutParams(lp);

                layout.addView(itemR);
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(layout)
                .setPositiveButton("Fechar", null)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    private void exibirDialogMeusCursosMenu() {
        if (getContext() == null) return;

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
        Set<String> setCursos = sp.getStringSet("lista_cursos_ids", new HashSet<>());

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundResource(R.drawable.bg_card_questionario);
        layout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(requireContext());
        title.setText("📚 Meus Cursos (Concluídos e Em Progresso)");
        title.setTextColor(requireContext().getColor(R.color.dark_indigo));
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);

        if (setCursos.isEmpty()) {
            TextView txtVazio = new TextView(requireContext());
            txtVazio.setText("Você não está matriculado em nenhum curso ainda.");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(13);
            txtVazio.setPadding(0, 16, 0, 16);
            layout.addView(txtVazio);
        } else {
            for (String idC : setCursos) {
                String nome = sp.getString("nomeCurso_" + idC, "Curso");
                String faculdade = sp.getString("faculdadeCurso_" + idC, "USP");
                int progresso = sp.getInt("progressoCurso_" + idC, 0);

                boolean concluido = progresso >= 100;

                TextView itemC = new TextView(requireContext());
                itemC.setText((concluido ? "🎓 [CONCLUÍDO] " : "⏳ [EM PROGRESSO " + progresso + "%] ") + nome + " (" + faculdade + ")");
                itemC.setTextColor(requireContext().getColor(concluido ? R.color.mint : R.color.dark_indigo));
                itemC.setTextSize(13);
                itemC.setTypeface(null, Typeface.BOLD);
                itemC.setBackgroundResource(R.drawable.bg_card_questionario);
                itemC.setPadding(16, 12, 16, 12);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 8, 0, 8);
                itemC.setLayoutParams(lp);

                layout.addView(itemC);
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(layout)
                .setPositiveButton("Fechar", null)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    private void exibirDialogMeusTestesMenu() {
        if (getContext() == null) return;

        LinearLayout layout = new LinearLayout(requireContext());
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundResource(R.drawable.bg_card_questionario);
        layout.setPadding(40, 40, 40, 40);

        TextView title = new TextView(requireContext());
        title.setText("🧠 Meus Testes & Questionários Externos");
        title.setTextColor(requireContext().getColor(R.color.purple));
        title.setTextSize(16);
        title.setTypeface(null, Typeface.BOLD);
        layout.addView(title);

        TextView t1 = new TextView(requireContext());
        t1.setText("📝 Questionário Vocacional - Lógica & TI (Concluído)");
        t1.setTextColor(requireContext().getColor(R.color.dark_indigo));
        t1.setTextSize(13);
        t1.setBackgroundResource(R.drawable.bg_card_questionario);
        t1.setPadding(16, 12, 16, 12);
        LinearLayout.LayoutParams lp1 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp1.setMargins(0, 12, 0, 8);
        t1.setLayoutParams(lp1);

        TextView t2 = new TextView(requireContext());
        t2.setText("📝 Teste de Aptidão Acadêmica (Pendente)");
        t2.setTextColor(requireContext().getColor(R.color.dark_indigo));
        t2.setTextSize(13);
        t2.setBackgroundResource(R.drawable.bg_card_questionario);
        t2.setPadding(16, 12, 16, 12);
        LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp2.setMargins(0, 0, 0, 8);
        t2.setLayoutParams(lp2);

        layout.addView(t1);
        layout.addView(t2);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(layout)
                .setPositiveButton("Fechar", null)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        dialog.show();
    }

    private void atualizarSininho(View view) {
        if (view == null || getContext() == null) return;
        TextView badge = view.findViewById(R.id.badgeSininhoQtd);
        int qtd = NotificationHelper.getQtdNaoLidas(requireContext());
        if (badge != null) {
            if (qtd > 0) {
                badge.setText(String.valueOf(qtd));
                badge.setVisibility(View.VISIBLE);
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    private void exibirDialogEditarPerfilAluno() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_editar_perfil_aluno, null);

        ImageView imgPreview = dialogView.findViewById(R.id.imgAvatarPreviewEditarDialog);
        Button btnEnviarGaleria = dialogView.findViewById(R.id.btnEnviarFotoGaleriaEditarDialog);

        ImageView opt1 = dialogView.findViewById(R.id.avatarOpt1Editar);
        ImageView opt2 = dialogView.findViewById(R.id.avatarOpt2Editar);
        ImageView opt3 = dialogView.findViewById(R.id.avatarOpt3Editar);

        EditText inputNome = dialogView.findViewById(R.id.inputNomeEditar);
        EditText inputIdade = dialogView.findViewById(R.id.inputIdadeEditar);
        EditText inputBio = dialogView.findViewById(R.id.inputBioEditar);
        EditText inputPreferencias = dialogView.findViewById(R.id.inputPreferenciasEditar);
        Button btnCancelar = dialogView.findViewById(R.id.btnCancelarEditarPerfil);
        Button btnSalvar = dialogView.findViewById(R.id.btnSalvarEditarPerfil);

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

        String fotoUriAtual = sp.getString("foto_perfil_uri", "preset:round_person");
        avatarSelecionadoTemp = fotoUriAtual;
        carregarImagemElemento(imgPreview, fotoUriAtual);

        if (inputNome != null) inputNome.setText(sp.getString("nome", ""));
        if (inputIdade != null) inputIdade.setText(sp.getString("idade", "17 anos"));
        if (inputBio != null) inputBio.setText(sp.getString("bio", ""));
        if (inputPreferencias != null) inputPreferencias.setText(sp.getString("preferencias", ""));

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnEnviarGaleria != null) {
            btnEnviarGaleria.setOnClickListener(v -> {
                changeImageLauncher.launch("image/*");
                dialog.dismiss();
            });
        }

        if (opt1 != null) {
            opt1.setOnClickListener(v -> {
                avatarSelecionadoTemp = "preset:round_person";
                if (imgPreview != null) imgPreview.setImageResource(R.drawable.round_person);
            });
        }

        if (opt2 != null) {
            opt2.setOnClickListener(v -> {
                avatarSelecionadoTemp = "preset:baseline_account";
                if (imgPreview != null) imgPreview.setImageResource(R.drawable.baseline_account);
            });
        }

        if (opt3 != null) {
            opt3.setOnClickListener(v -> {
                avatarSelecionadoTemp = "preset:logo_proxima_etapa";
                if (imgPreview != null) imgPreview.setImageResource(R.drawable.logo_proxima_etapa);
            });
        }

        if (btnCancelar != null) {
            btnCancelar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnSalvar != null) {
            btnSalvar.setOnClickListener(v -> {
                String novoNome = inputNome != null ? inputNome.getText().toString().trim() : "";
                String novaIdade = inputIdade != null ? inputIdade.getText().toString().trim() : "17 anos";
                String novaBio = inputBio != null ? inputBio.getText().toString().trim() : "";
                String novasPreferencias = inputPreferencias != null ? inputPreferencias.getText().toString().trim() : "";

                if (novoNome.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Digite seu nome!");
                    return;
                }

                sp.edit()
                        .putString("nome", novoNome)
                        .putString("idade", novaIdade)
                        .putString("bio", novaBio)
                        .putString("preferencias", novasPreferencias)
                        .putString("foto_perfil_uri", avatarSelecionadoTemp)
                        .apply();

                NotificationHelper.exibirToastCustomizado(getContext(), "Perfil e foto atualizados!");
                if (getView() != null) carregarDadosPerfil(getView());
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void aplicarFotoPreset(String presetKey, int drawableResId) {
        if (imgFotoPerfil != null) {
            imgFotoPerfil.setImageResource(drawableResId);
        }
        if (getContext() != null) {
            SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
            sp.edit().putString("foto_perfil_uri", presetKey).apply();
            NotificationHelper.adicionarNotificacao(requireContext(), "Perfil Atualizado", "Avatar do perfil alterado.");
            if (getView() != null) atualizarSininho(getView());
        }
        Toast.makeText(getContext(), "Avatar de perfil atualizado!", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getView() != null) {
            carregarDadosPerfil(getView());
        }
    }

    private void carregarDadosPerfil(View view) {
        if (getContext() == null) return;

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

        String nome = sp.getString("nome", "Nome do Usuário");
        String tipoUsuario = sp.getString("tipoUsuario", "aluno");
        String idade = sp.getString("idade", "17 anos");
        String pretensaoFaculdade = sp.getString("pretensaoFaculdade", "Ciência da Computação / USP");
        String bio = sp.getString("bio", "Nenhuma biografia informada ainda.");
        String preferencias = sp.getString("preferencias", "Nenhuma preferência cadastrada.");
        String fotoUri = sp.getString("foto_perfil_uri", "");

        int countCursosInscritos = sp.getInt("cursosInscritosCount", 0);

        if (txtNomePerfil != null) txtNomePerfil.setText(nome);

        // Ajuste das Informações do Perfil conforme o papel (Aluno vs Professor vs ADM)
        if ("admin".equalsIgnoreCase(tipoUsuario)) {
            if (txtTipoPerfil != null) {
                txtTipoPerfil.setText("👑 ÁREA DO ADMINISTRADOR");
                txtTipoPerfil.setBackgroundResource(R.drawable.bg_pill_purple);
                txtTipoPerfil.setTextColor(requireContext().getColor(R.color.white));
            }
            if (txtTituloEquipadoPerfil != null) txtTituloEquipadoPerfil.setVisibility(View.GONE);
            if (cardGamificacaoContainer != null) cardGamificacaoContainer.setVisibility(View.GONE);
            if (txtIdadePerfil != null) txtIdadePerfil.setText("Cargo: Administrador Geral da Plataforma");
            if (txtFaculdadePerfil != null) txtFaculdadePerfil.setVisibility(View.GONE);
            if (btnVerCardPerfil != null) btnVerCardPerfil.setVisibility(View.GONE);
            if (headerCertificadosPerfil != null) headerCertificadosPerfil.setVisibility(View.GONE);
            if (containerCertificadosPerfil != null) containerCertificadosPerfil.setVisibility(View.GONE);

            if (headerFaculdadesSeguidasPerfil != null) headerFaculdadesSeguidasPerfil.setVisibility(View.GONE);
            if (containerListaFaculdadesSeguidasPerfil != null) containerListaFaculdadesSeguidasPerfil.setVisibility(View.GONE);

        } else if ("professor".equalsIgnoreCase(tipoUsuario)) {
            if (txtTipoPerfil != null) {
                txtTipoPerfil.setText("👨‍🏫 ÁREA DO PROFESSOR");
                txtTipoPerfil.setBackgroundResource(R.drawable.bg_pill_green);
                txtTipoPerfil.setTextColor(requireContext().getColor(R.color.white));
            }
            if (txtTituloEquipadoPerfil != null) txtTituloEquipadoPerfil.setVisibility(View.GONE);
            if (cardGamificacaoContainer != null) cardGamificacaoContainer.setVisibility(View.GONE);
            if (txtIdadePerfil != null) txtIdadePerfil.setText("Cargo: Docente / Gestor Acadêmico");
            if (txtFaculdadePerfil != null) txtFaculdadePerfil.setVisibility(View.GONE);
            if (btnVerCardPerfil != null) btnVerCardPerfil.setVisibility(View.GONE);
            if (headerCertificadosPerfil != null) headerCertificadosPerfil.setVisibility(View.GONE);
            if (containerCertificadosPerfil != null) containerCertificadosPerfil.setVisibility(View.GONE);

            if (headerFaculdadesSeguidasPerfil != null) headerFaculdadesSeguidasPerfil.setVisibility(View.GONE);
            if (containerListaFaculdadesSeguidasPerfil != null) containerListaFaculdadesSeguidasPerfil.setVisibility(View.GONE);

        } else {
            // ALUNO EXCLUSIVO COM SISTEMA DE GAMIFICAÇÃO & CONQUISTAS
            if (txtTipoPerfil != null) {
                txtTipoPerfil.setText("🎓 ÁREA DO ALUNO");
                txtTipoPerfil.setBackgroundResource(R.drawable.bg_pill_yellow);
                txtTipoPerfil.setTextColor(requireContext().getColor(R.color.dark_indigo));
            }

            // Exibe o Título Equipado pelo Aluno no Topo do Perfil
            String tituloEquipado = GamificationManager.getTituloEquipado(requireContext());
            if (txtTituloEquipadoPerfil != null) {
                txtTituloEquipadoPerfil.setText(tituloEquipado);
                txtTituloEquipadoPerfil.setVisibility(View.VISIBLE);
            }

            // Exibe as Conquistas e Requisitos em Tempo Real
            int xpTotais = GamificationManager.getXpTotais(requireContext());
            int nivelAtual = GamificationManager.getNivelAtual(requireContext());

            if (cardGamificacaoContainer != null) cardGamificacaoContainer.setVisibility(View.VISIBLE);
            if (txtNivelGamificacao != null) txtNivelGamificacao.setText("Nível " + nivelAtual + " • " + xpTotais + " XP");

            atualizarConquistasEBarraStatus(requireContext());

            if (txtIdadePerfil != null) txtIdadePerfil.setText("Idade: " + idade);

            if (txtFaculdadePerfil != null) {
                txtFaculdadePerfil.setVisibility(View.VISIBLE);
                String textoInscricoes = countCursosInscritos > 0
                        ? "Cursos Cadastrados/Inscritos: " + countCursosInscritos + " curso(s)"
                        : "Pretensão / Meta: " + pretensaoFaculdade;
                txtFaculdadePerfil.setText(textoInscricoes);
            }

            if (btnVerCardPerfil != null) {
                btnVerCardPerfil.setText("✏️ Editar Informações do Perfil");
                btnVerCardPerfil.setVisibility(View.VISIBLE);
            }

            if (headerCertificadosPerfil != null) headerCertificadosPerfil.setVisibility(View.VISIBLE);
            if (containerCertificadosPerfil != null) containerCertificadosPerfil.setVisibility(View.VISIBLE);

            if (headerFaculdadesSeguidasPerfil != null) headerFaculdadesSeguidasPerfil.setVisibility(View.VISIBLE);
            if (containerListaFaculdadesSeguidasPerfil != null) containerListaFaculdadesSeguidasPerfil.setVisibility(View.VISIBLE);

            renderizarFaculdadesSeguidas(sp);
        }

        if (txtBioPerfil != null) txtBioPerfil.setText(bio.isEmpty() ? "Nenhuma biografia informada." : bio);
        if (txtPreferenciasPerfil != null) txtPreferenciasPerfil.setText(preferencias.isEmpty() ? "Nenhuma preferência cadastrada." : preferencias);

        carregarImagemElemento(imgFotoPerfil, fotoUri);

        if ("aluno".equalsIgnoreCase(tipoUsuario)) {
            renderizarCertificadosPerfil(sp);
        }

        atualizarSininho(view);
    }

    private void atualizarConquistasEBarraStatus(Context context) {
        if (context == null) return;
        int qtdCursos = GamificationManager.getQtdCursosInscritos(context);

        int colorDarkIndigo = context.getColor(R.color.dark_indigo);
        int colorDarkGray = context.getColor(R.color.dark_gray);
        int colorMint = context.getColor(R.color.mint);

        // 1. Primeiro Passo (1 curso)
        boolean desc1 = GamificationManager.isConquistaDesbloqueada(context, "primeiro_passo");
        if (txtCircleIconPrimeiroPasso != null) txtCircleIconPrimeiroPasso.setBackgroundResource(desc1 ? R.drawable.bg_gold_circle : R.drawable.bg_dot_inactive);
        if (txtLabelPrimeiroPasso != null) txtLabelPrimeiroPasso.setTextColor(desc1 ? colorDarkIndigo : colorDarkGray);
        if (txtReqPrimeiroPassoStatus != null) {
            txtReqPrimeiroPassoStatus.setText(desc1 ? "✓ Conquistado" : qtdCursos + "/1 curso");
            txtReqPrimeiroPassoStatus.setTextColor(desc1 ? colorMint : colorDarkGray);
        }

        // 2. Explorador (2 cursos)
        boolean desc2 = GamificationManager.isConquistaDesbloqueada(context, "explorador");
        if (txtCircleIconExplorador != null) txtCircleIconExplorador.setBackgroundResource(desc2 ? R.drawable.bg_gold_circle : R.drawable.bg_dot_inactive);
        if (txtLabelExplorador != null) txtLabelExplorador.setTextColor(desc2 ? colorDarkIndigo : colorDarkGray);
        if (txtReqExploradorStatus != null) {
            txtReqExploradorStatus.setText(desc2 ? "✓ Conquistado" : qtdCursos + "/2 cursos");
            txtReqExploradorStatus.setTextColor(desc2 ? colorMint : colorDarkGray);
        }

        // 3. Dedicado (3 cursos)
        boolean desc3 = GamificationManager.isConquistaDesbloqueada(context, "dedicado");
        if (txtCircleIconDedicado != null) txtCircleIconDedicado.setBackgroundResource(desc3 ? R.drawable.bg_gold_circle : R.drawable.bg_dot_inactive);
        if (txtLabelDedicado != null) txtLabelDedicado.setTextColor(desc3 ? colorDarkIndigo : colorDarkGray);
        if (txtReqDedicadoStatus != null) {
            txtReqDedicadoStatus.setText(desc3 ? "✓ Conquistado" : qtdCursos + "/3 cursos");
            txtReqDedicadoStatus.setTextColor(desc3 ? colorMint : colorDarkGray);
        }

        // 4. Mestre (4 cursos)
        boolean desc4 = GamificationManager.isConquistaDesbloqueada(context, "mestre");
        if (txtCircleIconMestre != null) txtCircleIconMestre.setBackgroundResource(desc4 ? R.drawable.bg_gold_circle : R.drawable.bg_dot_inactive);
        if (txtLabelMestre != null) txtLabelMestre.setTextColor(desc4 ? colorDarkIndigo : colorDarkGray);
        if (txtReqMestreStatus != null) {
            txtReqMestreStatus.setText(desc4 ? "✓ Conquistado" : qtdCursos + "/4 cursos");
            txtReqMestreStatus.setTextColor(desc4 ? colorMint : colorDarkGray);
        }
    }

    private void exibirDialogPersonalizarTitulo() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_personalizar_titulo, null);

        Button btnFechar = dialogView.findViewById(R.id.btnFecharPersonalizarTituloDialog);
        LinearLayout container = dialogView.findViewById(R.id.containerTitulosPersonalizarDialog);

        List<String> titulosDesbloqueados = GamificationManager.getTitulosDesbloqueados(requireContext());
        String tituloAtual = GamificationManager.getTituloEquipado(requireContext());

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnFechar != null) {
            btnFechar.setOnClickListener(v -> dialog.dismiss());
        }

        if (container != null) {
            container.removeAllViews();
            for (String t : titulosDesbloqueados) {
                boolean estaEquipado = t.equals(tituloAtual);

                Button btnT = new Button(requireContext());
                btnT.setText((estaEquipado ? "✓ EQUIPADO: " : "⭐ EQUIPAR: ") + t);
                btnT.setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        requireContext().getColor(estaEquipado ? R.color.mint : R.color.purple)
                ));
                btnT.setTextColor(requireContext().getColor(R.color.white));
                btnT.setTypeface(null, Typeface.BOLD);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                lp.setMargins(0, 4, 0, 8);
                btnT.setLayoutParams(lp);

                btnT.setOnClickListener(v -> {
                    GamificationManager.equiparTitulo(requireContext(), t);
                    if (getView() != null) carregarDadosPerfil(getView());
                    dialog.dismiss();
                });

                container.addView(btnT);
            }
        }

        dialog.show();
    }

    private void renderizarFaculdadesSeguidas(SharedPreferences sp) {
        if (containerListaFaculdadesSeguidasPerfil == null || getContext() == null) return;
        containerListaFaculdadesSeguidasPerfil.removeAllViews();

        boolean segueUsp = sp.getBoolean("seguindo_USP", false);
        boolean segueUnicamp = sp.getBoolean("seguindo_UNICAMP", false);
        boolean segueUnesp = sp.getBoolean("seguindo_UNESP", false);

        int cont = 0;

        if (segueUsp) {
            cont++;
            adicionarCardFaculdadeSeguida("USP", "USP - Universidade de São Paulo", "Líder em ensino e pesquisa", R.drawable.proximaetapa1);
        }

        if (segueUnicamp) {
            cont++;
            adicionarCardFaculdadeSeguida("UNICAMP", "UNICAMP - Universidade Estadual de Campinas", "Referência em tecnologia e inovação", R.drawable.proximaetapa2);
        }

        if (segueUnesp) {
            cont++;
            adicionarCardFaculdadeSeguida("UNESP", "UNESP - Universidade Estadual Paulista", "Excelência acadêmica em todo o estado de SP", R.drawable.proximaetapa3);
        }

        if (cont == 0) {
            TextView txtVazio = new TextView(getContext());
            txtVazio.setText("Você ainda não segue nenhuma faculdade. Acesse a aba de Cursos para seguir suas universidades preferidas!");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(12);
            txtVazio.setPadding(8, 8, 8, 8);
            containerListaFaculdadesSeguidasPerfil.addView(txtVazio);
        }
    }

    private void adicionarCardFaculdadeSeguida(String sigla, String nomeCompleto, String desc, int caparesId) {
        if (getContext() == null || containerListaFaculdadesSeguidasPerfil == null) return;

        LayoutInflater inflater = LayoutInflater.from(getContext());
        View cardView = inflater.inflate(R.layout.item_faculdade_seguida_perfil, containerListaFaculdadesSeguidasPerfil, false);

        TextView txtNome = cardView.findViewById(R.id.txtNomeFaculdadeSeguidaPerfil);
        TextView txtDesc = cardView.findViewById(R.id.txtDescFaculdadeSeguidaPerfil);
        Button btnVerPerfil = cardView.findViewById(R.id.btnVerPerfilFaculdadeItem);

        if (txtNome != null) txtNome.setText(nomeCompleto);
        if (txtDesc != null) txtDesc.setText("Parceira Oficial & Próxima Etapa");

        if (btnVerPerfil != null) {
            btnVerPerfil.setOnClickListener(v -> {
                Intent intent = new Intent(getActivity(), PerfilFaculdadeActivity.class);
                intent.putExtra("sigla", sigla);
                intent.putExtra("nomeCompleto", nomeCompleto);
                intent.putExtra("descricao", desc);
                intent.putExtra("capaResId", caparesId);
                startActivity(intent);
            });
        }

        containerListaFaculdadesSeguidasPerfil.addView(cardView);
    }

    private void renderizarCertificadosPerfil(SharedPreferences sp) {
        if (containerCertificadosPerfil == null || getContext() == null) return;

        containerCertificadosPerfil.removeAllViews();

        Set<String> setCursosOriginal = sp.getStringSet("lista_cursos_ids", new HashSet<>());
        Set<String> setCursos = new HashSet<>(setCursosOriginal);

        if (setCursos.isEmpty()) {
            TextView txtVazio = new TextView(getContext());
            txtVazio.setText("Nenhum curso concluído ou certificado disponível ainda.");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(12);
            txtVazio.setPadding(8, 8, 8, 8);
            containerCertificadosPerfil.addView(txtVazio);
            return;
        }

        LayoutInflater inflater = LayoutInflater.from(getContext());

        for (String idCurso : setCursos) {
            String nomeCurso = sp.getString("nomeCurso_" + idCurso, "");
            String faculdade = sp.getString("faculdadeCurso_" + idCurso, "USP");

            if (nomeCurso.isEmpty()) continue;

            View certView = inflater.inflate(R.layout.item_certificado_perfil, containerCertificadosPerfil, false);

            TextView txtCursoCert = certView.findViewById(R.id.txtNomeCursoCertificadoItem);
            TextView txtFaculCert = certView.findViewById(R.id.txtFaculdadeCertificadoItem);
            Button btnVerCert = certView.findViewById(R.id.btnVerCertificadoItem);

            if (txtCursoCert != null) txtCursoCert.setText(nomeCurso);
            if (txtFaculCert != null) txtFaculCert.setText("Realização: " + faculdade + " & Próxima Etapa");

            if (btnVerCert != null) {
                btnVerCert.setOnClickListener(v -> CardImageSaver.exibirCertificadoDialog(requireContext(), nomeCurso, faculdade));
            }

            containerCertificadosPerfil.addView(certView);
        }
    }

    private void carregarImagemElemento(ImageView imageView, String fotoUriStr) {
        if (imageView == null || fotoUriStr == null || fotoUriStr.isEmpty()) return;

        if (fotoUriStr.startsWith("preset:")) {
            String presetName = fotoUriStr.replace("preset:", "");
            if ("baseline_account".equals(presetName)) {
                imageView.setImageResource(R.drawable.baseline_account);
            } else if ("logo_proxima_etapa".equals(presetName)) {
                imageView.setImageResource(R.drawable.logo_proxima_etapa);
            } else {
                imageView.setImageResource(R.drawable.round_person);
            }
        } else {
            try {
                imageView.setImageURI(Uri.parse(fotoUriStr));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.round_person);
            }
        }
    }
}