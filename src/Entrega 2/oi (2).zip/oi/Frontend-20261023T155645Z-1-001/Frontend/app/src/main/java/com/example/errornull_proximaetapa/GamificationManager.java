package com.example.errornull_proximaetapa;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GamificationManager {

    public static int getQtdCursosInscritos(Context context) {
        if (context == null) return 0;
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        Set<String> setCursos = sp.getStringSet("lista_cursos_ids", new HashSet<>());
        return setCursos.size();
    }

    public static int getXpTotais(Context context) {
        if (context == null) return 0;
        int cursosCount = getQtdCursosInscritos(context);
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        int xpBonus = sp.getInt("xp_bonus_extra", 0);
        return 100 + (cursosCount * 100) + xpBonus;
    }

    public static int getNivelAtual(Context context) {
        int xp = getXpTotais(context);
        return (xp / 100) + 1;
    }

    public static String getNivelNome(int nivel) {
        if (nivel >= 5) return "👑 Lenda Acadêmica";
        if (nivel == 4) return "🎖️ Mestre da Etapa";
        if (nivel == 3) return "🏆 Dedicado";
        if (nivel == 2) return "⚡ Explorador";
        return "⭐ Primeiro Passo";
    }

    public static boolean isConquistaDesbloqueada(Context context, String idConquista) {
        int count = getQtdCursosInscritos(context);

        if ("primeiro_passo".equalsIgnoreCase(idConquista)) return count >= 1;
        if ("explorador".equalsIgnoreCase(idConquista)) return count >= 2;
        if ("dedicado".equalsIgnoreCase(idConquista)) return count >= 3;
        if ("mestre".equalsIgnoreCase(idConquista)) return count >= 4;

        return false;
    }

    public static String getTituloEquipado(Context context) {
        if (context == null) return "⭐ Primeiro Passo";
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        return sp.getString("titulo_equipado", "⭐ Primeiro Passo");
    }

    public static void equiparTitulo(Context context, String novoTitulo) {
        if (context == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        sp.edit().putString("titulo_equipado", novoTitulo).apply();
        NotificationHelper.exibirToastCustomizado(context, "Título '" + novoTitulo + "' exibido no seu perfil!");
    }

    public static void adicionarXp(Context context, int quantidade, String motivo) {
        if (context == null) return;
        SharedPreferences sp = UserSession.getScopedPreferences(context);

        int xpAnterior = sp.getInt("xp_bonus_extra", 0);
        int novoXp = xpAnterior + quantidade;
        sp.edit().putInt("xp_bonus_extra", novoXp).apply();

        String msg = "+" + quantidade + " XP ganho por: " + motivo + "!";
        NotificationHelper.adicionarNotificacao(context, "🎮 Ganhou + " + quantidade + " XP!", msg);
        NotificationHelper.exibirToastCustomizado(context, msg);
    }

    public static List<String> getTitulosDesbloqueados(Context context) {
        List<String> titulos = new ArrayList<>();
        titulos.add("⭐ Primeiro Passo");

        if (isConquistaDesbloqueada(context, "explorador")) {
            titulos.add("⚡ Explorador");
        }
        if (isConquistaDesbloqueada(context, "dedicado")) {
            titulos.add("🏆 Dedicado");
        }
        if (isConquistaDesbloqueada(context, "mestre")) {
            titulos.add("🎖️ Mestre");
        }

        return titulos;
    }
}