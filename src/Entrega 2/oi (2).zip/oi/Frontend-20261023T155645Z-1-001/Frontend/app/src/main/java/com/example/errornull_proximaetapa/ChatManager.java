package com.example.errornull_proximaetapa;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class ChatManager {

    private static final String PREF_CHAT_PREFIX = "chat_canal_";

    public static List<String> getMensagensCanal(Context context, String channelId) {
        if (context == null || channelId == null) return new ArrayList<>();
        SharedPreferences sp = context.getSharedPreferences("ChatDataBase", Context.MODE_PRIVATE);
        String savedString = sp.getString(PREF_CHAT_PREFIX + channelId, "");

        if (savedString.isEmpty()) {
            return new ArrayList<>();
        }

        return new ArrayList<>(Arrays.asList(savedString.split("###")));
    }

    public static void enviarMensagem(Context context, String channelId, String remetenteNome, String remetenteRole, String textoMsg) {
        if (context == null || channelId == null || textoMsg == null || textoMsg.trim().isEmpty()) return;

        SharedPreferences sp = context.getSharedPreferences("ChatDataBase", Context.MODE_PRIVATE);
        String savedString = sp.getString(PREF_CHAT_PREFIX + channelId, "");

        List<String> lista = new ArrayList<>();
        if (!savedString.isEmpty()) {
            lista.addAll(Arrays.asList(savedString.split("###")));
        }

        String dataHora = DateFormat.format("dd/MM/yyyy • HH:mm", new Date()).toString();
        String itemMsg = remetenteNome + "|||" + remetenteRole + "|||" + textoMsg.trim() + "|||" + dataHora;

        lista.add(itemMsg);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista.size(); i++) {
            sb.append(lista.get(i));
            if (i < lista.size() - 1) sb.append("###");
        }

        sp.edit().putString(PREF_CHAT_PREFIX + channelId, sb.toString()).apply();

        // Notifica o destinatário SOMENTE SE a mensagem foi enviada por outra pessoa/papel
        SharedPreferences spUser = UserSession.getScopedPreferences(context);
        String meuTipo = spUser.getString("tipoUsuario", "aluno");

        if (!meuTipo.equalsIgnoreCase(remetenteRole)) {
            NotificationHelper.adicionarNotificacao(
                    context,
                    "💬 Nova resposta no Chat (" + remetenteNome + ")",
                    textoMsg.trim()
            );
            NotificationHelper.exibirToastCustomizado(context, "💬 " + remetenteNome + ": " + textoMsg.trim());
        }
    }

    public static void abrirJanelaChat(Context context, String channelId, String tituloJanela, String subtituloJanela) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_chat_conversacao, null);

        TextView txtTitulo = dialogView.findViewById(R.id.txtTituloJanelaChat);
        TextView txtSubtitulo = dialogView.findViewById(R.id.txtSubtituloJanelaChat);
        LinearLayout containerMsgs = dialogView.findViewById(R.id.containerMensagensChat);
        EditText inputTexto = dialogView.findViewById(R.id.inputTextoMensagemChat);
        Button btnEnviar = dialogView.findViewById(R.id.btnEnviarMensagemChat);
        Button btnFechar = dialogView.findViewById(R.id.btnFecharJanelaChat);

        if (txtTitulo != null) txtTitulo.setText(tituloJanela);
        if (txtSubtitulo != null) txtSubtitulo.setText(subtituloJanela);

        SharedPreferences spUser = UserSession.getScopedPreferences(context);
        String meuNome = spUser.getString("nome", "Usuário");
        String meuRole = spUser.getString("tipoUsuario", "aluno");

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        Runnable recarregarChat = () -> {
            if (containerMsgs == null) return;
            containerMsgs.removeAllViews();

            List<String> mensagens = getMensagensCanal(context, channelId);

            if (mensagens.isEmpty()) {
                TextView txtVazio = new TextView(context);
                txtVazio.setText("Nenhuma mensagem trocada ainda. Escreva a primeira mensagem abaixo!");
                txtVazio.setTextColor(context.getColor(R.color.dark_gray));
                txtVazio.setTextSize(12);
                txtVazio.setPadding(16, 16, 16, 16);
                containerMsgs.addView(txtVazio);
            } else {
                for (String mStr : mensagens) {
                    String[] p = mStr.split("\\|\\|\\|");
                    String nome = p.length > 0 ? p[0] : "Remetente";
                    String role = p.length > 1 ? p[1] : "aluno";
                    String texto = p.length > 2 ? p[2] : "";
                    String hora = p.length > 3 ? p[3] : "";

                    boolean souEu = meuRole.equalsIgnoreCase(role);

                    LinearLayout cardM = new LinearLayout(context);
                    cardM.setOrientation(LinearLayout.VERTICAL);
                    cardM.setBackgroundResource(souEu ? R.drawable.bg_pill_purple : R.drawable.bg_card_questionario);
                    cardM.setPadding(16, 12, 16, 12);

                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMargins(0, 4, 0, 8);
                    cardM.setLayoutParams(lp);

                    TextView txtN = new TextView(context);
                    txtN.setText(nome + " (" + role.toUpperCase() + ") • " + hora);
                    txtN.setTextColor(context.getColor(souEu ? R.color.yellow : R.color.purple));
                    txtN.setTextSize(11);
                    txtN.setTypeface(null, Typeface.BOLD);

                    TextView txtT = new TextView(context);
                    txtT.setText(texto);
                    txtT.setTextColor(context.getColor(souEu ? R.color.white : R.color.dark_indigo));
                    txtT.setTextSize(13);
                    txtT.setPadding(0, 4, 0, 0);

                    cardM.addView(txtN);
                    cardM.addView(txtT);

                    containerMsgs.addView(cardM);
                }
            }
        };

        recarregarChat.run();

        if (btnEnviar != null && inputTexto != null) {
            btnEnviar.setOnClickListener(v -> {
                String t = inputTexto.getText().toString().trim();
                if (t.isEmpty()) return;

                enviarMensagem(context, channelId, meuNome, meuRole, t);
                inputTexto.setText("");
                recarregarChat.run();
            });
        }

        if (btnFechar != null) {
            btnFechar.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }
}