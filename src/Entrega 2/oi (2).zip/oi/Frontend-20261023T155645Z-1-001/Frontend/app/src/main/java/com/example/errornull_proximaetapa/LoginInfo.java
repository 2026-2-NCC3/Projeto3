package com.example.errornull_proximaetapa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import com.example.errornull_proximaetapa.peServices.ApiService;
import com.example.errornull_proximaetapa.peServices.LoginRequest;
import com.example.errornull_proximaetapa.peServices.TokenResponse;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LoginInfo extends AppCompatActivity {

    private ViewPager2 viewPagerCarousel;
    private final Handler carouselHandler = new Handler(Looper.getMainLooper());
    private Runnable carouselRunnable;
    private int currentCarouselPosition = 0;

    private View dot1, dot2, dot3;

    private EditText inputEmail, inputSenha;
    private Button btnLogar, btnIrParaCadastro;
    private TextView tabLoginAluno, tabLoginProfessor, tabLoginAdmin;
    private String tipoContaSelecionada = "aluno";

    private ApiService api;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Se o usuário já estiver autenticado com e-mail válido, redireciona direto para MainActivity
        String usuarioConectado = UserSession.getUsuarioAtual(this);
        if (usuarioConectado != null && !usuarioConectado.isEmpty() && !"usuario_convidado".equalsIgnoreCase(usuarioConectado)) {
            Intent intent = new Intent(LoginInfo.this, MainActivity.class);
            intent.putExtra("abrir_perfil", true);
            startActivity(intent);
            finish();
            return;
        }

        setContentView(R.layout.tela_login);

        dot1 = findViewById(R.id.dot1);
        dot2 = findViewById(R.id.dot2);
        dot3 = findViewById(R.id.dot3);

        inicializarCarrossel();

        inputEmail = findViewById(R.id.input_email);
        inputSenha = findViewById(R.id.input_senha);
        btnLogar = findViewById(R.id.btn_logar);
        btnIrParaCadastro = findViewById(R.id.btn_ir_cadastro);

        tabLoginAluno = findViewById(R.id.tabLoginAluno);
        tabLoginProfessor = findViewById(R.id.tabLoginProfessor);
        tabLoginAdmin = findViewById(R.id.tabLoginAdmin);

        if (tabLoginAluno != null) tabLoginAluno.setOnClickListener(v -> selecionarTipoConta("aluno"));
        if (tabLoginProfessor != null) tabLoginProfessor.setOnClickListener(v -> selecionarTipoConta("professor"));
        if (tabLoginAdmin != null) tabLoginAdmin.setOnClickListener(v -> selecionarTipoConta("admin"));

        // Configuração da API Retrofit
        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("https://pi3-kc5f.onrender.com/")
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(ApiService.class);

        // Ação do Botão "Criar conta" (@+id/btn_ir_cadastro)
        if (btnIrParaCadastro != null) {
            btnIrParaCadastro.setOnClickListener(v -> {
                Intent intent = new Intent(LoginInfo.this, Cadastro.class);
                startActivity(intent);
            });
        }

        // Ação do Botão de Login (@+id/btn_logar)
        if (btnLogar != null) {
            btnLogar.setOnClickListener(v -> {
                String email = inputEmail != null ? inputEmail.getText().toString().trim() : "";
                String senha = inputSenha != null ? inputSenha.getText().toString().trim() : "";

                if (email.isEmpty()) {
                    email = "usuario_convidado";
                }

                UserSession.setUsuarioAtual(LoginInfo.this, email);
                SharedPreferences sp = UserSession.getScopedPreferences(LoginInfo.this);

                sp.edit()
                        .putString("tipoUsuario", tipoContaSelecionada)
                        .putString("nome", "usuario_convidado".equalsIgnoreCase(email) ? ("Convidado (" + tipoContaSelecionada.toUpperCase() + ")") : email.split("@")[0])
                        .apply();

                String statusConta = sp.getString("statusConta", "ACTIVA");
                if ("SUSPENSA".equalsIgnoreCase(statusConta) || "DESATIVADA".equalsIgnoreCase(statusConta)) {
                    Toast.makeText(LoginInfo.this, "Sua conta está " + statusConta.toLowerCase() + ". Entre em contato com o ADM.", Toast.LENGTH_LONG).show();
                    return;
                }

                final String perfilFinal = tipoContaSelecionada;

                if (senha.isEmpty()) {
                    Toast.makeText(LoginInfo.this, "Entrando como " + perfilFinal.toUpperCase() + ".", Toast.LENGTH_SHORT).show();
                    abrirMainActivity();
                    return;
                }

                LoginRequest request = new LoginRequest(email, senha);

                api.fazerLogin(request).enqueue(new Callback<TokenResponse>() {
                    @Override
                    public void onResponse(Call<TokenResponse> call, Response<TokenResponse> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            Toast.makeText(LoginInfo.this, "Login efetuado com sucesso (" + perfilFinal.toUpperCase() + ")!", Toast.LENGTH_SHORT).show();
                            abrirMainActivity();
                        } else {
                            Toast.makeText(LoginInfo.this, "E-mail ou senha inválidos.", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<TokenResponse> call, Throwable t) {
                        Toast.makeText(LoginInfo.this, "Entrando como " + perfilFinal.toUpperCase() + " (Modo Offline).", Toast.LENGTH_SHORT).show();
                        Log.e("API_ERRO", "Falha: " + t.getMessage());
                        abrirMainActivity();
                    }
                });
            });
        }
    }

    private void abrirMainActivity() {
        Intent intent = new Intent(LoginInfo.this, MainActivity.class);
        intent.putExtra("abrir_perfil", true);
        startActivity(intent);
        finish();
    }

    private void selecionarTipoConta(String tipo) {
        tipoContaSelecionada = tipo;

        if (tabLoginAluno != null) {
            tabLoginAluno.setBackgroundResource("aluno".equalsIgnoreCase(tipo) ? R.drawable.bg_tab_selected : R.drawable.bg_tab_unselected);
            tabLoginAluno.setTextColor("aluno".equalsIgnoreCase(tipo) ? getColor(R.color.dark_indigo) : getColor(R.color.white));
        }

        if (tabLoginProfessor != null) {
            tabLoginProfessor.setBackgroundResource("professor".equalsIgnoreCase(tipo) ? R.drawable.bg_tab_selected : R.drawable.bg_tab_unselected);
            tabLoginProfessor.setTextColor("professor".equalsIgnoreCase(tipo) ? getColor(R.color.dark_indigo) : getColor(R.color.white));
        }

        if (tabLoginAdmin != null) {
            tabLoginAdmin.setBackgroundResource("admin".equalsIgnoreCase(tipo) ? R.drawable.bg_tab_selected : R.drawable.bg_tab_unselected);
            tabLoginAdmin.setTextColor("admin".equalsIgnoreCase(tipo) ? getColor(R.color.dark_indigo) : getColor(R.color.white));
        }
    }

    private void inicializarCarrossel() {
        int[] carouselImages = new int[]{
                R.drawable.proximaetapa1,
                R.drawable.proximaetapa2,
                R.drawable.proximaetapa3
        };

        viewPagerCarousel = findViewById(R.id.viewPagerCarousel);
        if (viewPagerCarousel != null) {
            viewPagerCarousel.setAdapter(new CarouselAdapter(carouselImages));

            viewPagerCarousel.setPageTransformer((page, position) -> {
                float absPos = Math.abs(position);

                if (position <= -1 || position >= 1) {
                    page.setAlpha(0f);
                } else {
                    page.setTranslationX(-position * page.getWidth());
                    float alpha = 1f - absPos;
                    page.setAlpha(alpha);
                    float scale = 0.96f + (1f - absPos) * 0.04f;
                    page.setScaleX(scale);
                    page.setScaleY(scale);
                }
            });

            viewPagerCarousel.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    super.onPageSelected(position);
                    currentCarouselPosition = position;
                    atualizarDots(position);
                }
            });

            carouselRunnable = new Runnable() {
                @Override
                public void run() {
                    if (viewPagerCarousel != null) {
                        currentCarouselPosition = (currentCarouselPosition + 1) % carouselImages.length;
                        viewPagerCarousel.setCurrentItem(currentCarouselPosition, true);
                        carouselHandler.postDelayed(this, 8000);
                    }
                }
            };

            carouselHandler.postDelayed(carouselRunnable, 8000);
        }
    }

    private void atualizarDots(int position) {
        if (dot1 == null || dot2 == null || dot3 == null) return;

        dot1.setBackgroundResource(position == 0 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot2.setBackgroundResource(position == 1 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);
        dot3.setBackgroundResource(position == 2 ? R.drawable.bg_dot_active : R.drawable.bg_dot_inactive);

        ViewGroup.LayoutParams p1 = dot1.getLayoutParams();
        p1.width = position == 0 ? 50 : 20;
        dot1.setLayoutParams(p1);

        ViewGroup.LayoutParams p2 = dot2.getLayoutParams();
        p2.width = position == 1 ? 50 : 20;
        dot2.setLayoutParams(p2);

        ViewGroup.LayoutParams p3 = dot3.getLayoutParams();
        p3.width = position == 2 ? 50 : 20;
        dot3.setLayoutParams(p3);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (carouselHandler != null && carouselRunnable != null) {
            carouselHandler.removeCallbacks(carouselRunnable);
            carouselHandler.postDelayed(carouselRunnable, 8000);
        }
    }
}