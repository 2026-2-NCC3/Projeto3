package com.example.errornull_proximaetapa;

import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.view.MenuItem;
import android.view.ViewGroup;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.errornull_proximaetapa.Fragments.AvisosFragment;
import com.example.errornull_proximaetapa.Fragments.ConfigFragment;
import com.example.errornull_proximaetapa.Fragments.CursosFragment;
import com.example.errornull_proximaetapa.Fragments.HomeFragment;
import com.example.errornull_proximaetapa.Fragments.PerfilFragment;
import com.example.errornull_proximaetapa.databinding.ActivityMainBinding;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;
    FloatingActionButton menu_perfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Inicializa o modo escuro salvo antes do super.onCreate
        SharedPreferences sp = UserSession.getScopedPreferences(this);
        boolean temaEscuro = sp.getBoolean("config_tema_escuro", false);

        if (temaEscuro) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Integração Contínua e Imersiva da Barra Amarela com os Botões do Sistema
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getWindow().setNavigationBarColor(getColor(R.color.yellow));
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                getWindow().setNavigationBarContrastEnforced(false);
            }
        }

        menu_perfil = findViewById(R.id.menu_perfil);

        // Preenche a barra amarela até a borda sem criar lacunas
        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, windowInsets) -> {
            if (binding.bottomappbar != null && binding.bottomappbar.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
                ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) binding.bottomappbar.getLayoutParams();
                params.bottomMargin = 0;
                binding.bottomappbar.setLayoutParams(params);
            }
            return windowInsets;
        });

        atualizarBotaoPerfil(false);
        configurarMenuNavegacaoPorPapel();

        menu_perfil.setOnClickListener(v -> {
            mudarFragment(new PerfilFragment());
            binding.bottomnavview.getMenu()
                    .findItem(R.id.menu_nada)
                    .setChecked(true);
            atualizarBotaoPerfil(true);
            menu_perfil.animate()
                    .scaleX(0.88f)
                    .scaleY(0.88f)
                    .setDuration(100)
                    .withEndAction(() ->
                            menu_perfil.animate()
                                    .scaleX(1f)
                                    .scaleY(1f)
                                    .setDuration(160)
                                    .start()
                    )
                    .start();
        });

        // Cliques nos itens normais da barra
        binding.bottomnavview.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.menu_nada) {
                mudarFragment(new PerfilFragment());
                atualizarBotaoPerfil(true);
                return true;
            } else if (id == R.id.menu_home) {
                mudarFragment(new HomeFragment());
            } else if (id == R.id.menu_cursos) {
                mudarFragment(new CursosFragment());
            } else if (id == R.id.menu_avisos) {
                mudarFragment(new AvisosFragment());
            } else if (id == R.id.menu_config) {
                mudarFragment(new ConfigFragment());
            } else {
                return false;
            }

            atualizarBotaoPerfil(false);
            return true;
        });

        if (getIntent().getBooleanExtra("abrir_perfil", false)) {
            mudarFragment(new PerfilFragment());
            atualizarBotaoPerfil(true);
        } else {
            mudarFragment(new HomeFragment());
        }
    }

    private void configurarMenuNavegacaoPorPapel() {
        SharedPreferences sp = UserSession.getScopedPreferences(this);
        String tipo = sp.getString("tipoUsuario", "aluno");

        MenuItem itemHome = binding.bottomnavview.getMenu().findItem(R.id.menu_home);
        MenuItem itemCursos = binding.bottomnavview.getMenu().findItem(R.id.menu_cursos);
        MenuItem itemAvisos = binding.bottomnavview.getMenu().findItem(R.id.menu_avisos);
        MenuItem itemConfig = binding.bottomnavview.getMenu().findItem(R.id.menu_config);

        if ("professor".equalsIgnoreCase(tipo)) {
            if (itemHome != null) {
                itemHome.setTitle("Turmas");
                itemHome.setIcon(android.R.drawable.ic_menu_agenda);
            }
            if (itemCursos != null) {
                itemCursos.setTitle("Postar");
                itemCursos.setIcon(android.R.drawable.ic_menu_add);
            }
            if (itemAvisos != null) {
                itemAvisos.setTitle("Avisos");
                itemAvisos.setIcon(android.R.drawable.ic_menu_day);
            }
            if (itemConfig != null) {
                itemConfig.setTitle("Ajustes");
                itemConfig.setIcon(android.R.drawable.ic_menu_preferences);
            }
        } else if ("admin".equalsIgnoreCase(tipo)) {
            if (itemHome != null) {
                itemHome.setTitle("Painel");
                itemHome.setIcon(android.R.drawable.ic_menu_manage);
            }
            if (itemCursos != null) {
                itemCursos.setTitle("Gerenciar");
                itemCursos.setIcon(android.R.drawable.ic_menu_edit);
            }
            if (itemAvisos != null) {
                itemAvisos.setTitle("Requerimentos");
                itemAvisos.setIcon(android.R.drawable.ic_menu_send);
            }
            if (itemConfig != null) {
                itemConfig.setTitle("Ajustes");
                itemConfig.setIcon(android.R.drawable.ic_menu_preferences);
            }
        } else {
            // ALUNO
            if (itemHome != null) {
                itemHome.setTitle("Home");
                itemHome.setIcon(android.R.drawable.ic_menu_view);
            }
            if (itemCursos != null) {
                itemCursos.setTitle("Cursos");
                itemCursos.setIcon(android.R.drawable.ic_menu_compass);
            }
            if (itemAvisos != null) {
                itemAvisos.setTitle("Avisos");
                itemAvisos.setIcon(android.R.drawable.ic_menu_today);
            }
            if (itemConfig != null) {
                itemConfig.setTitle("Config");
                itemConfig.setIcon(android.R.drawable.ic_menu_preferences);
            }
        }
    }

    private void mudarFragment(androidx.fragment.app.Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .setCustomAnimations(
                        android.R.anim.fade_in,
                        android.R.anim.fade_out
                )
                .replace(R.id.frame_layout, fragment)
                .commit();
    }

    private void atualizarBotaoPerfil(boolean selecionado) {
        int corIcone = selecionado ? Color.WHITE : Color.BLACK;

        menu_perfil.setImageTintList(ColorStateList.valueOf(corIcone));

        menu_perfil.animate()
                .scaleX(selecionado ? 1.08f : 1f)
                .scaleY(selecionado ? 1.08f : 1f)
                .setDuration(180)
                .start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        configurarMenuNavegacaoPorPapel();
    }
}