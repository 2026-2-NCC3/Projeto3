package com.example.errornull_proximaetapa;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BlacklistManager {

    public static int getQtdStrikes(Context context) {
        if (context == null) return 0;
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        return sp.getInt("strike_count", 0);
    }

    public static boolean isSuspensoOuBanido(Context context) {
        if (context == null) return false;
        SharedPreferences sp = UserSession.getScopedPreferences(context);

        if (sp.getBoolean("esta_banido", false)) return true;

        boolean suspenso = sp.getBoolean("esta_suspenso", false);
        if (!suspenso) return false;

        long tempoFim = sp.getLong("strike_timestamp_fim", 0);
        if (tempoFim > 0 && System.currentTimeMillis() >= tempoFim) {
            // Suspensão expirou! Aluno volta a ter acesso aos cursos automaticamente
            sp.edit().putBoolean("esta_suspenso", false).remove("strike_timestamp_fim").apply();
            return false;
        }

        return true;
    }

    public static boolean isBanido(Context context) {
        if (context == null) return false;
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        return sp.getBoolean("esta_banido", false) || sp.getInt("strike_count", 0) >= 3;
    }

    public static String getUltimoMotivoStrike(Context context) {
        if (context == null) return "Sem motivo registrado";
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        int qtd = getQtdStrikes(context);
        return sp.getString("strike_motivo_" + qtd, "Desrespeito às normas de conduta da plataforma");
    }

    public static String getUltimoPrazoStrike(Context context) {
        if (context == null) return "Até liberação do ADM";
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        int qtd = getQtdStrikes(context);
        if (isBanido(context)) return "BANIMENTO PERMANENTE (Contate o ADM)";
        return sp.getString("strike_prazo_" + qtd, "1 minuto");
    }

    public static void aplicarStrikeParaEmail(Context context, String emailTarget, String motivo, String prazoHorasOuDias) {
        if (context == null || emailTarget == null || emailTarget.trim().isEmpty()) return;
        SharedPreferences sp = UserSession.getScopedPreferencesForUser(context, emailTarget);

        int qtdAtual = sp.getInt("strike_count", 0) + 1;
        long duracaoMillis = 60 * 1000L;

        String prazoLower = prazoHorasOuDias.toLowerCase().trim();
        if (prazoLower.contains("min")) {
            try {
                String nums = prazoLower.replaceAll("[^0-9]", "");
                if (!nums.isEmpty()) duracaoMillis = Long.parseLong(nums) * 60 * 1000L;
            } catch (Exception ignored) {}
        } else if (prazoLower.contains("hora") || prazoLower.contains("h")) {
            try {
                String nums = prazoLower.replaceAll("[^0-9]", "");
                if (!nums.isEmpty()) duracaoMillis = Long.parseLong(nums) * 60 * 60 * 1000L;
            } catch (Exception ignored) {}
        } else if (prazoLower.contains("dia") || prazoLower.contains("d")) {
            try {
                String nums = prazoLower.replaceAll("[^0-9]", "");
                if (!nums.isEmpty()) duracaoMillis = Long.parseLong(nums) * 24 * 60 * 60 * 1000L;
            } catch (Exception ignored) {}
        }

        long tempoFim = System.currentTimeMillis() + duracaoMillis;

        SharedPreferences.Editor editor = sp.edit();
        editor.putInt("strike_count", qtdAtual);
        editor.putString("strike_motivo_" + qtdAtual, motivo);
        editor.putString("strike_prazo_" + qtdAtual, prazoHorasOuDias);
        editor.putBoolean("esta_suspenso", true);
        editor.putLong("strike_timestamp_fim", tempoFim);

        if (qtdAtual >= 3) {
            editor.putBoolean("esta_banido", true);
        }

        editor.apply();

        String msgNotif = qtdAtual >= 3
                ? "⚠️ STRIKE 3/3 RECEBIDO! Conta banida."
                : "⚠️ Strike " + qtdAtual + "/3 aplicado ao aluno " + emailTarget + ".";

        NotificationHelper.exibirToastCustomizado(context, msgNotif);
    }

    public static void enviarAvisoProfessorParaEmail(Context context, String emailTarget, String avisoTexto, String autor) {
        if (context == null || emailTarget == null || emailTarget.trim().isEmpty()) return;
        SharedPreferences sp = UserSession.getScopedPreferencesForUser(context, emailTarget);

        String saved = sp.getString("lista_avisos_professor", "");
        List<String> lista = new ArrayList<>();
        if (!saved.isEmpty()) {
            lista.addAll(Arrays.asList(saved.split("###")));
        }

        lista.add(0, autor + ": " + avisoTexto);

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista.size(); i++) {
            sb.append(lista.get(i));
            if (i < lista.size() - 1) sb.append("###");
        }

        sp.edit().putString("lista_avisos_professor", sb.toString()).apply();
        NotificationHelper.exibirToastCustomizado(context, "Aviso enviado para " + emailTarget + "!");
    }

    public static void removerStrikesELiberarAlunoParaEmail(Context context, String emailTarget) {
        if (context == null || emailTarget == null || emailTarget.trim().isEmpty()) return;
        SharedPreferences sp = UserSession.getScopedPreferencesForUser(context, emailTarget);
        sp.edit()
                .putInt("strike_count", 0)
                .putBoolean("esta_suspenso", false)
                .putBoolean("esta_banido", false)
                .remove("strike_timestamp_fim")
                .apply();

        NotificationHelper.exibirToastCustomizado(context, "Aluno " + emailTarget + " liberado pelo ADM!");
    }

    public static List<String> getListaAvisos(Context context) {
        if (context == null) return new ArrayList<>();
        SharedPreferences sp = UserSession.getScopedPreferences(context);
        String saved = sp.getString("lista_avisos_professor", "");
        if (saved.isEmpty()) return new ArrayList<>();
        return new ArrayList<>(Arrays.asList(saved.split("###")));
    }

    public static void exibirTelaBloqueioCurso(Context context) {
        if (context == null) return;

        SharedPreferences sp = UserSession.getScopedPreferences(context);
        long tempoFim = sp.getLong("strike_timestamp_fim", 0);

        if (!isBanido(context) && tempoFim > 0 && System.currentTimeMillis() >= tempoFim) {
            sp.edit().putBoolean("esta_suspenso", false).remove("strike_timestamp_fim").apply();
            NotificationHelper.exibirToastCustomizado(context, "Sua suspensão expirou! Seus cursos foram liberados.");
            return;
        }

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_curso_bloqueado, null);

        TextView txtTituloHeaderLock = dialogView.findViewById(R.id.txtTituloHeaderLock);
        TextView txtMotivoLock = dialogView.findViewById(R.id.txtMotivoLock);
        TextView txtTempoSuspensaoLock = dialogView.findViewById(R.id.txtTempoSuspensaoLock);
        Button btnEntendiLock = dialogView.findViewById(R.id.btnEntendiLock);

        boolean banido = isBanido(context);
        String motivo = getUltimoMotivoStrike(context);
        String prazoDeclarado = getUltimoPrazoStrike(context);

        if (txtTituloHeaderLock != null) {
            txtTituloHeaderLock.setText(banido ? "VOCÊ FOI BANIDO DA PLATAFORMA!" : "Você levou um strike!");
        }

        if (txtMotivoLock != null) {
            txtMotivoLock.setText("Motivo: " + motivo);
        }

        if (txtTempoSuspensaoLock != null) {
            txtTempoSuspensaoLock.setText("Duração do bloqueio: " + prazoDeclarado);
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnEntendiLock != null) {
            btnEntendiLock.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    public static void exibirBlacklistAlunoDialog(Context context) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_blacklist_aluno, null);

        Button btnVoltar = dialogView.findViewById(R.id.btnVoltarBlacklist);
        View b1 = dialogView.findViewById(R.id.blockStrike1);
        View b2 = dialogView.findViewById(R.id.blockStrike2);
        View b3 = dialogView.findViewById(R.id.blockStrike3);

        LinearLayout containerMotivos = dialogView.findViewById(R.id.containerMotivosBlacklist);
        LinearLayout containerAvisos = dialogView.findViewById(R.id.containerAvisosBlacklist);

        int strikes = getQtdStrikes(context);
        List<String> avisos = getListaAvisos(context);

        if (b1 != null) b1.setBackgroundResource(strikes >= 1 ? R.drawable.bg_strike_block_red : R.drawable.bg_strike_block_gray);
        if (b2 != null) b2.setBackgroundResource(strikes >= 2 ? R.drawable.bg_strike_block_red : R.drawable.bg_strike_block_gray);
        if (b3 != null) b3.setBackgroundResource(strikes >= 3 ? R.drawable.bg_strike_block_red : R.drawable.bg_strike_block_gray);

        if (containerMotivos != null) {
            containerMotivos.removeAllViews();
            if (strikes == 0) {
                TextView txtVazio = new TextView(context);
                txtVazio.setText("Nenhum strike registrado no momento.");
                txtVazio.setTextColor(context.getColor(R.color.dark_gray));
                txtVazio.setTextSize(12);
                txtVazio.setPadding(8, 8, 8, 8);
                containerMotivos.addView(txtVazio);
            } else {
                for (int s = 1; s <= strikes; s++) {
                    SharedPreferences sp = UserSession.getScopedPreferences(context);
                    String mot = sp.getString("strike_motivo_" + s, "Desrespeito às regras da plataforma");
                    String prz = sp.getString("strike_prazo_" + s, "1 minuto");

                    TextView itemM = new TextView(context);
                    itemM.setText("• Strike " + s + "/3: " + mot + " (Duração: " + prz + ")");
                    itemM.setTextColor(context.getColor(R.color.dark_indigo));
                    itemM.setTextSize(12);
                    itemM.setPadding(0, 4, 0, 4);
                    containerMotivos.addView(itemM);
                }
            }
        }

        if (containerAvisos != null) {
            containerAvisos.removeAllViews();
            if (avisos.isEmpty()) {
                TextView txtVazio = new TextView(context);
                txtVazio.setText("Nenhum aviso emitido por professores ou direção até o momento.");
                txtVazio.setTextColor(context.getColor(R.color.dark_gray));
                txtVazio.setTextSize(12);
                txtVazio.setPadding(8, 8, 8, 8);
                containerAvisos.addView(txtVazio);
            } else {
                for (String aviso : avisos) {
                    TextView item = new TextView(context);
                    item.setText("• " + aviso);
                    item.setTextColor(context.getColor(R.color.dark_indigo));
                    item.setTextSize(12);
                    item.setPadding(0, 4, 0, 4);
                    containerAvisos.addView(item);
                }
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnVoltar != null) {
            btnVoltar.setOnClickListener(v -> dialog.dismiss());
        }

        dialog.show();
    }

    public static void exibirPainelAdminBlacklistDialog(Context context) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_blacklist_admin, null);

        Button btnVoltar = dialogView.findViewById(R.id.btnVoltarAdminBlacklist);
        EditText inputEmail = dialogView.findViewById(R.id.inputEmailAlunoStrike);
        EditText inputMotivo = dialogView.findViewById(R.id.inputMotivoStrike);
        EditText inputPrazo = dialogView.findViewById(R.id.inputPrazoStrike);

        Button btnAplicarStrike = dialogView.findViewById(R.id.btnAplicarStrikeAdmin);
        Button btnEnviarAviso = dialogView.findViewById(R.id.btnEnviarAvisoAdmin);
        Button btnLiberarAluno = dialogView.findViewById(R.id.btnLiberarAlunoAdmin);

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnVoltar != null) {
            btnVoltar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnAplicarStrike != null) {
            btnAplicarStrike.setOnClickListener(v -> {
                String email = inputEmail != null ? inputEmail.getText().toString().trim() : "";
                String motivo = inputMotivo != null ? inputMotivo.getText().toString().trim() : "";
                String prazo = inputPrazo != null ? inputPrazo.getText().toString().trim() : "";

                if (email.isEmpty() || motivo.isEmpty() || prazo.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(context, "E-mail do Aluno, Motivo e Prazo são OBRIGATÓRIOS!");
                    return;
                }

                aplicarStrikeParaEmail(context, email, motivo, prazo);
                dialog.dismiss();
            });
        }

        if (btnEnviarAviso != null) {
            btnEnviarAviso.setOnClickListener(v -> {
                String email = inputEmail != null ? inputEmail.getText().toString().trim() : "";
                String motivo = inputMotivo != null ? inputMotivo.getText().toString().trim() : "";

                if (email.isEmpty() || motivo.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(context, "Digite o e-mail do aluno e a mensagem!");
                    return;
                }

                enviarAvisoProfessorParaEmail(context, email, motivo, "ADM");
                dialog.dismiss();
            });
        }

        if (btnLiberarAluno != null) {
            btnLiberarAluno.setOnClickListener(v -> {
                String email = inputEmail != null ? inputEmail.getText().toString().trim() : "";
                if (email.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(context, "Digite o e-mail do aluno para liberar!");
                    return;
                }
                removerStrikesELiberarAlunoParaEmail(context, email);
                dialog.dismiss();
            });
        }

        dialog.show();
    }
}