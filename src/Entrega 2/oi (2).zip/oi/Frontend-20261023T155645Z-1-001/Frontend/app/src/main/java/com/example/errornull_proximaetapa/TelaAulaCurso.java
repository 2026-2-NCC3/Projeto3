package com.example.errornull_proximaetapa;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashSet;
import java.util.Set;

public class TelaAulaCurso extends AppCompatActivity {

    private TextView txtNomeCursoAula, txtFaculdadeAula, txtPorcentagemAula;
    private ProgressBar pbProgressoAula;
    private Button btnIniciarContinuar, btnConcluirModulo1, btnConcluirModulo2, btnConcluirModulo3, btnVoltarAula;
    private View btnAbrirForumDuvidas;

    private int progressoAtual = 0;
    private String cursoId = "web";
    private String nomeCurso = "Desenvolvimento Web";
    private String faculdade = "USP";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_aula_curso);

        txtNomeCursoAula = findViewById(R.id.txtNomeCursoAula);
        txtFaculdadeAula = findViewById(R.id.txtFaculdadeAula);
        txtPorcentagemAula = findViewById(R.id.txtPorcentagemAula);
        pbProgressoAula = findViewById(R.id.pbProgressoAula);

        btnIniciarContinuar = findViewById(R.id.btnIniciarContinuar);
        btnConcluirModulo1 = findViewById(R.id.btnConcluirModulo1);
        btnConcluirModulo2 = findViewById(R.id.btnConcluirModulo2);
        btnConcluirModulo3 = findViewById(R.id.btnConcluirModulo3);
        btnVoltarAula = findViewById(R.id.btnVoltarAula);

        btnAbrirForumDuvidas = findViewById(R.id.btnAbrirForumDuvidas);

        String idExtra = getIntent().getStringExtra("cursoId");
        if (idExtra != null && !idExtra.isEmpty()) {
            cursoId = idExtra;
        }

        carregarDados();

        if (btnAbrirForumDuvidas != null) {
            btnAbrirForumDuvidas.setOnClickListener(v -> ChatManager.abrirJanelaChat(
                    TelaAulaCurso.this,
                    "forum_curso_" + cursoId,
                    "💬 Fórum de Dúvidas: " + nomeCurso,
                    "Perguntas, respostas e discussões em tempo real"
            ));
        }

        if (btnVoltarAula != null) {
            btnVoltarAula.setOnClickListener(v -> finish());
        }

        if (btnIniciarContinuar != null) {
            btnIniciarContinuar.setOnClickListener(v -> {
                if (progressoAtual == 0) {
                    atualizarProgresso(20);
                    NotificationHelper.exibirToastCustomizado(this, "Você começou o curso!");
                } else {
                    NotificationHelper.exibirToastCustomizado(this, "Continuando o curso...");
                }
            });
        }

        if (btnConcluirModulo1 != null) {
            btnConcluirModulo1.setOnClickListener(v -> atualizarProgresso(Math.min(100, Math.max(35, progressoAtual + 35))));
        }

        if (btnConcluirModulo2 != null) {
            btnConcluirModulo2.setOnClickListener(v -> atualizarProgresso(Math.min(100, Math.max(70, progressoAtual + 35))));
        }

        if (btnConcluirModulo3 != null) {
            btnConcluirModulo3.setOnClickListener(v -> atualizarProgresso(100));
        }
    }

    private void carregarDados() {
        SharedPreferences sp = UserSession.getScopedPreferences(this);

        nomeCurso = sp.getString("nomeCurso_" + cursoId, sp.getString("nomeCursoInscrito", "Desenvolvimento Web"));
        faculdade = sp.getString("faculdadeCurso_" + cursoId, sp.getString("faculdadeCursoInscrito", "USP"));
        progressoAtual = sp.getInt("progressoCurso_" + cursoId, sp.getInt("progressoCursoInscrito", 0));

        if (txtNomeCursoAula != null) txtNomeCursoAula.setText(nomeCurso);
        if (txtFaculdadeAula != null) txtFaculdadeAula.setText(faculdade);

        renderizarProgresso();
    }

    private void atualizarProgresso(int novoProgresso) {
        progressoAtual = novoProgresso;

        SharedPreferences sp = UserSession.getScopedPreferences(this);
        SharedPreferences.Editor editor = sp.edit();

        editor.putInt("progressoCurso_" + cursoId, progressoAtual);
        editor.putInt("progressoCursoInscrito", progressoAtual);

        // Se o progresso atingir 100%, registra na lista de cursos concluídos em 100%
        if (progressoAtual >= 100) {
            Set<String> concluidosSet = new HashSet<>(sp.getStringSet("lista_cursos_concluidos_100", new HashSet<>()));
            concluidosSet.add(cursoId);
            editor.putStringSet("lista_cursos_concluidos_100", concluidosSet);
            editor.putBoolean("concluido_100_" + cursoId, true);

            NotificationHelper.adicionarNotificacao(
                    this,
                    "🎓 Curso Concluído 100%!",
                    "Parabéns! Você concluiu 100% das aulas do curso " + nomeCurso + ". Seu certificado já está disponível no perfil!"
            );
        } else {
            NotificationHelper.adicionarNotificacao(
                    this,
                    "Progresso de Aulas",
                    "Seu progresso no curso " + nomeCurso + " foi atualizado para " + progressoAtual + "%."
            );
        }

        editor.apply();

        renderizarProgresso();
        NotificationHelper.exibirToastCustomizado(this, "Progresso atualizado para " + progressoAtual + "%!");
    }

    private void renderizarProgresso() {
        if (pbProgressoAula != null) pbProgressoAula.setProgress(progressoAtual);
        if (txtPorcentagemAula != null) txtPorcentagemAula.setText(progressoAtual + "%");

        if (btnIniciarContinuar != null) {
            if (progressoAtual == 0) {
                btnIniciarContinuar.setText("Começar Curso");
            } else {
                btnIniciarContinuar.setText("Continuar Curso");
            }
        }
    }
}