package com.example.errornull_proximaetapa;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CardImageSaver {

    private static final String KEY_CUSTOM_COURSES = "custom_card_courses_string";

    public static void exibirCardEstudanteDialog(Context context) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_card_estudante, null);

        ImageView imgAvatarCard = dialogView.findViewById(R.id.imgAvatarCard);
        TextView txtBadgeQtdCursos = dialogView.findViewById(R.id.txtBadgeQtdCursos);
        TextView txtNomeCard = dialogView.findViewById(R.id.txtNomeCard);
        TextView txtEscolaCard = dialogView.findViewById(R.id.txtEscolaCard);
        LinearLayout containerGridSkillsCard = dialogView.findViewById(R.id.containerGridSkillsCard);
        View layoutCardParaSalvar = dialogView.findViewById(R.id.layoutCardParaSalvar);
        ImageView btnFechar = dialogView.findViewById(R.id.btnFecharCardDialog);
        Button btnPersonalizarCardCursos = dialogView.findViewById(R.id.btnPersonalizarCardCursos);
        Button btnBaixarCardImage = dialogView.findViewById(R.id.btnBaixarCardImage);

        SharedPreferences sp = UserSession.getScopedPreferences(context);

        String nome = sp.getString("nome", "Nome do Aluno");
        String escola = sp.getString("escola", "E.E. Próxima Etapa");
        String fotoUri = sp.getString("foto_perfil_uri", "");

        if (txtNomeCard != null) txtNomeCard.setText(nome);
        if (txtEscolaCard != null) txtEscolaCard.setText(escola);

        List<String> listaCursos = carregarListaCursosCustom(sp);

        if (txtBadgeQtdCursos != null) {
            String txtBadge = listaCursos.size() + "\nCURSOS";
            txtBadgeQtdCursos.setText(txtBadge);
        }

        renderizarGridSkillsCard(context, containerGridSkillsCard, listaCursos);

        if (imgAvatarCard != null && !fotoUri.isEmpty()) {
            if (fotoUri.startsWith("preset:")) {
                String presetName = fotoUri.replace("preset:", "");
                if ("baseline_account".equals(presetName)) {
                    imgAvatarCard.setImageResource(R.drawable.baseline_account);
                } else if ("logo_proxima_etapa".equals(presetName)) {
                    imgAvatarCard.setImageResource(R.drawable.logo_proxima_etapa);
                } else {
                    imgAvatarCard.setImageResource(R.drawable.round_person);
                }
            } else {
                try {
                    imgAvatarCard.setImageURI(Uri.parse(fotoUri));
                } catch (Exception ignored) {}
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnFechar != null) {
            btnFechar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnPersonalizarCardCursos != null) {
            btnPersonalizarCardCursos.setOnClickListener(v -> {
                dialog.dismiss();
                exibirDialogPersonalizarCard(context);
            });
        }

        if (btnBaixarCardImage != null && layoutCardParaSalvar != null) {
            btnBaixarCardImage.setOnClickListener(v -> {
                salvarViewComoImagem(context, layoutCardParaSalvar, "Card_Estudante_" + System.currentTimeMillis());
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private static List<String> carregarListaCursosCustom(SharedPreferences sp) {
        String savedString = sp.getString(KEY_CUSTOM_COURSES, "");
        List<String> lista = new ArrayList<>();

        if (!savedString.isEmpty()) {
            String[] split = savedString.split(";;;");
            lista.addAll(Arrays.asList(split));
        }

        return lista;
    }

    private static void salvarListaCursosCustom(SharedPreferences sp, List<String> lista) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista.size(); i++) {
            sb.append(lista.get(i));
            if (i < lista.size() - 1) {
                sb.append(";;;");
            }
        }
        sp.edit()
                .putString(KEY_CUSTOM_COURSES, sb.toString())
                .putInt("cursosInscritosCount", lista.size())
                .apply();
    }

    private static void renderizarGridSkillsCard(Context context, LinearLayout containerGrid, List<String> cursosList) {
        if (containerGrid == null || context == null) return;
        containerGrid.removeAllViews();

        LayoutInflater inflater = LayoutInflater.from(context);

        if (cursosList.isEmpty()) {
            // Exibe mensagem/item instrucional limpo indicando como adicionar
            TextView txtPlaceholder = new TextView(context);
            txtPlaceholder.setText("➕ Clique no botão abaixo para adicionar seus cursos concluídos em 100%!");
            txtPlaceholder.setTextColor(context.getColor(R.color.purple));
            txtPlaceholder.setTextSize(12);
            txtPlaceholder.setBackgroundResource(R.drawable.bg_card_questionario);
            txtPlaceholder.setPadding(24, 20, 24, 20);
            txtPlaceholder.setGravity(android.view.Gravity.CENTER);
            containerGrid.addView(txtPlaceholder);
            return;
        }

        int total = cursosList.size();

        int[] drawables = new int[]{
                R.drawable.bg_pill_yellow,
                R.drawable.bg_pill_green,
                R.drawable.bg_pill_purple
        };

        for (int i = 0; i < total; i += 2) {
            LinearLayout row = new LinearLayout(context);
            row.setOrientation(LinearLayout.HORIZONTAL);
            LinearLayout.LayoutParams paramsRow = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            paramsRow.setMargins(0, 4, 0, 4);
            row.setLayoutParams(paramsRow);

            // Item 1
            String curso1 = cursosList.get(i);
            TextView item1 = (TextView) inflater.inflate(R.layout.item_pill_skill_card, row, false);
            item1.setText(curso1);
            item1.setBackgroundResource(drawables[i % drawables.length]);
            if (drawables[i % drawables.length] == R.drawable.bg_pill_yellow) {
                item1.setTextColor(context.getColor(R.color.dark_indigo));
            } else {
                item1.setTextColor(context.getColor(R.color.white));
            }

            LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            p1.setMargins(2, 2, 2, 2);
            item1.setLayoutParams(p1);
            row.addView(item1);

            // Item 2 (se houver)
            if (i + 1 < total) {
                String curso2 = cursosList.get(i + 1);
                TextView item2 = (TextView) inflater.inflate(R.layout.item_pill_skill_card, row, false);
                item2.setText(curso2);
                item2.setBackgroundResource(drawables[(i + 1) % drawables.length]);
                if (drawables[(i + 1) % drawables.length] == R.drawable.bg_pill_yellow) {
                    item2.setTextColor(context.getColor(R.color.dark_indigo));
                } else {
                    item2.setTextColor(context.getColor(R.color.white));
                }

                LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
                p2.setMargins(2, 2, 2, 2);
                item2.setLayoutParams(p2);
                row.addView(item2);
            }

            containerGrid.addView(row);
        }
    }

    public static void exibirDialogPersonalizarCard(Context context) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_personalizar_cursos_card, null);

        LinearLayout containerCursosConcluidos = dialogView.findViewById(R.id.containerCursosConcluidosDisponiveis);
        TextView txtSemCursosConcluidosAviso = dialogView.findViewById(R.id.txtSemCursosConcluidosAviso);
        LinearLayout containerListaCard = dialogView.findViewById(R.id.containerListaPersonalizarCard);
        Button btnSalvar = dialogView.findViewById(R.id.btnSalvarPersonalizacaoCard);

        SharedPreferences sp = UserSession.getScopedPreferences(context);
        List<String> listaAtualCard = carregarListaCursosCustom(sp);

        // Busca estritamente os cursos que foram concluídos em 100% pelo usuário
        Set<String> setConcluidos100 = sp.getStringSet("lista_cursos_concluidos_100", new HashSet<>());
        List<String> cursos100Nomes = new ArrayList<>();

        for (String idCurso : setConcluidos100) {
            int progresso = sp.getInt("progressoCurso_" + idCurso, 0);
            if (progresso == 100) {
                String nome = sp.getString("nomeCurso_" + idCurso, "");
                if (!nome.isEmpty() && !cursos100Nomes.contains(nome)) {
                    cursos100Nomes.add(nome);
                }
            }
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        Runnable renderizarListas = new Runnable() {
            @Override
            public void run() {
                LayoutInflater inflater = LayoutInflater.from(context);

                // 1. Renderizar Cursos 100% Concluídos Disponíveis para Adicionar
                if (containerCursosConcluidos != null) {
                    containerCursosConcluidos.removeAllViews();

                    boolean algumDisponivel = false;
                    for (String nomeConcluido : cursos100Nomes) {
                        if (!listaAtualCard.contains(nomeConcluido)) {
                            algumDisponivel = true;
                            View itemConcluidoView = inflater.inflate(R.layout.item_curso_concluido_disponivel, containerCursosConcluidos, false);
                            TextView txtNome = itemConcluidoView.findViewById(R.id.txtNomeCursoConcluido);
                            Button btnAdd = itemConcluidoView.findViewById(R.id.btnAdicionarAoCard);

                            if (txtNome != null) txtNome.setText(nomeConcluido);
                            if (btnAdd != null) {
                                btnAdd.setOnClickListener(v -> {
                                    listaAtualCard.add(nomeConcluido);
                                    run();
                                });
                            }

                            containerCursosConcluidos.addView(itemConcluidoView);
                        }
                    }

                    if (!algumDisponivel && txtSemCursosConcluidosAviso != null) {
                        if (cursos100Nomes.isEmpty()) {
                            txtSemCursosConcluidosAviso.setText("⚠️ Você ainda não possui cursos concluídos em 100%.\n\nAcesse a Home, conclua as aulas e módulos do seu curso para liberá-lo aqui!");
                        } else {
                            txtSemCursosConcluidosAviso.setText("✓ Todos os seus cursos concluídos em 100% já foram adicionados ao Card!");
                        }
                        txtSemCursosConcluidosAviso.setVisibility(View.VISIBLE);
                    } else if (txtSemCursosConcluidosAviso != null) {
                        txtSemCursosConcluidosAviso.setVisibility(View.GONE);
                    }
                }

                // 2. Renderizar Cursos Atualmente Exibidos no Card
                if (containerListaCard != null) {
                    containerListaCard.removeAllViews();

                    if (listaAtualCard.isEmpty()) {
                        TextView txtSemCursosCard = new TextView(context);
                        txtSemCursosCard.setText("Nenhum curso no card ainda.");
                        txtSemCursosCard.setTextColor(context.getColor(R.color.dark_gray));
                        txtSemCursosCard.setPadding(8, 8, 8, 8);
                        containerListaCard.addView(txtSemCursosCard);
                    } else {
                        for (int i = 0; i < listaAtualCard.size(); i++) {
                            final int index = i;
                            String nomeCurso = listaAtualCard.get(i);

                            View rowView = inflater.inflate(R.layout.item_personalizar_curso_row, containerListaCard, false);
                            TextView txtNome = rowView.findViewById(R.id.txtNomeCursoPersonalizar);
                            ImageView btnRemover = rowView.findViewById(R.id.btnRemoverCursoPersonalizar);

                            if (txtNome != null) txtNome.setText(nomeCurso);

                            if (btnRemover != null) {
                                btnRemover.setOnClickListener(v -> {
                                    listaAtualCard.remove(index);
                                    run();
                                });
                            }

                            containerListaCard.addView(rowView);
                        }
                    }
                }
            }
        };

        renderizarListas.run();

        if (btnSalvar != null) {
            btnSalvar.setOnClickListener(v -> {
                salvarListaCursosCustom(sp, listaAtualCard);
                NotificationHelper.adicionarNotificacao(context, "Card Atualizado", "Sua seleção de cursos exibidos no Card do Estudante foi salva com sucesso!");
                NotificationHelper.exibirToastCustomizado(context, "Card do Estudante atualizado com sucesso!");
                dialog.dismiss();
                exibirCardEstudanteDialog(context);
            });
        }

        dialog.show();
    }

    public static void exibirCertificadoDialog(Context context, String nomeCurso, String faculdade) {
        if (context == null) return;

        View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_certificado, null);

        TextView txtNomeAlunoCertificado = dialogView.findViewById(R.id.txtNomeAlunoCertificado);
        TextView txtNomeCursoCertificado = dialogView.findViewById(R.id.txtNomeCursoCertificado);
        TextView txtFaculdadeCertificado = dialogView.findViewById(R.id.txtFaculdadeCertificado);
        View layoutCertificadoParaSalvar = dialogView.findViewById(R.id.layoutCertificadoParaSalvar);
        ImageView btnFechar = dialogView.findViewById(R.id.btnFecharCertificadoDialog);
        Button btnBaixarCertificado = dialogView.findViewById(R.id.btnBaixarCertificado);

        SharedPreferences sp = UserSession.getScopedPreferences(context);
        String nomeAluno = sp.getString("nome", "Nome do Estudante");

        if (txtNomeAlunoCertificado != null) txtNomeAlunoCertificado.setText(nomeAluno);
        if (txtNomeCursoCertificado != null) txtNomeCursoCertificado.setText(nomeCurso);
        if (txtFaculdadeCertificado != null) {
            String txtFacul = "Realização: Próxima Etapa & " + faculdade;
            txtFaculdadeCertificado.setText(txtFacul);
        }

        AlertDialog dialog = new AlertDialog.Builder(context)
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnFechar != null) {
            btnFechar.setOnClickListener(v -> dialog.dismiss());
        }

        if (btnBaixarCertificado != null && layoutCertificadoParaSalvar != null) {
            btnBaixarCertificado.setOnClickListener(v -> {
                String nomeFile = "Certificado_" + nomeCurso.replace(" ", "_");
                salvarViewComoImagem(context, layoutCertificadoParaSalvar, nomeFile);
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    public static void salvarViewComoImagem(Context context, View view, String filename) {
        try {
            view.setDrawingCacheEnabled(true);
            Bitmap bitmap = Bitmap.createBitmap(view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            view.draw(canvas);
            view.setDrawingCacheEnabled(false);

            new Thread(() -> {
                try {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues resolverValues = new ContentValues();
                        resolverValues.put(MediaStore.MediaColumns.DISPLAY_NAME, filename + ".jpg");
                        resolverValues.put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg");
                        resolverValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/ProximaEtapa");

                        Uri imageUri = context.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, resolverValues);
                        if (imageUri != null) {
                            OutputStream fos = context.getContentResolver().openOutputStream(imageUri);
                            if (fos != null) {
                                bitmap.compress(Bitmap.CompressFormat.JPEG, 100, fos);
                                fos.close();
                            }
                        }
                    }
                    new Handler(Looper.getMainLooper()).post(() ->
                            NotificationHelper.exibirToastCustomizado(context, "Salvo na Galeria em Pictures/ProximaEtapa!")
                    );
                } catch (Exception e) {
                    new Handler(Looper.getMainLooper()).post(() ->
                            NotificationHelper.exibirToastCustomizado(context, "Erro ao salvar imagem.")
                    );
                }
            }).start();
        } catch (Exception e) {
            NotificationHelper.exibirToastCustomizado(context, "Erro ao gerar imagem.");
        }
    }
}