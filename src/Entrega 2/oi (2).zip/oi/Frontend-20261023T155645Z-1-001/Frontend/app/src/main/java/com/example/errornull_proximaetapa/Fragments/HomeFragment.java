package com.example.errornull_proximaetapa.Fragments;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.example.errornull_proximaetapa.BlacklistManager;
import com.example.errornull_proximaetapa.CardImageSaver;
import com.example.errornull_proximaetapa.ChatManager;
import com.example.errornull_proximaetapa.NotificationHelper;
import com.example.errornull_proximaetapa.R;
import com.example.errornull_proximaetapa.TelaAulaCurso;
import com.example.errornull_proximaetapa.UserSession;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HomeFragment extends Fragment {

    // Componentes do Aluno
    private TextView txtNomeAluno;
    private TextView txtBoasVindas;
    private TextView txtNomeCompleto;
    private TextView txtIdade;
    private TextView txtEscola;
    private ImageView imgFotoAluno;
    private Button btnVerCardHome;
    private View btnAvisosSuspensoesHome;

    // Containers Específicos de Aluno vs Admin
    private LinearLayout containerHomeAdmin;
    private LinearLayout containerHomeAluno;
    private View btnAdminBlacklistTools;
    private Button btnCadastrarAlunoAdmin;
    private LinearLayout containerListaAlunosAdmin;
    private View btnChatProfAdmHome;

    // Filtros de Alunos do ADM
    private String filtroAlunoAtual = "todos";
    private TextView filterAAll, filterAAtivos, filterAAvisos, filterA1Strike, filterA2Strikes, filterABanidos, filterADesativados;

    // Componentes dos Questionários
    private LinearLayout areaQuestionario1;
    private LinearLayout areaQuestionario2;

    // Componentes do Progresso de Cursos
    private LinearLayout containerCursosInscritosHome;
    private View layoutSemCursos;
    private View btnSininhoNotificacoes;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        txtNomeAluno = view.findViewById(R.id.txtNomeAluno);
        txtBoasVindas = view.findViewById(R.id.txtBoasVindas);
        txtNomeCompleto = view.findViewById(R.id.txtNomeCompleto);
        txtIdade = view.findViewById(R.id.txtIdade);
        txtEscola = view.findViewById(R.id.txtEscola);
        imgFotoAluno = view.findViewById(R.id.imgFotoAluno);
        btnVerCardHome = view.findViewById(R.id.btnVerCardHome);

        btnAvisosSuspensoesHome = view.findViewById(R.id.btnAvisosSuspensoesHome);
        if (btnAvisosSuspensoesHome != null) {
            btnAvisosSuspensoesHome.setOnClickListener(v -> BlacklistManager.exibirBlacklistAlunoDialog(requireContext()));
        }

        containerHomeAdmin = view.findViewById(R.id.containerHomeAdmin);
        containerHomeAluno = view.findViewById(R.id.containerHomeAluno);
        btnAdminBlacklistTools = view.findViewById(R.id.btnAdminBlacklistTools);

        btnCadastrarAlunoAdmin = view.findViewById(R.id.btnCadastrarAlunoAdmin);
        containerListaAlunosAdmin = view.findViewById(R.id.containerListaAlunosAdmin);
        btnChatProfAdmHome = view.findViewById(R.id.btnChatProfAdmHome);

        if (btnChatProfAdmHome != null) {
            btnChatProfAdmHome.setOnClickListener(v -> ChatManager.abrirJanelaChat(
                    requireContext(),
                    "chat_prof_adm",
                    "💬 Chat Docentes ↔ ADM",
                    "Comunicação direta em tempo real entre Professores e Direção"
            ));
        }

        configurarFiltrosAlunosAdmin(view);

        if (btnAdminBlacklistTools != null) {
            btnAdminBlacklistTools.setOnClickListener(v -> BlacklistManager.exibirPainelAdminBlacklistDialog(requireContext()));
        }

        if (btnCadastrarAlunoAdmin != null) {
            btnCadastrarAlunoAdmin.setOnClickListener(v -> exibirDialogCadastrarAluno());
        }

        btnSininhoNotificacoes = view.findViewById(R.id.btnSininhoNotificacoes);
        if (btnSininhoNotificacoes != null) {
            btnSininhoNotificacoes.setOnClickListener(v -> NotificationHelper.exibirCentralNotificacoes(requireContext(), () -> atualizarSininho(view)));
        }

        areaQuestionario1 = view.findViewById(R.id.areaQuestionario1);
        areaQuestionario2 = view.findViewById(R.id.areaQuestionario2);

        containerCursosInscritosHome = view.findViewById(R.id.containerCursosInscritosHome);
        layoutSemCursos = view.findViewById(R.id.layoutSemCursos);

        carregarDadosSalvos(view);
    }

    private void configurarFiltrosAlunosAdmin(View view) {
        filterAAll = view.findViewById(R.id.filterAlunoTodos);
        filterAAtivos = view.findViewById(R.id.filterAlunoAtivos);
        filterAAvisos = view.findViewById(R.id.filterAlunoAvisos);
        filterA1Strike = view.findViewById(R.id.filterAluno1Strike);
        filterA2Strikes = view.findViewById(R.id.filterAluno2Strikes);
        filterABanidos = view.findViewById(R.id.filterAlunoBanidos);
        filterADesativados = view.findViewById(R.id.filterAlunoDesativados);

        if (filterAAll != null) filterAAll.setOnClickListener(v -> aplicarFiltroAluno("todos"));
        if (filterAAtivos != null) filterAAtivos.setOnClickListener(v -> aplicarFiltroAluno("ativos"));
        if (filterAAvisos != null) filterAAvisos.setOnClickListener(v -> aplicarFiltroAluno("avisos"));
        if (filterA1Strike != null) filterA1Strike.setOnClickListener(v -> aplicarFiltroAluno("1strike"));
        if (filterA2Strikes != null) filterA2Strikes.setOnClickListener(v -> aplicarFiltroAluno("2strikes"));
        if (filterABanidos != null) filterABanidos.setOnClickListener(v -> aplicarFiltroAluno("banidos"));
        if (filterADesativados != null) filterADesativados.setOnClickListener(v -> aplicarFiltroAluno("desativados"));
    }

    private void aplicarFiltroAluno(String filtro) {
        filtroAlunoAtual = filtro;
        resetarVisualFiltrosAlunos();

        if ("ativos".equalsIgnoreCase(filtro) && filterAAtivos != null) {
            filterAAtivos.setBackgroundResource(R.drawable.bg_pill_purple);
            filterAAtivos.setTextColor(Color.WHITE);
        } else if ("avisos".equalsIgnoreCase(filtro) && filterAAvisos != null) {
            filterAAvisos.setBackgroundResource(R.drawable.bg_pill_purple);
            filterAAvisos.setTextColor(Color.WHITE);
        } else if ("1strike".equalsIgnoreCase(filtro) && filterA1Strike != null) {
            filterA1Strike.setBackgroundResource(R.drawable.bg_pill_purple);
            filterA1Strike.setTextColor(Color.WHITE);
        } else if ("2strikes".equalsIgnoreCase(filtro) && filterA2Strikes != null) {
            filterA2Strikes.setBackgroundResource(R.drawable.bg_pill_purple);
            filterA2Strikes.setTextColor(Color.WHITE);
        } else if ("banidos".equalsIgnoreCase(filtro) && filterABanidos != null) {
            filterABanidos.setBackgroundResource(R.drawable.bg_pill_purple);
            filterABanidos.setTextColor(Color.WHITE);
        } else if ("desativados".equalsIgnoreCase(filtro) && filterADesativados != null) {
            filterADesativados.setBackgroundResource(R.drawable.bg_pill_purple);
            filterADesativados.setTextColor(Color.WHITE);
        } else if (filterAAll != null) {
            filterAAll.setBackgroundResource(R.drawable.bg_pill_purple);
            filterAAll.setTextColor(Color.WHITE);
        }

        renderizarListaAlunosAdmin();
    }

    private void resetarVisualFiltrosAlunos() {
        if (getContext() == null) return;
        int darkIndigo = requireContext().getColor(R.color.dark_indigo);
        if (filterAAll != null) { filterAAll.setBackgroundResource(R.drawable.bg_card_questionario); filterAAll.setTextColor(darkIndigo); }
        if (filterAAtivos != null) { filterAAtivos.setBackgroundResource(R.drawable.bg_card_questionario); filterAAtivos.setTextColor(darkIndigo); }
        if (filterAAvisos != null) { filterAAvisos.setBackgroundResource(R.drawable.bg_card_questionario); filterAAvisos.setTextColor(darkIndigo); }
        if (filterA1Strike != null) { filterA1Strike.setBackgroundResource(R.drawable.bg_card_questionario); filterA1Strike.setTextColor(darkIndigo); }
        if (filterA2Strikes != null) { filterA2Strikes.setBackgroundResource(R.drawable.bg_card_questionario); filterA2Strikes.setTextColor(darkIndigo); }
        if (filterABanidos != null) { filterABanidos.setBackgroundResource(R.drawable.bg_card_questionario); filterABanidos.setTextColor(darkIndigo); }
        if (filterADesativados != null) { filterADesativados.setBackgroundResource(R.drawable.bg_card_questionario); filterADesativados.setTextColor(darkIndigo); }
    }

    private void atualizarSininho(View view) {
        if (view == null || getContext() == null) return;
        TextView badge = view.findViewById(R.id.badgeSininhoQtd);
        int qtd = NotificationHelper.getQtdNaoLidas(requireContext());
        if (badge != null) {
            if (qtd > 0) {
                badge.setText(String.valueOf(qtd));
                badge.setVisibility(View.VISIBLE);
            } else {
                badge.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        if (getView() != null) {
            carregarDadosSalvos(getView());
        }
    }

    private void carregarDadosSalvos(View view) {
        if (getContext() == null) return;

        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

        String nome = sp.getString("nome", "nome usuario");
        String idade = sp.getString("idade", "17 anos");
        String escola = sp.getString("escola", "E.E. Próxima Etapa");
        String fotoUri = sp.getString("foto_perfil_uri", "");
        String tipo = sp.getString("tipoUsuario", "aluno");

        atualizarDadosAluno(nome, nome, idade, escola, tipo);

        if (imgFotoAluno != null && !fotoUri.isEmpty()) {
            carregarImagemElemento(imgFotoAluno, fotoUri);
        }

        // Atualiza a badge de strikes no botão de avisos e suspensões da Home do Aluno
        int qtdStrikes = BlacklistManager.getQtdStrikes(requireContext());
        TextView badgeStrikes = view.findViewById(R.id.badgeStrikesHome);
        if (badgeStrikes != null) {
            if (qtdStrikes > 0) {
                badgeStrikes.setText(qtdStrikes + " Strike(s)");
                badgeStrikes.setBackgroundResource(R.drawable.bg_strike_block_red);
                badgeStrikes.setTextColor(requireContext().getColor(R.color.white));
            } else {
                badgeStrikes.setText("Ver Blacklist");
                badgeStrikes.setBackgroundResource(R.drawable.bg_pill_yellow);
                badgeStrikes.setTextColor(requireContext().getColor(R.color.dark_indigo));
            }
        }

        configurarVisibilidadeAba(tipo);
        renderizarCursosInscritos(sp);
        atualizarSininho(view);
    }

    private void configurarVisibilidadeAba(String tipoUsuario) {
        if ("admin".equalsIgnoreCase(tipoUsuario)) {
            if (containerHomeAdmin != null) containerHomeAdmin.setVisibility(View.VISIBLE);
            if (containerHomeAluno != null) containerHomeAluno.setVisibility(View.GONE);
            renderizarListaAlunosAdmin();
        } else {
            if (containerHomeAdmin != null) containerHomeAdmin.setVisibility(View.GONE);
            if (containerHomeAluno != null) containerHomeAluno.setVisibility(View.VISIBLE);

            if (btnVerCardHome != null) {
                if ("professor".equalsIgnoreCase(tipoUsuario)) {
                    btnVerCardHome.setText("➕ Postar Novo Curso");
                    btnVerCardHome.setOnClickListener(v -> exibirDialogPostarCurso());
                    if (areaQuestionario1 != null) areaQuestionario1.setVisibility(View.GONE);
                    if (areaQuestionario2 != null) areaQuestionario2.setVisibility(View.GONE);
                    if (btnAvisosSuspensoesHome != null) btnAvisosSuspensoesHome.setVisibility(View.GONE);
                } else {
                    btnVerCardHome.setText("Ver Card do Estudante");
                    btnVerCardHome.setOnClickListener(v -> CardImageSaver.exibirCardEstudanteDialog(requireContext()));
                    if (areaQuestionario1 != null) areaQuestionario1.setVisibility(View.VISIBLE);
                    if (areaQuestionario2 != null) areaQuestionario2.setVisibility(View.VISIBLE);
                    if (btnAvisosSuspensoesHome != null) btnAvisosSuspensoesHome.setVisibility(View.VISIBLE);
                }
            }
        }
    }

    private void renderizarListaAlunosAdmin() {
        if (containerListaAlunosAdmin == null || getContext() == null) return;
        containerListaAlunosAdmin.removeAllViews();

        SharedPreferences spGeneral = requireContext().getSharedPreferences("ListaGeralAlunosAdmin", Context.MODE_PRIVATE);
        String savedString = spGeneral.getString("lista_alunos_cadastrados_string", "");
        List<String> listaAlunos = new ArrayList<>();

        if (!savedString.isEmpty()) {
            listaAlunos.addAll(Arrays.asList(savedString.split("###")));
        } else {
            // Alunos cadastrados padrão
            listaAlunos.add("Bolo Fofo;;;aluno@proximaetapa.com");
            listaAlunos.add("João Silva;;;joao@escola.com");
            listaAlunos.add("Maria Souza;;;maria@escola.com");
            salvarAlunosAdminSp(spGeneral, listaAlunos);
        }

        LayoutInflater inflater = LayoutInflater.from(getContext());
        int exibidosCount = 0;

        for (int i = 0; i < listaAlunos.size(); i++) {
            final int index = i;
            String alunoStr = listaAlunos.get(i);
            String[] partes = alunoStr.split(";;;");
            String nomeAluno = partes.length > 0 ? partes[0] : "Aluno";
            String emailAluno = partes.length > 1 ? partes[1] : "aluno@escola.com";

            // Verifica o status do aluno para os filtros sem modificar a sessão do usuário conectado
            SharedPreferences spAluno = UserSession.getScopedPreferencesForUser(requireContext(), emailAluno);
            int strikesCount = spAluno.getInt("strike_count", 0);
            boolean banido = spAluno.getBoolean("esta_banido", false) || strikesCount >= 3;
            boolean suspenso = spAluno.getBoolean("esta_suspenso", false);

            // APLICAÇÃO DOS FILTROS POR CATEGORIA DE ALUNOS
            if ("ativos".equalsIgnoreCase(filtroAlunoAtual) && (banido || suspenso)) continue;
            if ("1strike".equalsIgnoreCase(filtroAlunoAtual) && (strikesCount != 1 || banido)) continue;
            if ("2strikes".equalsIgnoreCase(filtroAlunoAtual) && (strikesCount != 2 || banido)) continue;
            if ("banidos".equalsIgnoreCase(filtroAlunoAtual) && !banido) continue;
            if ("avisos".equalsIgnoreCase(filtroAlunoAtual)) {
                String savedAvisos = spAluno.getString("lista_avisos_professor", "");
                if (savedAvisos.isEmpty()) continue;
            }
            if ("desativados".equalsIgnoreCase(filtroAlunoAtual)) {
                boolean desativada = spAluno.getBoolean("conta_desativada", false);
                if (!desativada) continue;
            }

            exibidosCount++;

            View rowView = inflater.inflate(R.layout.item_aluno_admin_row, containerListaAlunosAdmin, false);

            TextView txtNome = rowView.findViewById(R.id.txtNomeAlunoRow);
            TextView txtEmail = rowView.findViewById(R.id.txtEmailAlunoRow);
            TextView txtStatus = rowView.findViewById(R.id.txtStatusAlunoRow);

            Button btnStrike = rowView.findViewById(R.id.btnStrikeAlunoRow);
            Button btnAviso = rowView.findViewById(R.id.btnAvisoAlunoRow);
            Button btnLiberar = rowView.findViewById(R.id.btnLiberarAlunoRow);
            ImageView btnExcluir = rowView.findViewById(R.id.btnExcluirAlunoRow);

            if (txtNome != null) txtNome.setText(nomeAluno);
            if (txtEmail != null) txtEmail.setText(emailAluno);

            if (txtStatus != null) {
                if (banido) {
                    txtStatus.setText("BANIDO (3/3)");
                    txtStatus.setBackgroundResource(R.drawable.bg_pill_purple);
                } else if (suspenso) {
                    txtStatus.setText("SUSPENSO (" + strikesCount + "/3)");
                    txtStatus.setBackgroundResource(R.drawable.bg_strike_block_red);
                } else {
                    txtStatus.setText("Regular");
                    txtStatus.setBackgroundResource(R.drawable.bg_pill_green);
                }
            }

            if (btnStrike != null) {
                btnStrike.setOnClickListener(v -> {
                    BlacklistManager.aplicarStrikeParaEmail(requireContext(), emailAluno, "Desrespeito às regras da plataforma", "1 minuto");
                    renderizarListaAlunosAdmin();
                });
            }

            if (btnAviso != null) {
                btnAviso.setOnClickListener(v -> {
                    BlacklistManager.enviarAvisoProfessorParaEmail(requireContext(), emailAluno, "Por favor, atente-se aos prazos e entregas de atividades.", "ADM");
                    renderizarListaAlunosAdmin();
                });
            }

            if (btnLiberar != null) {
                btnLiberar.setOnClickListener(v -> {
                    BlacklistManager.removerStrikesELiberarAlunoParaEmail(requireContext(), emailAluno);
                    renderizarListaAlunosAdmin();
                });
            }

            if (btnExcluir != null) {
                btnExcluir.setOnClickListener(v -> {
                    listaAlunos.remove(index);
                    salvarAlunosAdminSp(spGeneral, listaAlunos);
                    renderizarListaAlunosAdmin();
                    NotificationHelper.exibirToastCustomizado(getContext(), "Aluno " + nomeAluno + " removido da lista!");
                });
            }

            containerListaAlunosAdmin.addView(rowView);
        }

        if (exibidosCount == 0) {
            TextView txtVazio = new TextView(getContext());
            txtVazio.setText("Nenhum aluno encontrado para o filtro '" + filtroAlunoAtual.toUpperCase() + "'.");
            txtVazio.setTextColor(requireContext().getColor(R.color.dark_gray));
            txtVazio.setTextSize(12);
            txtVazio.setPadding(8, 8, 8, 8);
            containerListaAlunosAdmin.addView(txtVazio);
        }
    }

    private void salvarAlunosAdminSp(SharedPreferences spGeneral, List<String> lista) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < lista.size(); i++) {
            sb.append(lista.get(i));
            if (i < lista.size() - 1) sb.append("###");
        }
        spGeneral.edit().putString("lista_alunos_cadastrados_string", sb.toString()).apply();
    }

    private void exibirDialogCadastrarAluno() {
        if (getContext() == null) return;

        LinearLayout cardView = new LinearLayout(requireContext());
        cardView.setOrientation(LinearLayout.VERTICAL);
        cardView.setBackgroundResource(R.drawable.bg_card_questionario);
        cardView.setPadding(40, 40, 40, 40);

        TextView title = new TextView(requireContext());
        title.setText("➕ Cadastrar Novo Aluno");
        title.setTextColor(requireContext().getColor(R.color.dark_indigo));
        title.setTextSize(16);
        title.setTypeface(null, android.graphics.Typeface.BOLD);

        EditText inputNome = new EditText(requireContext());
        inputNome.setHint("Nome do Aluno");

        EditText inputEmail = new EditText(requireContext());
        inputEmail.setHint("E-mail do Aluno");

        Button btnAdd = new Button(requireContext());
        btnAdd.setText("Cadastrar Aluno");
        btnAdd.setBackgroundTintList(android.content.res.ColorStateList.valueOf(requireContext().getColor(R.color.yellow)));
        btnAdd.setTextColor(requireContext().getColor(R.color.dark_indigo));
        btnAdd.setTypeface(null, android.graphics.Typeface.BOLD);

        cardView.addView(title);
        cardView.addView(inputNome);
        cardView.addView(inputEmail);
        cardView.addView(btnAdd);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(cardView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        btnAdd.setOnClickListener(v -> {
            String nome = inputNome.getText().toString().trim();
            String email = inputEmail.getText().toString().trim();

            if (nome.isEmpty() || email.isEmpty()) {
                NotificationHelper.exibirToastCustomizado(getContext(), "Preencha o nome e o e-mail!");
                return;
            }

            SharedPreferences spGeneral = requireContext().getSharedPreferences("ListaGeralAlunosAdmin", Context.MODE_PRIVATE);
            String savedString = spGeneral.getString("lista_alunos_cadastrados_string", "");
            List<String> listaAlunos = new ArrayList<>();
            if (!savedString.isEmpty()) {
                listaAlunos.addAll(Arrays.asList(savedString.split("###")));
            }

            listaAlunos.add(nome + ";;;" + email);
            salvarAlunosAdminSp(spGeneral, listaAlunos);

            // Cria o perfil isolado do novo aluno sem alterar a sessão ativa do ADM
            SharedPreferences spNovo = UserSession.getScopedPreferencesForUser(requireContext(), email);
            spNovo.edit()
                    .putString("nome", nome)
                    .putString("email", email)
                    .putString("tipoUsuario", "aluno")
                    .apply();

            NotificationHelper.exibirToastCustomizado(getContext(), "Aluno " + nome + " cadastrado com sucesso!");
            renderizarListaAlunosAdmin();
            dialog.dismiss();
        });

        dialog.show();
    }

    private void exibirDialogPostarCurso() {
        if (getContext() == null) return;

        View dialogView = LayoutInflater.from(requireContext()).inflate(R.layout.dialog_postar_curso, null);

        EditText inputNome = dialogView.findViewById(R.id.inputNomeCursoPostar);
        EditText inputFaculdade = dialogView.findViewById(R.id.inputFaculdadePostar);
        EditText inputCarga = dialogView.findViewById(R.id.inputCargaHorariaPostar);
        EditText inputDias = dialogView.findViewById(R.id.inputDiasSemanaPostar);
        Button btnPublicar = dialogView.findViewById(R.id.btnPublicarCursoProfessor);

        AlertDialog dialog = new AlertDialog.Builder(requireContext())
                .setView(dialogView)
                .create();

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        if (btnPublicar != null) {
            btnPublicar.setOnClickListener(v -> {
                String nome = inputNome != null ? inputNome.getText().toString().trim() : "";
                String faculdade = inputFaculdade != null ? inputFaculdade.getText().toString().trim() : "USP";
                String carga = inputCarga != null ? inputCarga.getText().toString().trim() : "80 horas";
                String dias = inputDias != null ? inputDias.getText().toString().trim() : "Seg, Qua, Sex (14h - 16h)";

                if (nome.isEmpty()) {
                    NotificationHelper.exibirToastCustomizado(getContext(), "Digite o nome do curso!");
                    return;
                }

                String idCurso = "curso_prof_" + System.currentTimeMillis();
                SharedPreferences sp = UserSession.getScopedPreferences(requireContext());

                Set<String> setCursos = new HashSet<>(sp.getStringSet("lista_cursos_ids", new HashSet<>()));
                setCursos.add(idCurso);

                sp.edit()
                        .putBoolean("inscrito", true)
                        .putStringSet("lista_cursos_ids", setCursos)
                        .putString("nomeCurso_" + idCurso, nome)
                        .putString("faculdadeCurso_" + idCurso, faculdade)
                        .putString("cargaHoraria_" + idCurso, carga)
                        .putString("diasSemana_" + idCurso, dias)
                        .putInt("progressoCurso_" + idCurso, 0)
                        .apply();

                NotificationHelper.adicionarNotificacao(
                        requireContext(),
                        "Novo Curso Publicado",
                        "Você publicou a disciplina de " + nome + " (" + faculdade + ") para os alunos!"
                );

                NotificationHelper.exibirToastCustomizado(getContext(), "📢 Curso " + nome + " publicado com sucesso!");
                carregarDadosSalvos(getView());
                dialog.dismiss();
            });
        }

        dialog.show();
    }

    private void renderizarCursosInscritos(SharedPreferences sp) {
        if (containerCursosInscritosHome == null || layoutSemCursos == null || getContext() == null) return;

        containerCursosInscritosHome.removeAllViews();

        Set<String> setCursosOriginal = sp.getStringSet("lista_cursos_ids", new HashSet<>());
        Set<String> setCursos = new HashSet<>(setCursosOriginal);

        if (setCursos.isEmpty()) {
            containerCursosInscritosHome.setVisibility(View.GONE);
            layoutSemCursos.setVisibility(View.VISIBLE);
            return;
        }

        containerCursosInscritosHome.setVisibility(View.VISIBLE);
        layoutSemCursos.setVisibility(View.GONE);

        LayoutInflater inflater = LayoutInflater.from(getContext());

        for (String idCurso : setCursos) {
            String nomeCurso = sp.getString("nomeCurso_" + idCurso, "");
            String faculdade = sp.getString("faculdadeCurso_" + idCurso, "USP");
            String diasSemana = sp.getString("diasSemana_" + idCurso, "Segunda, Quarta e Sexta (14h - 16h)");
            int progresso = sp.getInt("progressoCurso_" + idCurso, 0);

            if (nomeCurso.isEmpty()) continue;

            View cardItem = inflater.inflate(R.layout.item_card_curso_home, containerCursosInscritosHome, false);

            TextView txtResumo = cardItem.findViewById(R.id.txtResumoCursos);
            TextView txtBadge = cardItem.findViewById(R.id.txtFaculdadeBadge);
            TextView txtDiasAulas = cardItem.findViewById(R.id.txtDiasAulasHome);
            ProgressBar pbProgresso = cardItem.findViewById(R.id.progressoCursos);
            TextView txtPorcentagem = cardItem.findViewById(R.id.txtPorcentagem);

            if (txtResumo != null) txtResumo.setText(nomeCurso);
            if (txtBadge != null) txtBadge.setText(faculdade);
            if (txtDiasAulas != null) txtDiasAulas.setText("📅 " + diasSemana);
            if (pbProgresso != null) pbProgresso.setProgress(progresso);
            if (txtPorcentagem != null) txtPorcentagem.setText(progresso + "%");

            cardItem.setOnClickListener(v -> {
                if (BlacklistManager.isSuspensoOuBanido(requireContext())) {
                    BlacklistManager.exibirTelaBloqueioCurso(requireContext());
                    return;
                }
                Intent intent = new Intent(getActivity(), TelaAulaCurso.class);
                intent.putExtra("cursoId", idCurso);
                startActivity(intent);
            });

            containerCursosInscritosHome.addView(cardItem);
        }
    }

    private void carregarImagemElemento(ImageView imageView, String fotoUriStr) {
        if (imageView == null || fotoUriStr == null || fotoUriStr.isEmpty()) return;

        if (fotoUriStr.startsWith("preset:")) {
            String presetName = fotoUriStr.replace("preset:", "");
            if ("baseline_account".equals(presetName)) {
                imageView.setImageResource(R.drawable.baseline_account);
            } else if ("logo_proxima_etapa".equals(presetName)) {
                imageView.setImageResource(R.drawable.logo_proxima_etapa);
            } else {
                imageView.setImageResource(R.drawable.round_person);
            }
        } else {
            try {
                imageView.setImageURI(Uri.parse(fotoUriStr));
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.round_person);
            }
        }
    }

    public LinearLayout getAreaQuestionario1() {
        return areaQuestionario1;
    }

    public LinearLayout getAreaQuestionario2() {
        return areaQuestionario2;
    }

    public ImageView getImgFotoAluno() {
        return imgFotoAluno;
    }

    public void atualizarDadosAluno(String nome, String nomeCompleto, String idade, String escola, String tipoUsuario) {
        if (txtNomeAluno != null) txtNomeAluno.setText(nome);
        if (txtBoasVindas != null) {
            if ("professor".equalsIgnoreCase(tipoUsuario)) {
                txtBoasVindas.setText("bem vindo(a), professor(a)!");
            } else if ("admin".equalsIgnoreCase(tipoUsuario)) {
                txtBoasVindas.setText("bem vindo(a), administrador(a)!");
            } else {
                String mensagem = getString(R.string.boas_vindas_format, nome);
                txtBoasVindas.setText(mensagem);
            }
        }
        if (txtNomeCompleto != null) txtNomeCompleto.setText(nomeCompleto);
        if (txtIdade != null) txtIdade.setText("professor".equalsIgnoreCase(tipoUsuario) || "admin".equalsIgnoreCase(tipoUsuario) ? "Docente / Gestor" : idade);
        if (txtEscola != null) txtEscola.setText(escola);
    }
}