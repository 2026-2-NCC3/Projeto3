package com.example.errornull_proximaetapa.Fragments;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.errornull_proximaetapa.Cadastro;
import com.example.errornull_proximaetapa.CadastroViewModel;
import com.example.errornull_proximaetapa.R;

public class CadastroEtapa1Fragment extends Fragment {

    private EditText inputNome, inputIdade, inputCpf, inputEstado, inputEmail, inputSenha;
    private Button btnAvancarEtapa1;
    private CadastroViewModel viewModel;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cadastro_etapa1, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity() != null) {
            viewModel = new ViewModelProvider(requireActivity()).get(CadastroViewModel.class);
        }

        inputNome = view.findViewById(R.id.input_nome);
        inputIdade = view.findViewById(R.id.input_idade);
        inputCpf = view.findViewById(R.id.input_cpf);
        inputEstado = view.findViewById(R.id.input_estado);
        inputEmail = view.findViewById(R.id.input_email);
        inputSenha = view.findViewById(R.id.input_senha);
        btnAvancarEtapa1 = view.findViewById(R.id.btnAvancarEtapa1);

        // Preencher valores salvos no ViewModel para não perder dados
        if (viewModel != null) {
            if (inputNome != null) inputNome.setText(viewModel.getNome());
            if (inputIdade != null) inputIdade.setText(viewModel.getIdade());
            if (inputCpf != null) inputCpf.setText(viewModel.getCpf());
            if (inputEstado != null) inputEstado.setText(viewModel.getEstado());
            if (inputEmail != null) inputEmail.setText(viewModel.getEmail());
            if (inputSenha != null) inputSenha.setText(viewModel.getSenha());
        }

        // Listener para bloquear alteração do tipo de conta assim que o usuário digita algo
        TextWatcher lockTabsWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0 && getActivity() instanceof Cadastro) {
                    ((Cadastro) getActivity()).bloquearTabs(true);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        };

        if (inputNome != null) inputNome.addTextChangedListener(lockTabsWatcher);
        if (inputCpf != null) inputCpf.addTextChangedListener(lockTabsWatcher);
        if (inputEmail != null) inputEmail.addTextChangedListener(lockTabsWatcher);

        btnAvancarEtapa1.setOnClickListener(v -> {
            String nome = inputNome != null ? inputNome.getText().toString().trim() : "";
            String idade = inputIdade != null ? inputIdade.getText().toString().trim() : "";
            String cpf = inputCpf != null ? inputCpf.getText().toString().trim() : "";
            String estado = inputEstado != null ? inputEstado.getText().toString().trim() : "";
            String email = inputEmail != null ? inputEmail.getText().toString().trim() : "";
            String senha = inputSenha != null ? inputSenha.getText().toString().trim() : "";

            if (nome.isEmpty() || cpf.isEmpty() || email.isEmpty() || senha.isEmpty()) {
                Toast.makeText(getContext(), "Preencha os campos obrigatórios da Parte 1!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Salva estado no ViewModel
            if (viewModel != null) {
                viewModel.setNome(nome);
                viewModel.setIdade(idade);
                viewModel.setCpf(cpf);
                viewModel.setEstado(estado);
                viewModel.setEmail(email);
                viewModel.setSenha(senha);
            }

            if (getActivity() instanceof Cadastro) {
                ((Cadastro) getActivity()).navegarParaEtapa(2);
            }
        });
    }

    @Override
    public void onPause() {
        super.onPause();
        salvarDados();
    }

    private void salvarDados() {
        if (viewModel == null) return;
        if (inputNome != null) viewModel.setNome(inputNome.getText().toString().trim());
        if (inputIdade != null) viewModel.setIdade(inputIdade.getText().toString().trim());
        if (inputCpf != null) viewModel.setCpf(inputCpf.getText().toString().trim());
        if (inputEstado != null) viewModel.setEstado(inputEstado.getText().toString().trim());
        if (inputEmail != null) viewModel.setEmail(inputEmail.getText().toString().trim());
        if (inputSenha != null) viewModel.setSenha(inputSenha.getText().toString().trim());
    }
}