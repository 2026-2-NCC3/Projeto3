package com.example.errornull_proximaetapa.Fragments;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.errornull_proximaetapa.Cadastro;
import com.example.errornull_proximaetapa.CadastroViewModel;
import com.example.errornull_proximaetapa.R;
import com.example.errornull_proximaetapa.UserSession;

public class CadastroEtapa3Fragment extends Fragment {

    private View btnEscolherFoto;
    private ImageView imgPerfilPreview;
    private EditText inputBio, inputPreferencias;
    private Button btnVoltarEtapa3, btnCadastrar;

    private CadastroViewModel viewModel;

    // Launcher para seleção de foto da galeria do dispositivo
    private final ActivityResultLauncher<String> pickImageLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) {
                    try {
                        requireContext().getContentResolver().takePersistableUriPermission(
                                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                    } catch (Exception ignored) {}

                    if (imgPerfilPreview != null) {
                        imgPerfilPreview.setImageURI(uri);
                    }

                    if (viewModel != null) {
                        viewModel.setFotoUri(uri.toString());
                    }

                    if (getContext() != null) {
                        SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
                        sp.edit().putString("foto_perfil_uri", uri.toString()).apply();
                    }

                    Toast.makeText(getContext(), "Foto da galeria selecionada!", Toast.LENGTH_SHORT).show();
                }
            });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_cadastro_etapa3, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        if (getActivity() != null) {
            viewModel = new ViewModelProvider(requireActivity()).get(CadastroViewModel.class);
            ((Cadastro) getActivity()).bloquearTabs(true);
        }

        btnEscolherFoto = view.findViewById(R.id.btnEscolherFoto);
        imgPerfilPreview = view.findViewById(R.id.imgPerfilPreview);
        inputBio = view.findViewById(R.id.input_bio);
        inputPreferencias = view.findViewById(R.id.input_preferencias);
        btnVoltarEtapa3 = view.findViewById(R.id.btnVoltarEtapa3);
        btnCadastrar = view.findViewById(R.id.btn_cadastrar);

        if (viewModel != null) {
            if (inputBio != null) inputBio.setText(viewModel.getBio());
            if (inputPreferencias != null) inputPreferencias.setText(viewModel.getPreferencias());

            carregarPreviewFoto(viewModel.getFotoUri());
        }

        if (btnEscolherFoto != null) {
            btnEscolherFoto.setOnClickListener(v -> exibirOpcoesFoto());
        }

        btnVoltarEtapa3.setOnClickListener(v -> {
            salvarDados();
            if (getActivity() instanceof Cadastro) {
                ((Cadastro) getActivity()).navegarParaEtapa(2);
            }
        });

        btnCadastrar.setOnClickListener(v -> {
            salvarDados();
            if (getActivity() instanceof Cadastro) {
                ((Cadastro) getActivity()).executarCadastroFinal();
            }
        });
    }

    private void exibirOpcoesFoto() {
        if (getContext() == null) return;

        CharSequence[] opcoes = {
                "📁 Galeria do Dispositivo",
                "👤 Avatar Clássico",
                "🎓 Avatar Estudante",
                "🚀 Logo Próxima Etapa"
        };

        new AlertDialog.Builder(requireContext())
                .setTitle("Escolher Foto de Perfil")
                .setItems(opcoes, (dialog, which) -> {
                    if (which == 0) {
                        pickImageLauncher.launch("image/*");
                    } else if (which == 1) {
                        aplicarFotoPreset("preset:round_person", R.drawable.round_person);
                    } else if (which == 2) {
                        aplicarFotoPreset("preset:baseline_account", R.drawable.baseline_account);
                    } else if (which == 3) {
                        aplicarFotoPreset("preset:logo_proxima_etapa", R.drawable.logo_proxima_etapa);
                    }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void aplicarFotoPreset(String presetKey, int drawableResId) {
        if (imgPerfilPreview != null) {
            imgPerfilPreview.setImageResource(drawableResId);
        }
        if (viewModel != null) {
            viewModel.setFotoUri(presetKey);
        }
        if (getContext() != null) {
            SharedPreferences sp = UserSession.getScopedPreferences(requireContext());
            sp.edit().putString("foto_perfil_uri", presetKey).apply();
        }
        Toast.makeText(getContext(), "Avatar selecionado com sucesso!", Toast.LENGTH_SHORT).show();
    }

    private void carregarPreviewFoto(String fotoUriStr) {
        if (imgPerfilPreview == null || fotoUriStr == null || fotoUriStr.isEmpty()) return;

        if (fotoUriStr.startsWith("preset:")) {
            String presetName = fotoUriStr.replace("preset:", "");
            if ("baseline_account".equals(presetName)) {
                imgPerfilPreview.setImageResource(R.drawable.baseline_account);
            } else if ("logo_proxima_etapa".equals(presetName)) {
                imgPerfilPreview.setImageResource(R.drawable.logo_proxima_etapa);
            } else {
                imgPerfilPreview.setImageResource(R.drawable.round_person);
            }
        } else {
            try {
                imgPerfilPreview.setImageURI(Uri.parse(fotoUriStr));
            } catch (Exception e) {
                imgPerfilPreview.setImageResource(R.drawable.round_person);
            }
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        salvarDados();
    }

    private void salvarDados() {
        if (viewModel == null) return;
        if (inputBio != null) viewModel.setBio(inputBio.getText().toString().trim());
        if (inputPreferencias != null) viewModel.setPreferencias(inputPreferencias.getText().toString().trim());
    }
}